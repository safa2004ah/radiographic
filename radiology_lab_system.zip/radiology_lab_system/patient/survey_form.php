<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!hasPermission('patient')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$patient_id = $user['id'];
$survey_id = $_GET['survey_id'] ?? 0;

// جلب معلومات الاستبيان
$survey_query = "SELECT * FROM surveys WHERE id = ? AND status = 'active'";
$stmt = $conn->prepare($survey_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$survey = $stmt->get_result()->fetch_assoc();

if (!$survey) {
    header('Location: surveys.php');
    exit;
}

// التحقق من أن المريض لم يجب على هذا الاستبيان سابقاً
$check_response = "SELECT id FROM survey_responses WHERE survey_id = ? AND patient_id = ?";
$stmt = $conn->prepare($check_response);
$stmt->bind_param("ii", $survey_id, $patient_id);
$stmt->execute();

if ($stmt->get_result()->num_rows > 0) {
    $_SESSION['error'] = 'لقد أجبت على هذا الاستبيان سابقاً';
    header('Location: surveys.php');
    exit;
}

// جلب الأسئلة
$questions_query = "SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY order_num ASC, id ASC";
$stmt = $conn->prepare($questions_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$questions = $stmt->get_result();

// معالجة الإرسال
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $success_count = 0;
    
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question_') === 0) {
            $question_id = str_replace('question_', '', $key);
            
            // التحقق من أن السؤال يتبع للاستبيان
            $check_query = "SELECT id FROM survey_questions WHERE id = ? AND survey_id = ?";
            $stmt = $conn->prepare($check_query);
            $stmt->bind_param("ii", $question_id, $survey_id);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows > 0) {
                $answer = is_array($value) ? implode(', ', $value) : $value;
                
                $insert_query = "INSERT INTO survey_responses (survey_id, patient_id, question_id, answer) 
                                 VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_query);
                $stmt->bind_param("iiis", $survey_id, $patient_id, $question_id, $answer);
                
                if ($stmt->execute()) {
                    $success_count++;
                }
            }
        }
    }
    
    if ($success_count > 0) {
        $_SESSION['success'] = 'تم إرسال استجابتك بنجاح. شكراً لك!';
        header('Location: surveys.php');
        exit;
    } else {
        $error = 'لم يتم إرسال أي إجابات';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $survey['title']; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* تحسين التخطيط ليناسب الشريط الجانبي الثابت */
        body { background-color: #f8f9fa; }
        .main-content { margin-right: 16.66%; padding: 30px; min-height: 100vh; }
        .sidebar-container { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; }
        
        @media (max-width: 992px) {
            .main-content { margin-right: 0; }
            .sidebar-container { position: relative; width: 100%; height: auto; }
        }

        .rating-stars { display: inline-block; direction: rtl; }
        .rating-stars input[type="radio"] { display: none; }
        .rating-stars label { cursor: pointer; color: #ddd; font-size: 2.5rem; transition: color 0.2s; }
        .rating-stars input[type="radio"]:checked ~ label,
        .rating-stars label:hover,
        .rating-stars label:hover ~ label { color: #ffc107; }
        
        .card { border: none; border-radius: 15px; box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1); }
        .question-box { transition: background-color 0.3s; padding: 20px; border-radius: 10px; }
        .question-box:hover { background-color: #fbfbfb; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="sidebar-container shadow">
                <?php include 'sidebar.php'; ?>
            </div>

            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-4 border-bottom">
                    <h2 class="h3 fw-bold"><i class="fas fa-edit text-primary me-2"></i> استبيان: <?php echo $survey['title']; ?></h2>
                    <a href="surveys.php" class="btn btn-outline-secondary shadow-sm">
                        <i class="fas fa-arrow-right ms-2"></i>العودة
                    </a>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="card mb-5">
                    <div class="card-header bg-primary text-white py-3">
                        <h5 class="mb-0 fw-bold"><?php echo $survey['title']; ?></h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($survey['description']): ?>
                            <div class="alert alert-light border-start border-primary border-4 mb-5 shadow-sm">
                                <i class="fas fa-info-circle text-primary me-2"></i>
                                <?php echo $survey['description']; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" class="needs-validation" novalidate>
                            <?php $question_num = 1; ?>
                            <?php while ($question = $questions->fetch_assoc()): ?>
                                <div class="mb-4 question-box border-bottom">
                                    <h6 class="fw-bold mb-4 text-dark">
                                        <span class="badge bg-primary me-2"><?php echo $question_num++; ?></span>
                                        <?php echo $question['question']; ?>
                                        <?php if ($question['required']): ?>
                                            <span class="text-danger">*</span>
                                        <?php endif; ?>
                                    </h6>
                                    
                                    <div class="ms-4">
                                        <?php
                                        $options = !empty($question['options']) ? explode(',', $question['options']) : [];
                                        $options = array_map('trim', $options);
                                        ?>
                                        
                                        <?php if ($question['question_type'] == 'text'): ?>
                                            <textarea class="form-control shadow-sm" name="question_<?php echo $question['id']; ?>" 
                                                      rows="3" placeholder="اكتب إجابتك هنا..."
                                                      <?php echo $question['required'] ? 'required' : ''; ?>></textarea>
                                        
                                        <?php elseif ($question['question_type'] == 'radio'): ?>
                                            <?php foreach ($options as $option): ?>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="radio" 
                                                           name="question_<?php echo $question['id']; ?>" 
                                                           id="q<?php echo $question['id']; ?>_<?php echo urlencode($option); ?>" 
                                                           value="<?php echo htmlspecialchars($option); ?>"
                                                           <?php echo $question['required'] ? 'required' : ''; ?>>
                                                    <label class="form-check-label" for="q<?php echo $question['id']; ?>_<?php echo urlencode($option); ?>">
                                                        <?php echo $option; ?>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        
                                        <?php elseif ($question['question_type'] == 'checkbox'): ?>
                                            <?php foreach ($options as $option): ?>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="question_<?php echo $question['id']; ?>[]" 
                                                           id="q<?php echo $question['id']; ?>_<?php echo urlencode($option); ?>" 
                                                           value="<?php echo htmlspecialchars($option); ?>">
                                                    <label class="form-check-label" for="q<?php echo $question['id']; ?>_<?php echo urlencode($option); ?>">
                                                        <?php echo $option; ?>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        
                                        <?php elseif ($question['question_type'] == 'rating'): ?>
                                            <div class="text-center bg-light py-3 rounded-3 shadow-sm mb-2">
                                                <div class="rating-stars">
                                                    <?php for ($i = 5; $i >= 1; $i--): ?>
                                                        <input type="radio" id="star<?php echo $question['id']; ?>_<?php echo $i; ?>" 
                                                               name="question_<?php echo $question['id']; ?>" 
                                                               value="<?php echo $i; ?>"
                                                               <?php echo $question['required'] ? 'required' : ''; ?>>
                                                        <label for="star<?php echo $question['id']; ?>_<?php echo $i; ?>" title="<?php echo $i; ?> نجوم">
                                                            <i class="fas fa-star"></i>
                                                        </label>
                                                    <?php endfor; ?>
                                                </div>
                                                <div class="d-flex justify-content-around px-5 text-muted small mt-2">
                                                    <span>ممتاز</span>
                                                    <span>سيء جداً</span>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                            
                            <div class="row mt-5">
                                <div class="col-md-8 mx-auto">
                                    <div class="d-grid gap-3 d-md-flex justify-content-md-center">
                                        <button type="submit" class="btn btn-primary btn-lg px-5 shadow">
                                            <i class="fas fa-paper-plane ms-2"></i>إرسال الاستبيان
                                        </button>
                                        <a href="surveys.php" class="btn btn-outline-secondary btn-lg px-5">
                                            <i class="fas fa-times ms-2"></i>إلغاء
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        // التحقق من صحة النموذج
        (function() {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function(form) {
                    form.addEventListener('submit', function(event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
</body>
</html>