<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!hasPermission('patient')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$patient_id = $user['id'];

// جلب المواعيد القادمة
$today = date('Y-m-d');
$upcoming_appointments_query = "SELECT a.*, d.full_name as doctor_name, dept.name as department_name
                                FROM appointments a
                                JOIN users d ON a.doctor_id = d.id
                                JOIN departments dept ON a.department_id = dept.id
                                WHERE a.patient_id = ? 
                                AND a.appointment_date >= ?
                                ORDER BY a.appointment_date ASC, a.appointment_time ASC
                                LIMIT 5";

$stmt = $conn->prepare($upcoming_appointments_query);
$stmt->bind_param("is", $patient_id, $today);
$stmt->execute();
$upcoming_appointments = $stmt->get_result();

// جلب المواعيد السابقة
$previous_appointments_query = "SELECT a.*, d.full_name as doctor_name, dept.name as department_name
                                FROM appointments a
                                JOIN users d ON a.doctor_id = d.id
                                JOIN departments dept ON a.department_id = dept.id
                                WHERE a.patient_id = ? 
                                AND a.appointment_date < ?
                                ORDER BY a.appointment_date DESC, a.appointment_time DESC
                                LIMIT 5";

$stmt = $conn->prepare($previous_appointments_query);
$stmt->bind_param("is", $patient_id, $today);
$stmt->execute();
$previous_appointments = $stmt->get_result();

// جلب عدد المواعيد
$total_appointments_query = "SELECT COUNT(*) as count FROM appointments WHERE patient_id = ?";
$stmt = $conn->prepare($total_appointments_query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$total_appointments = $stmt->get_result()->fetch_assoc()['count'];

// جلب عدد السجلات الطبية
$medical_records_count_query = "SELECT COUNT(*) as count FROM medical_records WHERE patient_id = ?";
$stmt = $conn->prepare($medical_records_count_query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$medical_records_count = $stmt->get_result()->fetch_assoc()['count'];

// جلب الاستبيانات النشطة
$active_surveys_query = "SELECT s.*, COUNT(DISTINCT sq.id) as questions_count
                         FROM surveys s
                         LEFT JOIN survey_questions sq ON s.id = sq.survey_id
                         WHERE s.status = 'active'
                         AND s.id NOT IN (
                             SELECT DISTINCT survey_id FROM survey_responses WHERE patient_id = ?
                         )
                         GROUP BY s.id
                         LIMIT 3";

$stmt = $conn->prepare($active_surveys_query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$active_surveys = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المريض - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .main-content { margin-right: 16.66%; padding: 30px; }
        .sidebar-fixed { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>            
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">لوحة تحكم المريض</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <span class="badge bg-success">متصل الآن</span>
                    </div>
                </div>

                <!-- البطاقات الإحصائية -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6 col-lg-4">
                        <div class="card bg-primary text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title mb-0">إجمالي المواعيد</h6>
                                        <h2 class="mb-0"><?php echo $total_appointments; ?></h2>
                                    </div>
                                    <i class="fas fa-calendar-alt fa-2x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-lg-4">
                        <div class="card bg-success text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title mb-0">السجلات الطبية</h6>
                                        <h2 class="mb-0"><?php echo $medical_records_count; ?></h2>
                                    </div>
                                    <i class="fas fa-file-medical fa-2x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-lg-4">
                        <div class="card bg-info text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title mb-0">استبيانات متاحة</h6>
                                        <h2 class="mb-0"><?php echo $active_surveys->num_rows; ?></h2>
                                    </div>
                                    <i class="fas fa-poll fa-2x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المواعيد القادمة -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-calendar-check me-2"></i> المواعيد القادمة</h5>
                        <a href="appointments.php" class="btn btn-sm btn-light">عرض الكل</a>
                    </div>
                    <div class="card-body">
                        <?php if ($upcoming_appointments->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>التاريخ والوقت</th>
                                            <th>الطبيب</th>
                                            <th>القسم</th>
                                            <th>الحالة</th>
                                            <th>ملاحظات الموظف</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($appointment = $upcoming_appointments->fetch_assoc()): ?>
                                            <tr>
                                                <td>
                                                    <i class="fas fa-calendar me-2"></i>
                                                    <?php echo date('d/m/Y', strtotime($appointment['appointment_date'])); ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-clock me-1"></i>
                                                        <?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong><?php echo $appointment['doctor_name']; ?></strong>
                                                </td>
                                                <td>
                                                    <span class="badge bg-info"><?php echo $appointment['department_name']; ?></span>
                                                </td>
                                                <td>
                                                    <?php
                                                    $status_badge = [
                                                        'pending' => 'warning',
                                                        'confirmed' => 'success',
                                                        'completed' => 'secondary',
                                                        'cancelled' => 'danger',
                                                        'no-show' => 'dark'
                                                    ];
                                                    $status_text = [
                                                        'pending' => 'قيد الانتظار',
                                                        'confirmed' => 'مؤكد',
                                                        'completed' => 'مكتمل',
                                                        'cancelled' => 'ملغى',
                                                        'no-show' => 'لم يحضر'
                                                    ];
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_badge[$appointment['status']]; ?>">
                                                        <?php echo $status_text[$appointment['status']]; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if (!empty($appointment['staff_notes'])): ?>
                                                        <small class="text-muted"><?php echo $appointment['staff_notes']; ?></small>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info text-center">
                                <i class="fas fa-info-circle fa-2x mb-3"></i>
                                <p class="mb-0">لا توجد مواعيد قادمة</p>
                                <a href="appointments.php?action=add" class="btn btn-primary mt-2">
                                    <i class="fas fa-plus me-2"></i>حجز موعد جديد
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- المواعيد السابقة -->
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0"><i class="fas fa-history me-2"></i> المواعيد السابقة</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($previous_appointments->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>التاريخ</th>
                                            <th>الطبيب</th>
                                            <th>القسم</th>
                                            <th>الحالة</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($appointment = $previous_appointments->fetch_assoc()): ?>
                                            <tr>
                                                <td>
                                                    <i class="fas fa-calendar me-2"></i>
                                                    <?php echo date('d/m/Y', strtotime($appointment['appointment_date'])); ?>
                                                </td>
                                                <td><?php echo $appointment['doctor_name']; ?></td>
                                                <td>
                                                    <span class="badge bg-info"><?php echo $appointment['department_name']; ?></span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo $status_badge[$appointment['status']]; ?>">
                                                        <?php echo $status_text[$appointment['status']]; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info text-center mb-0">
                                <p class="mb-0">لا توجد مواعيد سابقة</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- الاستبيانات المتاحة -->
                <div class="card">
                    <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-poll me-2"></i> استبيانات رضا المرضى</h5>
                        <a href="surveys.php" class="btn btn-sm btn-dark">عرض الكل</a>
                    </div>
                    <div class="card-body">
                        <?php if ($active_surveys->num_rows > 0): ?>
                            <div class="row g-3">
                                <?php while ($survey = $active_surveys->fetch_assoc()): ?>
                                    <div class="col-md-4">
                                        <div class="card h-100 border-warning">
                                            <div class="card-body">
                                                <h6 class="card-title"><?php echo $survey['title']; ?></h6>
                                                <p class="card-text small text-muted"><?php echo $survey['description']; ?></p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-warning text-dark">
                                                        <i class="fas fa-question-circle me-1"></i>
                                                        <?php echo $survey['questions_count']; ?> أسئلة
                                                    </span>
                                                    <a href="surveys.php?survey_id=<?php echo $survey['id']; ?>" 
                                                       class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit me-1"></i>الرد الآن
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-success text-center mb-0">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <p class="mb-0">لا توجد استبيانات متاحة حالياً</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>