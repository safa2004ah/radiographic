<?php
require_once '../includes/config.php';

// التحقق من الجلسة والدور لضمان أن المستخدم مريض
if (!hasPermission('patient') || !checkPermission('view_my_medical_records')) {
    header('Location: dashboard.php');
    exit;
}

$conn = getDBConnection();
// ضبط ترميز الاتصال لضمان ظهور اللغة العربية بشكل صحيح
$conn->set_charset("utf8mb4");

$patient_id = $_SESSION['user_id'];

// جلب السجلات الطبية للمريض مع أسماء الأطباء وبيانات المريض من قاعدة البيانات مباشرة
$query = "SELECT 
            mr.*, 
            u_pat.full_name AS patient_name, 
            u_doc.full_name AS doctor_name, 
            d.name AS dept_name 
          FROM medical_records mr 
          INNER JOIN users u_pat ON mr.patient_id = u_pat.id 
          INNER JOIN users u_doc ON mr.doctor_id = u_doc.id 
          LEFT JOIN departments d ON u_doc.department_id = d.id
          WHERE mr.patient_id = ? 
          ORDER BY mr.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$records = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ملفي الطبي - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', sans-serif; }
        .main-content { margin-right: 16.66%; padding: 2rem; min-height: 100vh; }
        .record-card { border: none; border-radius: 15px; margin-bottom: 20px; transition: 0.3s; border-right: 5px solid #2c3e50; }
        .record-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; }
        .diag-box { background: #f8f9fa; border-radius: 10px; padding: 15px; border: 1px solid #e9ecef; }
        @media print { .no-print { display: none; } .main-content { margin: 0; width: 100%; } }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div> 

            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom no-print">
                    <h2 class="fw-bold text-dark"><i class="fas fa-notes-medical text-primary ms-2"></i> سجلاتي الطبية</h2>
                    <span class="badge bg-white text-dark shadow-sm p-2">إجمالي التقارير: <?php echo $records->num_rows; ?></span>
                </div>

                <div class="row">
                    <?php if($records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <div class="col-12">
                            <div class="card record-card shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h5 class="fw-bold text-primary mb-1"> <?php echo htmlspecialchars($row['doctor_name']); ?></h5>
                                            <span class="badge bg-info-subtle text-info border border-info"><?php echo htmlspecialchars($row['dept_name'] ?? 'قسم الأشعة'); ?></span>
                                        </div>
                                        <div class="text-start">
                                            <div class="small text-muted"><i class="far fa-calendar-alt ms-1"></i> تاريخ الزيارة: <?php echo date('Y-m-d', strtotime($row['created_at'])); ?></div>
                                        </div>
                                    </div>

                                    <div class="diag-box mb-3">
                                        <h6 class="fw-bold text-dark mb-2"><i class="fas fa-stethoscope ms-1"></i> التشخيص الطبي:</h6>
                                        <p class="mb-0 text-secondary" style="line-height: 1.7;">
                                            <?php echo nl2br(htmlspecialchars($row['diagnosis'])); ?>
                                        </p>
                                    </div>

                                    <div class="d-flex justify-content-end no-print">
                                        <button onclick='printMedicalReport(<?php echo json_encode($row, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' class="btn btn-outline-dark btn-sm px-4 shadow-sm">
                                            <i class="fas fa-print ms-1"></i> طباعة التقرير الطبي
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                            <p class="text-muted fs-5">لا توجد سجلات طبية متوفرة في ملفك حالياً.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function printMedicalReport(data) {
            const printWin = window.open('', '_blank', 'width=900,height=900');
            const createdDate = new Date(data.created_at).toLocaleDateString('ar-EG');
            
            // تم استبدال الاسم الثابت بـ data.patient_name لضمان الدقة
            printWin.document.write(`
                <!DOCTYPE html>
                <html dir="rtl">
                <head>
                    <meta charset="UTF-8">
                    <title>تقرير - ${data.patient_name}</title>
                    <style>
                        @page { size: A4; margin: 15mm; }
                        body { padding: 40px; font-family: 'Arial', sans-serif; line-height: 1.6; }
                        .header { text-align: center; border-bottom: 2px solid #000; margin-bottom: 30px; }
                        .content { margin-top: 20px; font-size: 18px; }
                        .footer { margin-top: 100px; text-align: left; }
                    </style>
                </head>
                <body>
                    <div class="report-container">
                        <div class="header">
                            <h1>مختبر الأشعة التخصصي</h1>
                            <p>تقرير طبي رسمي للنتائج التشخيصية</p>
                        </div>
                        <div class="patient-meta">
                            <div class="meta-item"><strong>اسم المريض:</strong> ${data.patient_name}</div>
                            <div class="meta-item"><strong>الرقم المرجعي:</strong> #REC-${data.id}</div>
                            <div class="meta-item"><strong>الطبيب المعالج:</strong> ${data.doctor_name}</div>
                            <div class="meta-item"><strong>تاريخ الفحص:</strong> ${createdDate}</div>
                            <div class="meta-item"><strong>القسم:</strong> ${data.dept_name || 'الأشعة العامة'}</div>
                        </div>
                        <div class="diagnosis-section">
                            <div class="diagnosis-title">التقرير الفني والتشخيص:</div>
                            <div class="diagnosis-text">${data.diagnosis}</div>
                        </div>
                        <div class="footer">
                            <div class="signatures">
                                <div><p>ختم المركز</p><br>__________</div>
                                <div style="text-align: left;"><p>توقيع  ${data.doctor_name}</p><br>__________</div>
                            </div>
                            <div style="text-align: center; margin-top: 30px; color: #888; font-size: 12px;">
                                هذا التقرير مستخرج آلياً من النظام الإلكتروني ولا يعتد به بدون الأختام الرسمية.
                            </div>
                        </div>
                    </div>
                    <script>
                        window.onload = function() { 
                            window.print(); 
                            setTimeout(function() { window.close(); }, 500);
                        };
                    <\/script>
                </body>
                </html>
            `);
            printWin.document.close();
        }
    </script>
</body>
</html>