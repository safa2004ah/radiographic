<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar-wrapper d-flex flex-column flex-shrink-0 text-white shadow-sm" style="width: 100%; height: 100vh; background: linear-gradient(180deg, #2c3e50 0%, #000000 100%);">
    <div class="sidebar-header text-center p-3">
        <div class="bg-white rounded-circle d-inline-block p-3 mb-2 shadow-sm">
            <i class="fas fa-user-injured fa-3x text-primary"></i>
        </div>
        <h5 class="fw-bold mb-0 text-truncate px-2"><?php echo $_SESSION['full_name'] ?? 'المريض'; ?></h5>
        <small class="opacity-75">بوابة المريض الرقمية</small>
    </div>
    
    <hr class="mx-3 opacity-25">
    
    <div class="sidebar-scroll-content flex-grow-1 overflow-auto px-3">
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item mb-2">
                <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active bg-primary shadow' : 'text-white opacity-75 hover-opacity'; ?>">
                    <i class="fas fa-th-large ms-2"></i> لوحة التحكم
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="appointments.php" class="nav-link <?php echo $current_page == 'appointments.php' ? 'active bg-primary shadow' : 'text-white opacity-75 hover-opacity'; ?>">
                    <i class="fas fa-calendar-alt ms-2"></i> مواعيدي
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="medical_records.php" class="nav-link <?php echo $current_page == 'medical_records.php' ? 'active bg-primary shadow' : 'text-white opacity-75 hover-opacity'; ?>">
                    <i class="fas fa-file-medical ms-2"></i> سجلاتي الطبية
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="surveys.php" class="nav-link <?php echo ($current_page == 'surveys.php' || $current_page == 'survey_form.php') ? 'active bg-primary shadow' : 'text-white opacity-75 hover-opacity'; ?>">
                    <i class="fas fa-poll ms-2"></i> الاستبيانات
                </a>
            </li>
        </ul>
        
        <hr class="opacity-25 mt-3">
        
        <small class="text-uppercase opacity-50 px-3 mb-2 d-block" style="font-size: 0.7rem;">الإعدادات الشخصية</small>
        
        <ul class="nav nav-pills flex-column mb-4">
            <li class="nav-item mb-2">
                <a href="../profile.php" class="nav-link text-white opacity-75 hover-opacity">
                    <i class="fas fa-user-circle ms-2"></i> الملف الشخصي
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="../change_password.php" class="nav-link text-white opacity-75 hover-opacity">
                    <i class="fas fa-key ms-2 text-warning"></i> تغيير كلمة المرور
                </a>
            </li>
            <li class="nav-item">
            <a href="../logout.php" class="nav-link text-danger fw-bold hover-opacity">
                <i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج
            </a>
        </li>
        </ul>
    </div>
    
</div>

<style>
    /* تفعيل خاصية التمرير */
    .sidebar-scroll-content {
        scrollbar-width: thin;
        scrollbar-color: rgba(255,255,255,0.2) transparent;
    }
    
    .sidebar-scroll-content::-webkit-scrollbar {
        width: 4px;
    }
    
    .sidebar-scroll-content::-webkit-scrollbar-thumb {
        background-color: rgba(255,255,255,0.2);
        border-radius: 10px;
    }

    .hover-opacity:hover { 
        opacity: 1 !important; 
        background: rgba(255,255,255,0.1); 
        transform: translateX(-5px);
    }
    
    .hover-danger:hover {
        background: rgba(220, 53, 69, 0.1);
        color: #ff4d4d !important;
    }

    .nav-link { 
        transition: all 0.3s ease; 
        border-radius: 10px !important; 
        padding: 12px 15px !important;
        display: flex;
        align-items: center;
    }

    .sidebar-wrapper {
        position: sticky;
        top: 0;
        overflow: hidden;
    }
</style>