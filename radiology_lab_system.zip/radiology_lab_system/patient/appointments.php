<?php
require_once '../includes/config.php';
if (!hasPermission('patient')) {
    header('Location: ../login.php');
    exit;
}
$conn = getDBConnection();
$user = getCurrentUser();
$patient_id = $_SESSION['user_id'];

// جلب المواعيد مع أسماء الأطباء والأقسام
$query = "SELECT a.*, d.full_name as doctor_name, dept.name as dept_name
FROM appointments a
JOIN users d ON a.doctor_id = d.id
JOIN departments dept ON a.department_id = dept.id
WHERE a.patient_id = ?
ORDER BY a.appointment_date DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مواعيدي - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .main-content { margin-right: 16.66%; padding: 30px; }
        .sidebar-fixed { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .status-badge { border-radius: 20px; padding: 5px 15px; font-size: 0.8rem; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h2 class="fw-bold text-dark">
                        <i class="fas fa-calendar-alt text-primary ms-2"></i> جدول مواعيدي
                    </h2>
                    <a href="book_appointment.php" class="btn btn-primary shadow-sm">
                        <i class="fas fa-plus ms-1"></i> حجز موعد جديد
                    </a>
                </div>

                <?php if ($result && $result->num_rows > 0): ?>
                    <div class="card p-3">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>الطبيب والمركز</th>
                                        <th>التاريخ والوقت</th>
                                        <th>الحالة</th>
                                        <th>ملاحظات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div class="fw-bold text-primary"><?= htmlspecialchars($row['doctor_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($row['dept_name']) ?></small>
                                            </td>
                                            <td>
                                                <div class="mb-1">
                                                    <i class="far fa-calendar-check ms-1"></i> 
                                                    <?= date('d/m/Y', strtotime($row['appointment_date'])) ?>
                                                </div>
                                                <small class="badge bg-light text-dark border">
                                                    <i class="far fa-clock ms-1"></i> 
                                                    <?= date('h:i A', strtotime($row['appointment_time'])) ?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php
                                                $status = $row['status'];
                                                $class = 'bg-secondary';
                                                $status_text = $status;
                                                
                                                if($status == 'confirmed') { $class = 'bg-success'; $status_text = 'مؤكد'; }
                                                if($status == 'pending') { $class = 'bg-warning text-dark'; $status_text = 'قيد الانتظار'; }
                                                if($status == 'cancelled') { $class = 'bg-danger'; $status_text = 'ملغى'; }
                                                if($status == 'completed') { $class = 'bg-secondary'; $status_text = 'مكتمل'; }
                                                ?>
                                                <span class="badge status-badge <?= $class ?>"><?= $status_text ?></span>
                                            </td>
                                            <td><small class="text-muted"><?= $row['notes'] ?: '-' ?></small></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card p-5 text-center">
                        <i class="fas fa-calendar-times fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد مواعيد مسجلة</h4>
                        <p class="text-muted">يمكنك حجز موعد جديد بالنقر على زر الحجز</p>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
</body>
</html>