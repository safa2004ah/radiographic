<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!hasPermission('patient')) {
    header('Location: ../login.php');
    exit;
}

$conn = getDBConnection();
$user = getCurrentUser();
$patient_id = $user['id'];

// معالجة إرسال الاستبيان
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_survey'])) {
    $survey_id = $_POST['survey_id'];
    
    // حفظ الإجابات
    $success_count = 0;
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question_') === 0) {
            $question_id = str_replace('question_', '', $key);
            
            // التحقق من أن السؤال يتبع للاستبيان
            $check_query = "SELECT id FROM survey_questions WHERE id = ? AND survey_id = ?";
            $stmt = $conn->prepare($check_query);
            $stmt->bind_param("ii", $question_id, $survey_id);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows > 0) {
                $answer = is_array($value) ? implode(', ', $value) : $value;
                
                $insert_query = "INSERT INTO survey_responses (survey_id, patient_id, question_id, answer) 
                                 VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_query);
                $stmt->bind_param("iiis", $survey_id, $patient_id, $question_id, $answer);
                $stmt->execute();
                $success_count++;
            }
        }
    }
    
    if ($success_count > 0) {
        $success = 'تم إرسال استجابتك بنجاح. شكراً لك!';
    } else {
        $error = 'لم يتم إرسال أي إجابات';
    }
}

// جلب الاستبيانات النشطة
$active_surveys_query = "SELECT s.*, COUNT(DISTINCT sq.id) as questions_count
                         FROM surveys s
                         LEFT JOIN survey_questions sq ON s.id = sq.survey_id
                         WHERE s.status = 'active'
                         AND s.id NOT IN (
                             SELECT DISTINCT survey_id FROM survey_responses WHERE patient_id = ?
                         )
                         GROUP BY s.id
                         ORDER BY s.created_at DESC";

$stmt = $conn->prepare($active_surveys_query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$active_surveys = $stmt->get_result();

// جلب الاستبيانات التي أجاب عليها المريض
$completed_surveys_query = "SELECT s.*, COUNT(DISTINCT sr.id) as responses_count, MAX(sr.submitted_at) as last_submission
                            FROM surveys s
                            JOIN survey_responses sr ON s.id = sr.survey_id
                            WHERE sr.patient_id = ?
                            GROUP BY s.id
                            ORDER BY last_submission DESC
                            LIMIT 5";

$stmt = $conn->prepare($completed_surveys_query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$completed_surveys = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>استبيانات رضا المرضى - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .main-content { margin-right: 16.66%; padding: 30px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">استبيانات رضا المرضى</h1>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- الاستبيانات النشطة -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-poll me-2"></i>استبيانات متاحة</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($active_surveys->num_rows > 0): ?>
                            <div class="row g-3">
                                <?php while ($survey = $active_surveys->fetch_assoc()): ?>
                                    <div class="col-md-6">
                                        <div class="card h-100 border-primary">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $survey['title']; ?></h5>
                                                <p class="card-text text-muted"><?php echo $survey['description']; ?></p>
                                                
                                                <div class="d-flex justify-content-between align-items-center mt-3">
                                                    <span class="badge bg-primary">
                                                        <i class="fas fa-question-circle me-1"></i>
                                                        <?php echo $survey['questions_count']; ?> أسئلة
                                                    </span>
                                                    
                                                    <button class="btn btn-primary" 
                                                            onclick="showSurvey(<?php echo $survey['id']; ?>, '<?php echo addslashes($survey['title']); ?>')">
                                                        <i class="fas fa-edit me-1"></i>الرد الآن
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-success text-center mb-0">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <p class="mb-0">لا توجد استبيانات متاحة حالياً</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- الاستبيانات المكتملة -->
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-check-circle me-2"></i>استبيانات أجبت عليها</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($completed_surveys->num_rows > 0): ?>
                            <div class="list-group">
                                <?php while ($survey = $completed_surveys->fetch_assoc()): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo $survey['title']; ?></h6>
                                                <p class="mb-1 text-muted small">
                                                    <i class="fas fa-check me-2"></i>
                                                    أجبت على <?php echo $survey['responses_count']; ?> أسئلة
                                                </p>
                                            </div>
                                            <span class="badge bg-success align-self-center">
                                                <i class="fas fa-check"></i>
                                            </span>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info text-center mb-0">
                                <p class="mb-0">لم تجب على أي استبيان بعد</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نافذة الاستبيان -->
    <div class="modal fade" id="surveyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="surveyModalTitle">استبيان</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="" id="surveyForm">
                    <div class="modal-body" id="surveyContent">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i>إرسال الاستبيان
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function showSurvey(surveyId, title) {
            fetchSurveyQuestions(surveyId, title);
        }
        
        function fetchSurveyQuestions(surveyId, title) {
            
            document.getElementById('surveyModalTitle').textContent = title;
            document.getElementById('surveyForm').action = 'surveys.php';
            
            // إضافة حقل معرف الاستبيان
            let input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'survey_id';
            input.value = surveyId;
            document.getElementById('surveyForm').appendChild(input);
            
            // إضافة زر الإرسال
            let submitInput = document.createElement('input');
            submitInput.type = 'hidden';
            submitInput.name = 'submit_survey';
            submitInput.value = '1';
            document.getElementById('surveyForm').appendChild(submitInput);
            
            loadSurveyQuestions(surveyId);
        }
        
        function loadSurveyQuestions(surveyId) {
            const content = document.getElementById('surveyContent');
            content.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-spinner fa-spin me-2"></i>
                    جاري تحميل الأسئلة...
                </div>
            `;
            
            // إعادة توجيه للصفحة نفسها مع معرف الاستبيان
            window.location.href = 'survey_form.php?survey_id=' + surveyId;
        }
    </script>
</body>
</html>