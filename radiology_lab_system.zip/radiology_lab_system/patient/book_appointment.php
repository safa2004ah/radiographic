<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات (المريض فقط)
if (!isLoggedIn() || $_SESSION['user_role'] != 'patient') {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة إضافة الموعد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $doctor_id = $_POST['doctor_id'];
    $department_id = $_POST['department_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $notes = $_POST['notes'] ?? '';
    
    $patient_id = $_SESSION['user_id'];
    
    $query = "INSERT INTO appointments (patient_id, doctor_id, department_id, appointment_date, appointment_time, notes, status)
              VALUES (?, ?, ?, ?, ?, ?, 'pending')";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiisss", $patient_id, $doctor_id, $department_id, $appointment_date, $appointment_time, $notes);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = 'تم حجز الموعد بنجاح. سيتم مراجعته من قبل الموظف.';
        header('Location: appointments.php');
        exit;
    } else {
        $error = 'حدث خطأ أثناء حجز الموعد. الرجاء المحاولة مرة أخرى.';
    }
}

// جلب بيانات المريض الحالي
$patient_query = "SELECT id, full_name, phone, email FROM users WHERE id = ? AND role = 'patient'";
$stmt = $conn->prepare($patient_query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

// جلب الأطباء
$doctors_query = "SELECT id, full_name, specialization FROM users WHERE role = 'doctor' AND status = 'active' ORDER BY full_name";
$doctors = $conn->query($doctors_query);

// جلب الأقسام
$departments_query = "SELECT id, name FROM departments WHERE status = 'active' ORDER BY name";
$departments = $conn->query($departments_query);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حجز موعد جديد - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .main-content { margin-right: 16.66%; padding: 30px; }
        .sidebar-fixed { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .header-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 15px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <!-- رأس الصفحة -->
                <div class="card header-card mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="mb-1"><i class="fas fa-calendar-plus me-2"></i> حجز موعد جديد</h2>
                                <p class="mb-0 opacity-75">املأ النموذج لحجز موعد مع الطبيب</p>
                            </div>
                            <a href="appointments.php" class="btn btn-light">
                                <i class="fas fa-arrow-right me-1"></i> العودة لمواعيدي
                            </a>
                        </div>
                    </div>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- نموذج الحجز -->
                <div class="card p-4">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row g-4">
                            <!-- معلومات المريض (تلقائية) -->
                            <div class="col-md-12">
                                <div class="card bg-light border-0">
                                    <div class="card-body">
                                        <h5 class="card-title mb-3">
                                            <i class="fas fa-user-injured text-primary me-2"></i>
                                            معلومات المريض
                                        </h5>
                                        <div class="row g-3">
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">اسم المريض</label>
                                                <input type="text" class="form-control" 
                                                       value="<?= htmlspecialchars($patient['full_name']) ?>" 
                                                       readonly>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">رقم الهاتف</label>
                                                <input type="text" class="form-control" 
                                                       value="<?= htmlspecialchars($patient['phone']) ?>" 
                                                       readonly>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">البريد الإلكتروني</label>
                                                <input type="text" class="form-control" 
                                                       value="<?= htmlspecialchars($patient['email']) ?>" 
                                                       readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- اختيار الطبيب -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-user-md me-2"></i>
                                    الطبيب <span class="text-danger">*</span>
                                </label>
                                <select class="form-select form-select-lg" name="doctor_id" id="doctorId" required onchange="updateDoctorInfo()">
                                    <option value="">اختر الطبيب</option>
                                    <?php mysqli_data_seek($doctors, 0); ?>
                                    <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                        <option value="<?= $doctor['id'] ?>" 
                                                data-specialization="<?= htmlspecialchars($doctor['specialization']) ?>">
                                            <?= htmlspecialchars($doctor['full_name']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                                <div id="doctorInfo" class="mt-2 text-muted small"></div>
                            </div>

                            <!-- اختيار القسم -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-hospital me-2"></i>
                                    القسم <span class="text-danger">*</span>
                                </label>
                                <select class="form-select form-select-lg" name="department_id" id="departmentId" required>
                                    <option value="">اختر القسم</option>
                                    <?php mysqli_data_seek($departments, 0); ?>
                                    <?php while ($dept = $departments->fetch_assoc()): ?>
                                        <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <!-- تاريخ الموعد -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold">
                                    <i class="far fa-calendar-alt me-2"></i>
                                    تاريخ الموعد <span class="text-danger">*</span>
                                </label>
                                <input type="date" class="form-control form-control-lg" 
                                       name="appointment_date" id="appointmentDate" 
                                       required min="<?= date('Y-m-d') ?>">
                            </div>

                            <!-- وقت الموعد -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold">
                                    <i class="far fa-clock me-2"></i>
                                    وقت الموعد <span class="text-danger">*</span>
                                </label>
                                <input type="time" class="form-control form-control-lg" 
                                       name="appointment_time" id="appointmentTime" 
                                       required min="08:00" max="18:00" step="1800">
                            </div>

                            <!-- ملاحظات -->
                            <div class="col-md-12">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-sticky-note me-2"></i>
                                    ملاحظات (اختياري)
                                </label>
                                <textarea class="form-control form-control-lg" 
                                          name="notes" id="notes" 
                                          rows="3" placeholder="اكتب أي ملاحظات أو أعراض إضافية..."></textarea>
                            </div>

                            <!-- معلومات إضافية -->
                            <div class="col-md-12">
                                <div class="alert alert-info mb-0">
                                    <i class="fas fa-info-circle me-2"></i>
                                    <strong>ملاحظة:</strong> سيتم مراجعة طلبك من قبل الموظف وسيتم إعلامك بتأكيد الموعد عبر البريد الإلكتروني أو الهاتف.
                                </div>
                            </div>

                            <!-- أزرار الإرسال -->
                            <div class="col-md-12">
                                <div class="d-flex justify-content-between gap-3">
                                    <a href="appointments.php" class="btn btn-secondary btn-lg px-5">
                                        <i class="fas fa-times me-2"></i> إلغاء
                                    </a>
                                    <button type="submit" class="btn btn-primary btn-lg px-5">
                                        <i class="fas fa-calendar-check me-2"></i> حجز الموعد
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحديث معلومات الطبيب عند الاختيار
        function updateDoctorInfo() {
            const select = document.getElementById('doctorId');
            const option = select.options[select.selectedIndex];
            const specialization = option.getAttribute('data-specialization');
            
            const infoDiv = document.getElementById('doctorInfo');
            if (specialization) {
                infoDiv.innerHTML = '<i class="fas fa-user-md me-2"></i> التخصص: <strong>' + specialization + '</strong>';
            } else {
                infoDiv.innerHTML = '';
            }
        }

        // منع اختيار تاريخ سابق
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('appointmentDate').setAttribute('min', today);
        });
    </script>
</body>
</html>