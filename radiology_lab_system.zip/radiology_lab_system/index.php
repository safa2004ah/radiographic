<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - الصفحة الرئيسية</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1a237e; --secondary-color: #0d47a1; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #f8f9fa; }
        .hero-section {
            background: linear-gradient(rgba(26, 35, 126, 0.9), rgba(13, 71, 161, 0.8)), url('assets/img/hero-bg.jpg') center/cover;
            color: white; padding: 100px 0; border-radius: 0 0 50px 50px;
        }
        .feature-card { border: none; border-radius: 20px; transition: transform 0.3s; }
        .feature-card:hover { transform: translateY(-10px); }
        .btn-primary { background-color: var(--primary-color); border: none; padding: 12px 30px; border-radius: 30px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#"><i class="fas fa-microscope me-2"></i><?php echo SITE_NAME; ?></a>
            <div class="d-flex">
                <a href="login.php" class="btn btn-outline-primary rounded-pill px-4 me-2">تسجيل الدخول</a>
                <a href="register.php" class="btn btn-primary rounded-pill px-4">إنشاء حساب</a>
            </div>
        </div>
    </nav>

    <header class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4">نظام إدارة الأشعة الذكي</h1>
            <p class="lead mb-5">دقة في التشخيص، سرعة في الإنجاز، ورعاية متميزة لمرضانا باستخدام تقنيات الذكاء الصناعي.</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="login.php" class="btn btn-light btn-lg px-5 rounded-pill shadow">ابدأ الآن</a>
                <a href="#features" class="btn btn-outline-light btn-lg px-5 rounded-pill">تعرف علينا</a>
            </div>
        </div>
    </header>

    <section id="features" class="py-5">
        <div class="container py-5">
            <div class="row g-4 text-center">
                <div class="col-md-4">
                    <div class="card feature-card shadow-sm p-4 h-100">
                        <div class="mb-3 text-primary"><i class="fas fa-x-ray fa-3x"></i></div>
                        <h4>نتائج فورية</h4>
                        <p class="text-muted">الوصول السريع لصور الأشعة والتقارير الطبية في أي وقت.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card shadow-sm p-4 h-100">
                        <div class="mb-3 text-success"><i class="fas fa-brain fa-3x"></i></div>
                        <h4>تنبؤ ذكي</h4>
                        <p class="text-muted">استخدام نماذج AI للتنبؤ بالحالات وضمان دقة التشخيص.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card shadow-sm p-4 h-100">
                        <div class="mb-3 text-info"><i class="fas fa-user-shield fa-3x"></i></div>
                        <h4>خصوصية تامة</h4>
                        <p class="text-muted">تشفير كامل لبيانات المرضى وسجلاتهم الطبية وفق المعايير العالمية.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white py-4 text-center">
        <p class="mb-0">© 2026 <?php echo SITE_NAME; ?>. جميع الحقوق محفوظة.</p>
    </footer>
</body>
</html>