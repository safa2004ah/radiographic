<?php
require_once 'includes/config.php';

// تدمير الجلسة
session_destroy();

// إعادة التوجيه لصفحة تسجيل الدخول
header('Location: index.php');
exit;
?>