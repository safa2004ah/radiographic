<?php
require_once 'includes/config.php';

// إعادة التوجيه إذا كان المستخدم مسجلاً دخوله بالفعل
if (isLoggedIn()) {
    $user = getCurrentUser();
    header("Location: " . $user['role'] . "/dashboard.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ? AND status = 'active'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            
            // تحديث وقت آخر تسجيل دخول
            $conn->query("UPDATE users SET last_login = NOW() WHERE id = " . $user['id']);
            
            header("Location: " . $user['role'] . "/dashboard.php");
            exit;
        } else {
            $error = 'كلمة المرور غير صحيحة';
        }
    } else {
        $error = 'اسم المستخدم غير موجود أو الحساب معطل';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, sans-serif;
        }
        .login-card {
            border: none;
            border-radius: 25px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 450px;
            width: 100%;
            background: white;
        }
        .login-header {
            background-color: #1a237e;
            color: white;
            padding: 40px;
            text-align: center;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px;
            border: 1px solid #eee;
        }
        .input-group-text {
            border-radius: 0 10px 10px 0;
            background: white;
            border: 1px solid #eee;
            cursor: pointer;
        }
        .btn-login {
            background-color: #1a237e;
            color: white;
            border-radius: 10px;
            padding: 12px;
            width: 100%;
            transition: 0.3s;
            border: none;
        }
        .btn-login:hover {
            background-color: #0d47a1;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header">
        <i class="fas fa-user-shield fa-3x mb-3"></i>
        <h4 class="fw-bold">تسجيل الدخول</h4>
        <p class="small opacity-75 mb-0">نظام إدارة مخبر الأشعة</p>
    </div>
    <div class="p-4 p-md-5">
        <?php if ($error): ?>
            <div class="alert alert-danger small rounded-3"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label small fw-bold">اسم المستخدم</label>
                <input type="text" name="username" class="form-control" placeholder="أدخل اسم المستخدم" required>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-bold">كلمة المرور</label>
                <div class="input-group">
                    <input type="password" name="password" id="passwordField" class="form-control border-start-0" placeholder="••••••••" required>
                    <span class="input-group-text border-end-0" onclick="togglePassword()">
                        <i class="fas fa-eye text-muted" id="eyeIcon"></i>
                    </span>
                </div>
            </div>
            <button type="submit" class="btn btn-login fw-bold shadow-sm">دخول</button>
            <div class="mt-4 text-center">
                <small class="text-muted">ليس لديك حساب؟ <a href="register.php" class="text-primary text-decoration-none fw-bold">سجل حساب مريض</a></small>
            </div>
        </form>
    </div>
</div>

<script>
function togglePassword() {
    const field = document.getElementById('passwordField');
    const icon = document.getElementById('eyeIcon');
    if (field.type === "password") {
        field.type = "text";
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        field.type = "password";
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}
</script>
</body>
</html>