<?php
require_once '../includes/config.php';

// التحقق من تسجيل الدخول وصلاحيات المدير
if (!isLoggedIn() || $_SESSION['user_role'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

// تعريف المتغير $user لضمان استقرار السايد بار
$user = getCurrentUser();
$conn = getDBConnection();

// جلب الاستبيانات مع عدد الردود لكل منها
$surveys = $conn->query("SELECT s.*, 
                            (SELECT COUNT(DISTINCT patient_id) FROM survey_responses WHERE survey_id = s.id) as response_count 
                         FROM surveys s 
                         ORDER BY s.id DESC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الاستبيانات - <?= htmlspecialchars($user['full_name'] ?? '') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        .sidebar { min-height: 100vh; position: sticky; top: 0; }
        .main-content { padding: 2rem; width: 100%; }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); transition: 0.3s; }
        .card-custom:hover { transform: translateY(-5px); }
        @media (max-width: 991.98px) { .sidebar-col { display: none; } }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
                <div class="d-flex justify-content-between align-items-center mb-5 pb-3 border-bottom text-right">
                    <div>
                        <h2 class="fw-bold text-dark mb-1">نظام تحليل الاستبيانات</h2>
                        <p class="text-muted mb-0">مراجعة وتحليل آراء المرضى حول الخدمات المقدمة</p>
                    </div>
                    <span class="badge bg-primary rounded-pill px-4 py-2 shadow-sm">
                        إجمالي الاستبيانات: <?= $surveys->num_rows ?>
                    </span>
                </div>

                <div class="row g-4">
                    <?php if ($surveys && $surveys->num_rows > 0): ?>
                        <?php while($s = $surveys->fetch_assoc()): ?>
                            <div class="col-md-6">
                                <div class="card card-custom p-4 bg-white">
                                    <div class="d-flex justify-content-between mb-3 align-items-start">
                                        <div class="text-right">
                                            <h5 class="fw-bold text-primary mb-1"><?= htmlspecialchars($s['title'] ?? '') ?></h5>
                                            <small class="text-muted">
                                                <i class="far fa-calendar-alt ms-1"></i> 
                                                تم الإنشاء: <?= date('Y-m-d', strtotime($s['created_at'])) ?>
                                            </small>
                                        </div>
                                        <span class="badge bg-info bg-opacity-10 text-info rounded-pill px-3 py-2">
                                            <?= $s['response_count'] ?> رد مستلم
                                        </span>
                                    </div>
                                    <p class="text-secondary small mb-4 text-right"><?= htmlspecialchars($s['description'] ?? '') ?></p>
                                    <div class="d-flex gap-2 justify-content-end">
                                        <a href="survey_responses.php?survey_id=<?= $s['id'] ?>" class="btn btn-primary rounded-pill px-4 shadow-sm">
                                            <i class="fas fa-list-ul ms-2"></i> عرض الردود التفصيلية
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-poll-h fa-5x text-light mb-3"></i>
                            <h4 class="text-muted">لا توجد استبيانات نشطة حالياً</h4>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>