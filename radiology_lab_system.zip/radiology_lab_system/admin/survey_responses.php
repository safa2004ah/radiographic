<?php
require_once '../includes/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// التحقق من الصلاحيات
if (!checkPermission('manage_surveys')) {
    $_SESSION['error_message'] = 'ليس لديك صلاحية الوصول لهذه الصفحة.';
    header('Location: ../dashboard.php');
    exit();
}

// التحقق من وجود survey_id
if (!isset($_GET['survey_id'])) {
    $_SESSION['error_message'] = 'بيانات غير صحيحة.';
    header('Location: surveys.php');
    exit();
}

$survey_id = (int)$_GET['survey_id'];
$conn = getDBConnection();

// جلب معلومات الاستبيان
$survey_query = "SELECT * FROM surveys WHERE id = ?";
$stmt = $conn->prepare($survey_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$survey = $stmt->get_result()->fetch_assoc();

if (!$survey) {
    $_SESSION['error_message'] = 'الاستبيان غير موجود.';
    header('Location: surveys.php');
    exit();
}

// جلب جميع المرضى الذين أجابوا على هذا الاستبيان (بدون id_number)
$patients_query = "SELECT DISTINCT 
                        u.id as patient_id,
                        u.full_name as name,
                        u.phone,
                        COUNT(sr.id) as answer_count,
                        MAX(sr.submitted_at) as last_response
                    FROM survey_responses sr
                    JOIN users u ON sr.patient_id = u.id
                    WHERE sr.survey_id = ? AND u.role = 'patient'
                    GROUP BY u.id, u.full_name, u.phone
                    ORDER BY last_response DESC";

$stmt = $conn->prepare($patients_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$patients = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ردود الاستبيان - <?= htmlspecialchars($survey['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; }
        .sidebar { min-height: 100vh; position: sticky; top: 0; }
        .main-content { padding: 2rem; width: 100%; }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); transition: 0.3s; }
        .card-custom:hover { transform: translateY(-5px); }
        .patient-card { border-left: 4px solid #3498db; }
        @media (max-width: 991.98px) { .sidebar-col { display: none; } }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 class="fw-bold text-dark mb-1">
                            <i class="fas fa-poll me-2"></i>
                            <?= htmlspecialchars($survey['title']) ?>
                        </h2>
                        <p class="text-muted mb-0"><?= htmlspecialchars($survey['description']) ?></p>
                    </div>
                    <a href="surveys.php" class="btn btn-secondary rounded-pill px-4">
                        <i class="fas fa-arrow-right ms-2"></i> العودة لقائمة الاستبيانات
                    </a>
                </div>

                <div class="row g-4">
                    <?php if ($patients && $patients->num_rows > 0): ?>
                        <?php while($patient = $patients->fetch_assoc()): ?>
                            <div class="col-md-6">
                                <div class="card card-custom patient-card p-4 bg-white">
                                    <div class="d-flex justify-content-between mb-3 align-items-start">
                                        <div class="text-right">
                                            <h5 class="fw-bold text-primary mb-1">
                                                <i class="fas fa-user me-2"></i>
                                                <?= htmlspecialchars($patient['name']) ?>
                                            </h5>
                                            <?php if ($patient['phone']): ?>
                                                <small class="text-muted d-block mt-1">
                                                    <i class="fas fa-phone me-1"></i>
                                                    <?= htmlspecialchars($patient['phone']) ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                        <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3 py-2">
                                            <?= $patient['answer_count'] ?> إجابة
                                        </span>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                        <small class="text-muted">
                                            <i class="far fa-clock me-1"></i>
                                            آخر رد: <?= date('Y-m-d H:i', strtotime($patient['last_response'])) ?>
                                        </small>
                                        <a href="survey_details.php?survey_id=<?= $survey_id ?>&patient_id=<?= $patient['patient_id'] ?>" 
                                           class="btn btn-primary btn-sm rounded-pill px-4">
                                            <i class="fas fa-eye me-1"></i> عرض التفاصيل
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-inbox fa-5x text-light mb-3"></i>
                            <h4 class="text-muted">لا توجد ردود على هذا الاستبيان بعد</h4>
                            <p class="text-muted mt-2">لم يقم أي مريض بالإجابة على هذا الاستبيان</p>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>