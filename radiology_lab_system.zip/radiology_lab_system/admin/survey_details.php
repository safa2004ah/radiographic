<?php
require_once '../includes/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// التحقق من الصلاحيات
if (!checkPermission('manage_surveys')) {
    $_SESSION['error_message'] = 'ليس لديك صلاحية الوصول لهذه الصفحة.';
    header('Location: ../dashboard.php');
    exit();
}

// التحقق من وجود المعاملات المطلوبة
if (!isset($_GET['survey_id']) || !isset($_GET['patient_id'])) {
    $_SESSION['error_message'] = 'بيانات غير صحيحة.';
    header('Location: surveys.php');
    exit();
}

$survey_id = (int)$_GET['survey_id'];
$patient_id = (int)$_GET['patient_id'];

$conn = getDBConnection();

// جلب معلومات الاستبيان والردود (بدون id_number)
$info_query = "SELECT 
                    s.title as survey_title,
                    u.full_name as patient_name
                FROM surveys s
                JOIN users u ON u.id = ?
                WHERE s.id = ? AND u.role = 'patient'";

$stmt = $conn->prepare($info_query);
$stmt->bind_param("ii", $patient_id, $survey_id);
$stmt->execute();
$info_result = $stmt->get_result()->fetch_assoc();

if (!$info_result) {
    $_SESSION['error_message'] = 'تعذر العثور على البيانات المطلوبة.';
    header('Location: surveys.php');
    exit();
}

// جلب الأسئلة مع الإجابات
$responses_query = "SELECT 
                        sq.question as question_text, 
                        sq.question_type, 
                        sr.answer, 
                        sr.submitted_at
                    FROM survey_responses sr
                    JOIN survey_questions sq ON sr.question_id = sq.id
                    WHERE sr.survey_id = ? AND sr.patient_id = ?
                    ORDER BY sq.order_num ASC, sq.id ASC";

$stmt = $conn->prepare($responses_query);
$stmt->bind_param("ii", $survey_id, $patient_id);
$stmt->execute();
$responses = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل إجابات المريض - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .container { max-width: 1000px; }
        .info-card { border-left: 4px solid #3498db; }
        .response-item { border-left: 3px solid #e74c3c; background-color: #fff; }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="card mb-4 info-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="mb-0 text-primary">
                        <i class="fas fa-file-alt me-2"></i>
                        تفاصيل إجابات المريض
                    </h3>
                    <div class="d-flex gap-2">
                        <a href="survey_responses.php?survey_id=<?= $survey_id ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-arrow-right me-1"></i> عرض جميع الردود
                        </a>
                        <a href="surveys.php" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-home me-1"></i> العودة للاستبيانات
                        </a>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <p class="mb-1"><strong>اسم الاستبيان:</strong></p>
                        <p class="text-muted"><?= htmlspecialchars($info_result['survey_title']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-1"><strong>اسم المريض:</strong></p>
                        <p class="text-muted"><?= htmlspecialchars($info_result['patient_name']) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-list-ul me-2"></i>
                    مراجعة الردود
                </h5>
            </div>
            <div class="card-body">
                <?php if ($responses->num_rows > 0): ?>
                    <?php while ($row = $responses->fetch_assoc()): ?>
                        <div class="response-item p-3 mb-3 rounded">
                            <h6 class="text-primary mb-2">
                                <i class="fas fa-question-circle me-2"></i>
                                السؤال:
                            </h6>
                            <p class="mb-2"><?= htmlspecialchars($row['question_text']) ?></p>
                            
                            <h6 class="text-success mb-2">
                                <i class="fas fa-reply me-2"></i>
                                الإجابة:
                            </h6>
                            <?php if ($row['question_type'] === 'rating'): ?>
                                <?php
                                $rating = (int)$row['answer'];
                                $stars = str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
                                ?>
                                <p class="text-warning h5 mb-0">
                                    <?= $stars ?> (<?= $rating ?> / 5)
                                </p>
                            <?php else: ?>
                                <p class="mb-0"><?= htmlspecialchars($row['answer'] ?: 'لا يوجد رد') ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                    
                    <div class="alert alert-info mt-3">
                        <i class="fas fa-clock me-2"></i>
                        <strong>تاريخ الإرسال:</strong> 
                        <?php 
                        $responses->data_seek(0);
                        $first_row = $responses->fetch_assoc();
                        echo $first_row ? date('Y-m-d H:i:s', strtotime($first_row['submitted_at'])) : 'غير متوفر'; 
                        ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                        <h5 class="text-muted">لا توجد إجابات مسجلة لهذا المريض.</h5>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>