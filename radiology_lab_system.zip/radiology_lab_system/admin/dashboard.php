<?php
require_once '../includes/config.php';
require_once '../includes/ai_prediction.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_users')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$ai = new AIPrediction();

// 1. جلب الإحصائيات السريعة
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_patients = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'patient'")->fetch_assoc()['count'];
$total_doctors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'doctor'")->fetch_assoc()['count'];
$total_appointments = $conn->query("SELECT COUNT(*) as count FROM appointments")->fetch_assoc()['count'];

// 2. إصلاح الخطأ: جلب مصفوفة الأقسام مباشرة
// الدالة تعيد مصفوفة جاهزة، لذا لا نستخدم fetch_assoc() هنا
$departments_data = $ai->getDepartmentComparison(); 

// 3. جلب بيانات التوقع للجدول
$predictions = [];
$active_depts = $conn->query("SELECT id, name FROM departments WHERE status = 'active' LIMIT 5");
while ($dept = $active_depts->fetch_assoc()) {
    $predictions[] = [
        'name' => $dept['name'],
        'prediction' => $ai->predictPatients($dept['id'])
    ];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; }
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; }
        .content-col { min-height: 100vh; padding: 2rem; }
        .stat-card { border: none; border-radius: 15px; color: white; transition: transform 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
            <?php include 'sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
            <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                <h2 class="fw-bold text-dark">نظرة عامة</h2>
                <span class="badge bg-success rounded-pill px-3 py-2">متصل الآن: <?php echo date('H:i'); ?></span>
            </div>

            <div class="row g-3 mb-4 text-white">
                <div class="col-md-3">
                    <div class="card stat-card bg-primary p-3 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><small>المستخدمون</small><h3 class="fw-bold mb-0"><?php echo $total_users; ?></h3></div>
                            <i class="fas fa-users fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-success p-3 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><small>المرضى</small><h3 class="fw-bold mb-0"><?php echo $total_patients; ?></h3></div>
                            <i class="fas fa-user-injured fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-info p-3 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><small>الأطباء</small><h3 class="fw-bold mb-0"><?php echo $total_doctors; ?></h3></div>
                            <i class="fas fa-user-md fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-warning p-3 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><small>المواعيد</small><h3 class="fw-bold mb-0"><?php echo $total_appointments; ?></h3></div>
                            <i class="fas fa-calendar-check fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100 p-4">
                        <h6 class="fw-bold mb-4 text-primary"><i class="fas fa-brain me-2"></i>التنبؤ بالشهر القادم (AI Model)</h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 0.9rem;">
                                <thead class="table-light">
                                    <tr>
                                        <th>القسم</th>
                                        <th>المتوقع</th>
                                        <th>الثقة</th>
                                        <th class="text-center">الاتجاه</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($predictions as $pred): ?>
                                    <tr>
                                        <td class="fw-bold text-secondary"><?php echo $pred['name']; ?></td>
                                        <td><span class="badge bg-primary bg-opacity-10 text-primary rounded-pill"><?php echo $pred['prediction']['predicted_count']; ?> مريض</span></td>
                                        <td>
                                            <div class="progress" style="height: 4px; width: 60px;">
                                                <div class="progress-bar bg-warning" style="width: <?php echo $pred['prediction']['confidence']; ?>%"></div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <?php if($pred['prediction']['trend'] == 'increasing'): ?>
                                                <i class="fas fa-arrow-up text-success"></i>
                                            <?php else: ?>
                                                <i class="fas fa-arrow-down text-danger"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100 p-4">
                        <h6 class="fw-bold mb-4 text-primary"><i class="fas fa-chart-pie me-2"></i>توزيع المرضى حسب الأقسام</h6>
                        <canvas id="distributionChart"></canvas>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('distributionChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_column($departments_data, 'department_name')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($departments_data, 'total_patients')); ?>,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'],
                borderWidth: 0,
                hoverOffset: 15
            }]
        },
        options: {
            cutout: '70%',
            plugins: { legend: { position: 'bottom', labels: { padding: 20, usePointStyle: true } } }
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>