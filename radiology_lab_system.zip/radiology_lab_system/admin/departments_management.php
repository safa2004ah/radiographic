<?php
require_once '../includes/config.php';

// التحقق من صلاحيات المدير
if (!isLoggedIn() || $_SESSION['user_role'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser(); // تعريف المتغير لمنع أخطاء السايد بار
$conn = getDBConnection();
$message = '';

// --- 1. معالجة الإضافة والتعديل ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_department'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    if (isset($_POST['dept_id']) && !empty($_POST['dept_id'])) {
        // تحديث قسم موجود
        $stmt = $conn->prepare("UPDATE departments SET name = ?, description = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $description, $status, $_POST['dept_id']);
    } else {
        // إضافة قسم جديد
        $stmt = $conn->prepare("INSERT INTO departments (name, description, status) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $description, $status);
    }

    if ($stmt->execute()) {
        $message = '<div class="alert alert-success rounded-pill px-4">تم حفظ بيانات القسم بنجاح.</div>';
    } else {
        $message = '<div class="alert alert-danger rounded-pill px-4">حدث خطأ: ' . $conn->error . '</div>';
    }
}

// --- 2. معالجة تغيير الحالة (تفعيل/إلغاء تفعيل) ---
if (isset($_GET['toggle_status'])) {
    $id = (int)$_GET['toggle_status'];
    $new_status = $_GET['current'] == 'active' ? 'inactive' : 'active';
    $conn->query("UPDATE departments SET status = '$new_status' WHERE id = $id");
    header("Location: departments_management.php");
    exit;
}

// --- 3. جلب قائمة الأقسام ---
$departments = $conn->query("SELECT * FROM departments ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الأقسام - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; position: sticky; top: 0; height: 100vh; overflow-y: auto; padding: 0; }
        .main-content { padding: 2rem; width: 100%; }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        .status-badge { cursor: pointer; transition: 0.3s; }
        .status-badge:hover { opacity: 0.8; transform: scale(1.05); }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
            <?php include 'sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
            <div class="d-flex justify-content-between align-items-center mb-5 pb-3 border-bottom">
                <h2 class="fw-bold text-dark mb-0">إدارة أقسام المركز</h2>
                <button class="btn btn-primary rounded-pill px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#deptModal" onclick="resetForm()">
                    <i class="fas fa-plus ms-2"></i> إضافة قسم جديد
                </button>
            </div>

            <?php echo $message; ?>

            <div class="card card-custom p-4 bg-white">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>اسم القسم</th>
                                <th>الوصف</th>
                                <th>الحالة</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $departments->fetch_assoc()): ?>
                            <tr>
                                <td class="fw-bold text-primary"><?php echo htmlspecialchars($row['name']); ?></td>
                                <td class="text-muted small"><?php echo htmlspecialchars($row['description']); ?></td>
                                <td>
                                    <a href="?toggle_status=<?php echo $row['id']; ?>&current=<?php echo $row['status']; ?>" class="text-decoration-none">
                                        <?php if($row['status'] == 'active'): ?>
                                            <span class="badge bg-success rounded-pill px-3 status-badge">نشط</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill px-3 status-badge">متوقف</span>
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary rounded-circle" onclick='editDept(<?php echo json_encode($row); ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="modal fade" id="deptModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="POST">
                <div class="modal-header border-0">
                    <h5 class="fw-bold" id="modalTitle">إضافة قسم جديد</h5>
                    <button type="button" class="btn-close ms-0" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="dept_id" id="dept_id">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">اسم القسم</label>
                        <input type="text" name="name" id="name" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">وصف القسم</label>
                        <textarea name="description" id="description" class="form-control rounded-3" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">الحالة الافتراضية</label>
                        <select name="status" id="status" class="form-select rounded-3">
                            <option value="active">نشط</option>
                            <option value="inactive">متوقف</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="save_department" class="btn btn-primary rounded-pill px-5">حفظ البيانات</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').innerText = 'إضافة قسم جديد';
    document.getElementById('dept_id').value = '';
    document.getElementById('name').value = '';
    document.getElementById('description').value = '';
    document.getElementById('status').value = 'active';
}

function editDept(data) {
    document.getElementById('modalTitle').innerText = 'تعديل بيانات: ' + data.name;
    document.getElementById('dept_id').value = data.id;
    document.getElementById('name').value = data.name;
    document.getElementById('description').value = data.description;
    document.getElementById('status').value = data.status;
    new bootstrap.Modal(document.getElementById('deptModal')).show();
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>