<?php
require_once '../includes/config.php';
require_once '../includes/ai_prediction.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_settings')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$ai = new AIPrediction();

// جلب الإحصائيات
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$active_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'")->fetch_assoc()['count'];
$total_patients = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'patient'")->fetch_assoc()['count'];
$total_doctors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'doctor'")->fetch_assoc()['count'];
$total_staff = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'staff'")->fetch_assoc()['count'];
$total_appointments = $conn->query("SELECT COUNT(*) as count FROM appointments")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(amount) as sum FROM invoices WHERE status = 'paid'")->fetch_assoc()['sum'];

// جلب بيانات الأقسام للمقارنة
$departments_comparison = $ai->getDepartmentComparison();

// جلب التنبؤات
$predictions = [];
$departments_list = $conn->query("SELECT id, name FROM departments WHERE status = 'active'");
while ($dept = $departments_list->fetch_assoc()) {
    $predictions[] = [
        'name' => $dept['name'],
        'prediction' => $ai->predictPatients($dept['id'])
    ];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإحصائيات - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        /* إعدادات لتجنب التداخل */
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; position: sticky; top: 0; }
        .card-custom {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
    </style>
</head>
<body class="bg-light">
<div class="container-fluid">
    <div class="row">
        <?php include 'sidebar.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
            <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
                <h2 class="fw-bold text-dark">التقارير الإحصائية</h2>
                <div class="text-muted"><?php echo date('Y-m-d'); ?></div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card card-custom p-3 bg-white border-start border-primary border-4">
                        <small class="text-muted">المستخدمون النشطون</small>
                        <h3 class="fw-bold mb-0"><?php echo $active_users; ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom p-3 bg-white border-start border-success border-4">
                        <small class="text-muted">إجمالي المرضى</small>
                        <h3 class="fw-bold mb-0"><?php echo $total_patients; ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom p-3 bg-white border-start border-info border-4">
                        <small class="text-muted">المواعيد</small>
                        <h3 class="fw-bold mb-0"><?php echo $total_appointments; ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom p-3 bg-white border-start border-warning border-4">
                        <small class="text-muted">الإيرادات (ل.س)</small>
                        <h4 class="fw-bold mb-0"><?php echo number_format($total_revenue ?? 0); ?></h4>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="card card-custom p-4 bg-white h-100">
                        <h6 class="fw-bold mb-3">توزيع الأدوار</h6>
                        <canvas id="usersChart"></canvas>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card card-custom p-4 bg-white h-100">
                        <h6 class="fw-bold mb-3">مقارنة الأقسام</h6>
                        <canvas id="departmentsChart"></canvas>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <div class="card card-custom border-0 overflow-hidden shadow-sm">
                        <div class="card-header bg-white py-3">
                            <h6 class="fw-bold mb-0 text-primary"><i class="fas fa-brain me-2"></i>توقعات الذكاء الصناعي للشهر القادم</h6>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">القسم</th>
                                        <th>العدد المتوقع</th>
                                        <th>مستوى الثقة</th>
                                        <th>الاتجاه</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($predictions as $pred): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold"><?php echo $pred['name']; ?></td>
                                        <td><span class="badge bg-primary px-3"><?php echo $pred['prediction']['predicted_count']; ?> مريض</span></td>
                                        <td style="width: 200px;">
                                            <div class="progress" style="height: 6px;">
                                                <div class="progress-bar bg-success" style="width: <?php echo $pred['prediction']['confidence']; ?>%"></div>
                                            </div>
                                        </td>
                                        <td>
                                            <i class="fas <?php echo $pred['prediction']['trend'] == 'increasing' ? 'fa-arrow-up text-success' : 'fa-arrow-down text-danger'; ?>"></i>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Chart 1
    new Chart(document.getElementById('usersChart'), {
        type: 'doughnut',
        data: {
            labels: ['مرضى', 'أطباء', 'موظفون', 'مدراء'],
            datasets: [{
                data: [<?php echo $total_patients; ?>, <?php echo $total_doctors; ?>, <?php echo $total_staff; ?>, <?php echo $total_users - ($total_patients+$total_doctors+$total_staff); ?>],
                backgroundColor: ['#0d6efd', '#198754', '#0dcaf0', '#ffc107']
            }]
        },
        options: { plugins: { legend: { position: 'bottom' } } }
    });

    // Chart 2
    new Chart(document.getElementById('departmentsChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($departments_comparison, 'department_name')); ?>,
            datasets: [{
                label: 'عدد المرضى',
                data: <?php echo json_encode(array_column($departments_comparison, 'total_patients')); ?>,
                backgroundColor: '#0d6efd'
            }]
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>