<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar collapse shadow-sm" style="background-color: #1a237e; min-height: 100vh; position: sticky; top: 0; height: 100vh; overflow-y: auto; padding-right: 0; padding-left: 0;">
    <div class="position-sticky pt-3">
        <div class="text-center py-4 border-bottom border-white border-opacity-10 mb-3">
            <h5 class="text-white fw-bold mb-0">
                <i class="fas fa-user-shield ms-2"></i><?php echo htmlspecialchars($user['full_name'] ?? 'المدير العام'); ?>
            </h5>
            <small class="text-white-50">لوحة الإدارة العليا</small>
        </div>
        
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active bg-white bg-opacity-10 shadow-sm' : 'opacity-75'; ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt ms-2"></i> لوحة التحكم
                </a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'users_management.php' ? 'active bg-white bg-opacity-10' : 'opacity-75'; ?>" href="users_management.php">
                    <i class="fas fa-users ms-2"></i> إدارة المستخدمين
                </a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'departments_management.php' ? 'active bg-white bg-opacity-10' : 'opacity-75'; ?>" href="departments_management.php">
                    <i class="fas fa-hospital ms-2 text-info"></i> إدارة الأقسام
                </a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'statistics.php' ? 'active bg-white bg-opacity-10' : 'opacity-75'; ?>" href="statistics.php">
                    <i class="fas fa-chart-pie ms-2 text-warning"></i> الإحصائيات العامة
                </a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'reports_export.php' ? 'active bg-white bg-opacity-10' : 'opacity-75'; ?>" href="reports_export.php">
                    <i class="fas fa-file-export ms-2 text-success"></i> تصدير التقارير
                </a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white rounded p-3 <?php echo basename($_SERVER['PHP_SELF']) == 'surveys.php' ? 'active bg-white bg-opacity-10' : 'opacity-75'; ?>" href="surveys.php">
                    <i class="fas fa-poll ms-2"></i> الاستبيانات
                </a>
            </li>
            
            <hr class="text-white opacity-25">
            <li class="nav-item mb-1">
                <a class="nav-link text-white opacity-75 p-2" href="../profile.php"><i class="fas fa-user-circle ms-2"></i>الملف الشخصي</a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white opacity-75 p-2" href="../change_password.php"><i class="fas fa-key ms-2 text-warning"></i> تغيير كلمة المرور</a>
            </li>
            <li class="nav-item mb-1">
                <a class="nav-link text-white opacity-75 p-2" href="../logout.php"><i class="fas fa-sign-out-alt ms-2 text-danger"></i> تسجيل الخروج</a>
            </li>
        </ul>
    </div>
</nav>