<?php
ob_start();
require_once '../includes/config.php';
require_once '../libs/tcpdf/tcpdf.php';

if (!isLoggedIn() || $_SESSION['user_role'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// --- منطق توليد التقرير المصلح ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['export_report'])) {
    $report_type = $_POST['report_type'];
    $date_from = $_POST['date_from'];
    $date_to = $_POST['date_to'];
    
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator(SITE_NAME);
    $pdf->setPrintHeader(false);
    $pdf->SetFont('aealarabiya', '', 12);
    $pdf->AddPage();
    $pdf->setRTL(true);

    $title = ($report_type == 'financial') ? 'تقرير التحصيل المالي' : 'تقرير المواعيد';
    $html = '<h1 style="text-align:center; color:#1a237e;">' . $title . '</h1>';
    $html .= '<p style="text-align:center;">الفترة من: ' . $date_from . ' إلى: ' . $date_to . '</p><hr>';

    if ($report_type == 'financial') {
        // استعلام الفواتير المصلح
        $query = "SELECT i.*, u.full_name FROM invoices i 
                  JOIN users u ON i.patient_id = u.id 
                  WHERE DATE(i.created_at) BETWEEN '$date_from' AND '$date_to'
                  ORDER BY i.created_at ASC";
        $res = $conn->query($query);
        
        $html .= '<table border="1" cellpadding="5"><thead><tr style="background-color:#f2f2f2; font-weight:bold;"><th>رقم الفاتورة</th><th>المريض</th><th>المبلغ</th><th>الحالة</th></tr></thead><tbody>';
        if($res && $res->num_rows > 0) {
            while($row = $res->fetch_assoc()) {
                $html .= '<tr><td>'.$row['invoice_number'].'</td><td>'.$row['full_name'].'</td><td>'.number_format($row['amount']).' ل.س</td><td>'.$row['status'].'</td></tr>';
            }
        } else { $html .= '<tr><td colspan="4" style="text-align:center;">لا توجد بيانات مسجلة لهذه الفترة</td></tr>'; }
        $html .= '</tbody></table>';
    } else {
        // استعلام المواعيد المصلح (استخدام اسم العمود الصحيح وجلب أسماء الأقسام)
        $query = "SELECT a.*, u.full_name, d.name as dept_name 
                  FROM appointments a 
                  JOIN users u ON a.patient_id = u.id 
                  JOIN departments d ON a.department_id = d.id
                  WHERE DATE(a.appointment_date) BETWEEN '$date_from' AND '$date_to'
                  ORDER BY a.appointment_date ASC";
        $res = $conn->query($query);
        
        $html .= '<table border="1" cellpadding="5"><thead><tr style="background-color:#f2f2f2; font-weight:bold;"><th>المريض</th><th>القسم</th><th>التاريخ</th><th>الحالة</th></tr></thead><tbody>';
        if($res && $res->num_rows > 0) {
            while($row = $res->fetch_assoc()) {
                $status_txt = ($row['status'] == 'completed') ? 'مكتمل' : 'قيد الانتظار';
                $html .= '<tr><td>'.$row['full_name'].'</td><td>'.$row['dept_name'].'</td><td>'.$row['appointment_date'].'</td><td>'.$status_txt.'</td></tr>';
            }
        } else { $html .= '<tr><td colspan="4" style="text-align:center;">لا توجد مواعيد مسجلة لهذه الفترة</td></tr>'; }
        $html .= '</tbody></table>';
    }

    ob_end_clean();
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('Report_' . date('Y-m-d') . '.pdf', 'D');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تصدير التقارير - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        .card-report { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        .sidebar-col { background-color: #1a237e; min-height: 100vh; padding: 0; position: sticky; top: 0; height: 100vh; overflow-y: auto; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
            <?php include 'sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
            <div class="d-flex justify-content-between align-items-center mb-5 pb-3 border-bottom">
                <h2 class="fw-bold text-dark mb-0"><i class="fas fa-file-export ms-2"></i>تصدير تقارير المنصة</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card card-report p-5 bg-white">
                        <form method="POST">
                            <div class="row g-4">
                                <div class="col-12 text-end">
                                    <label class="form-label fw-bold">نوع التقرير</label>
                                    <select name="report_type" class="form-select rounded-3">
                                        <option value="appointments">تقرير المواعيد</option>
                                        <option value="financial">التقرير المالي (الفواتير)</option>
                                    </select>
                                </div>
                                <div class="col-md-6 text-end">
                                    <label class="form-label fw-bold">من تاريخ</label>
                                    <input type="date" name="date_from" class="form-control" required>
                                </div>
                                <div class="col-md-6 text-end">
                                    <label class="form-label fw-bold">إلى تاريخ</label>
                                    <input type="date" name="date_to" class="form-control" required>
                                </div>
                                <div class="col-12 mt-5">
                                    <button type="submit" name="export_report" class="btn btn-primary w-100 rounded-pill py-2 fw-bold">
                                        <i class="fas fa-file-pdf ms-2"></i>توليد ملف PDF
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>