<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_users')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف وتغيير الحالة
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add' || $action == 'edit') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $full_name = $_POST['full_name'];
        $role = $_POST['role'];

        $dept_id = ($role === 'doctor' && !empty($_POST['department_id'])) ? $_POST['department_id'] : null;
        
        if ($action == 'add') {
            $password = password_hash($_POST['password'] ?? 'default123', PASSWORD_DEFAULT);
            $query = "INSERT INTO users (username, email, password, full_name, role, department_id, status) VALUES (?, ?, ?, ?, ?, ?, 'active')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssssi", $username, $email, $password, $full_name, $role, $dept_id);
        } else {
            $user_id = $_POST['user_id'];
            $dept_id = ($_POST['role'] == 'doctor') ? $_POST['department_id'] : null;
            $query = "UPDATE users SET username = ?, email = ?, full_name = ?, role = ?, department_id = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssssii", $username, $email, $full_name, $role, $dept_id, $user_id);
        }
        $stmt->execute();
    } elseif ($action == 'toggle_status') {
        $user_id = $_POST['user_id'];
        $stmt = $conn->prepare("UPDATE users SET status = CASE status WHEN 'active' THEN 'inactive' ELSE 'active' END WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
    }
    header("Location: users_management.php");
    exit;
}

$users = $conn->query("SELECT * FROM users ORDER BY role ASC, created_at DESC");
$departments = $conn->query("SELECT id, name FROM departments WHERE status = 'active'");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; position: sticky; top: 0; }
        .card { border: none; border-radius: 15px; box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="min-height: 100vh; background-color: #f8f9fa;">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h2 class="h3 fw-bold text-dark">إدارة مستخدمي النظام</h2>
                    <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#userModal" onclick="resetForm()">
                        <i class="fas fa-plus me-2"></i>إضافة مستخدم
                    </button>
                </div>

                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="usersTable">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">المستخدم</th>
                                    <th>الدور</th>
                                    <th>الحالة</th>
                                    <th class="text-center">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($u = $users->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold"><?php echo htmlspecialchars($u['full_name']); ?></div>
                                        <small class="text-muted">@<?php echo htmlspecialchars($u['username']); ?></small>
                                    </td>
                                    <td><span class="badge bg-light text-primary border"><?php echo $u['role']; ?></span></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" 
                                                   <?php echo $u['status'] == 'active' ? 'checked' : ''; ?> 
                                                   onclick="confirmToggleStatus(<?php echo $u['id']; ?>)">
                                            <span class="small"><?php echo $u['status'] == 'active' ? 'نشط' : 'معطل'; ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary mx-1" onclick='editUser(<?php echo json_encode($u); ?>)'>
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <div class="modal fade" id="userModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="userForm" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">إضافة مستخدم</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="user_id" id="userId">
                        <div class="mb-3">
                            <label class="form-label">الاسم الكامل</label>
                            <input type="text" class="form-control" name="full_name" id="fullName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">اسم المستخدم</label>
                            <input type="text" class="form-control" name="username" id="userName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" name="email" id="userEmail" required>
                        </div>
                        <div class="mb-3" id="passwordField">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" class="form-control" name="password">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الدور</label>
                            <select class="form-select" name="role" id="userRole" onchange="toggleDepartmentField()">
                                <option value="admin">مدير</option>
                                <option value="doctor">طبيب</option>
                                <option value="staff">موظف</option>
                            </select>
                        </div>
                        <div class="mb-3" id="departmentField" style="display: none;">
                            <label class="form-label">القسم التابع له</label>
                            <select class="form-select" name="department_id" id="deptId">
                                <option value="">اختر القسم...</option>
                                <?php 
                                $departments_list = $conn->query("SELECT id, name FROM departments WHERE status = 'active'");
                                while($dept = $departments_list->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleDepartmentField() {
            const roleSelect = document.getElementById('userRole');
            const deptField = document.getElementById('departmentField');
            const deptSelect = document.getElementById('deptId');

            if (roleSelect.value === 'doctor') {
                deptField.style.display = 'block';
                deptSelect.setAttribute('required', 'required');
            } else {
                deptField.style.display = 'none';
                deptSelect.removeAttribute('required');
                deptSelect.value = ''; // تصفير القيمة إذا لم يكن طبيباً
            }
        }

        function resetForm() {
            document.getElementById('userForm').reset();
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').innerText = 'إضافة مستخدم';
            document.getElementById('passwordField').style.display = 'block';
            toggleDepartmentField(); // سيقوم بإخفائه لأن القيمة الافتراضية ليست doctor
        }

        function editUser(user) {
            document.getElementById('formAction').value = 'edit';
            document.getElementById('modalTitle').innerText = 'تعديل مستخدم';
            document.getElementById('userId').value = user.id;
            document.getElementById('fullName').value = user.full_name;
            document.getElementById('userName').value = user.username;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userRole').value = user.role;
            
            // إخفاء حقل كلمة المرور عند التعديل
            document.getElementById('passwordField').style.display = 'none';

            // التحقق من ظهور حقل القسم وتعبئة قيمته
            if (user.role === 'doctor') {
                document.getElementById('deptId').value = user.department_id;
            }
            
            // تشغيل الدالة يدوياً لتحديث حالة الظهور (Display)
            toggleDepartmentField();

            new bootstrap.Modal(document.getElementById('userModal')).show();
        }

        // دالة تغيير الحالة
        function confirmToggleStatus(id) {
            if(confirm('هل أنت متأكد من تغيير حالة هذا المستخدم؟')) {
                sendAction('toggle_status', id);
            } else {
                window.location.reload(); // لإعادة مفتاح التبديل لحالته الأصلية إذا ألغى المستخدم
            }
        }

        // دالة مساعدة لإرسال الطلبات
        function sendAction(action, id) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="${action}">
                <input type="hidden" name="user_id" value="${id}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>