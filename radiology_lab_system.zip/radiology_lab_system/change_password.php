<?php
require_once 'includes/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = getCurrentUser();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];
    
    $conn = getDBConnection();
    
    if (password_verify($current_pass, $user['password'])) {
        if ($new_pass === $confirm_pass) {
            if (strlen($new_pass) >= 6) {
                $hashed_password = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashed_password, $user['id']);
                
                if ($stmt->execute()) {
                    $success = "تم تحديث كلمة المرور بنجاح.";
                } else {
                    $error = "حدث خطأ أثناء التحديث، يرجى المحاولة لاحقاً.";
                }
            } else {
                $error = "يجب أن تكون كلمة المرور الجديدة 6 أحرف على الأقل.";
            }
        } else {
            $error = "كلمتا المرور الجديدتان غير متطابقتين.";
        }
    } else {
        $error = "كلمة المرور الحالية غير صحيحة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تغيير كلمة المرور - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-family: 'Segoe UI', sans-serif; 
            padding: 20px;
        }
        .password-card { 
            background: white; 
            border-radius: 25px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
            width: 100%; 
            max-width: 450px; 
            border: none; 
            overflow: hidden; 
        }
        .card-header { 
            background-color: #1a237e; 
            color: white; 
            padding: 30px; 
            text-align: center; 
        }
        .form-label { margin-bottom: 8px; font-size: 0.9rem; }
        .form-control { 
            border-radius: 12px !important; 
            padding: 12px; 
            border: 1px solid #dee2e6; 
        }
        /* إصلاح مظهر أيقونة العين لتكون داخل الحقل */
        .input-group { position: relative; }
        .input-group .form-control { border-inline-start: 1px solid #dee2e6 !important; }
        .input-group-text { 
            background: #f8f9fa; 
            border-radius: 12px 0 0 12px !important; /* للغة العربية */
            cursor: pointer; 
            border: 1px solid #dee2e6;
            border-inline-end: 0;
        }
        .btn-update { 
            background-color: #1a237e; 
            color: white; 
            border-radius: 12px; 
            padding: 14px; 
            width: 100%; 
            border: none; 
            font-weight: bold; 
            transition: 0.3s; 
            margin-top: 10px;
        }
        .btn-update:hover { 
            background-color: #0d47a1; 
            transform: translateY(-2px); 
        }
        .strength-meter { 
            height: 6px; 
            border-radius: 3px; 
            margin: 10px 0; 
            transition: 0.3s; 
            background-color: #eee;
        }
        .feedback-text { font-size: 11px; display: block; margin-bottom: 5px; }
    </style>
</head>
<body>

<div class="password-card shadow">
    <div class="card-header">
        <div class="mb-2"><i class="fas fa-shield-alt fa-3x"></i></div>
        <h5 class="fw-bold mb-0">تحديث أمان الحساب</h5>
    </div>
    
    <div class="p-4 p-md-5">
        <?php if ($error): ?>
            <div class="alert alert-danger small rounded-3 mb-4"><i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success small rounded-3 mb-4"><i class="fas fa-check-circle me-2"></i><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" id="passwordForm">
            <div class="mb-4">
                <label class="form-label fw-bold text-muted">كلمة المرور الحالية</label>
                <input type="password" name="current_password" class="form-control" placeholder="كلمة المرور الحالية" required>
            </div>
            
            <hr class="my-4 opacity-25">

            <div class="mb-3">
                <label class="form-label fw-bold text-muted">كلمة المرور الجديدة</label>
                <div class="input-group">
                    <span class="input-group-text" onclick="togglePass('new_pass', 'eye1')">
                        <i class="fas fa-eye text-muted" id="eye1"></i>
                    </span>
                    <input type="password" name="new_password" id="new_pass" class="form-control" placeholder="كلمة المرور" required onkeyup="checkStrength(this.value)">
                </div>
                <div id="meter" class="strength-meter"></div>
                <small id="strengthText" class="feedback-text text-muted">كلمة المرور يجب أن تكون قوية.</small>
            </div>

            <div class="mb-4">
                <label class="form-label fw-bold text-muted">تأكيد كلمة المرور الجديدة</label>
                <div class="input-group">
                    <span class="input-group-text" onclick="togglePass('confirm_pass', 'eye2')">
                        <i class="fas fa-eye text-muted" id="eye2"></i>
                    </span>
                    <input type="password" name="confirm_password" id="confirm_pass" class="form-control" placeholder="تأكيد كلمة المرور" required>
                </div>
                <small id="matchText" class="feedback-text text-danger" style="display:none; margin-top: 8px;">
                    <i class="fas fa-times-circle me-1"></i> كلمتا المرور غير متطابقتين!
                </small>
            </div>
            
            <button type="submit" class="btn btn-update shadow-sm">تحديث كلمة المرور</button>
            
            <div class="text-center mt-4">
                <a href="<?php echo $user['role']; ?>/dashboard.php" class="text-muted text-decoration-none small">
                    <i class="fas fa-arrow-right me-1"></i> إلغاء والعودة للرئيسية
                </a>
            </div>
        </form>
    </div>
</div>

<script>
// وظيفة إظهار وإخفاء كلمة المرور
function togglePass(id, eyeId) {
    const field = document.getElementById(id);
    const eye = document.getElementById(eyeId);
    if (field.type === "password") {
        field.type = "text";
        eye.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        field.type = "password";
        eye.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

// فحص قوة كلمة المرور وتغيير شريط الحالة
function checkStrength(password) {
    let strength = 0;
    if (password.length > 7) strength++;
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
    if (password.match(/\d/)) strength++;
    if (password.match(/[^a-zA-Z\d]/)) strength++;

    const meter = document.getElementById('meter');
    const text = document.getElementById('strengthText');
    
    if (password.length === 0) {
        meter.style.width = "0%";
        meter.style.backgroundColor = "#eee";
        text.innerText = "كلمة المرور يجب أن تكون قوية.";
        return;
    }

    switch(strength) {
        case 0: case 1: 
            meter.style.width = "30%"; meter.style.backgroundColor = "#ff4d4d"; 
            text.innerText = "كلمة مرور ضعيفة"; break;
        case 2: 
            meter.style.width = "60%"; meter.style.backgroundColor = "#ffa500"; 
            text.innerText = "كلمة مرور متوسطة القوة"; break;
        case 3: case 4: 
            meter.style.width = "100%"; meter.style.backgroundColor = "#27ae60"; 
            text.innerText = "كلمة مرور قوية جداً"; break;
    }
}

// التحقق من التطابق مع إضافة مساحة لمنع التداخل
document.getElementById('confirm_pass').onkeyup = function() {
    const p1 = document.getElementById('new_pass').value;
    const matchText = document.getElementById('matchText');
    if (p1 !== this.value && this.value !== "") {
        matchText.style.display = "block";
    } else {
        matchText.style.display = "none";
    }
};
</script>
</body>
</html>