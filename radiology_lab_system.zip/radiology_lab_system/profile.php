<?php
require_once 'includes/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$success = '';
$error = '';

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    
    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
    $stmt->bind_param("sssi", $full_name, $email, $phone, $user['id']);
    
    if ($stmt->execute()) {
        $success = "تم تحديث بيانات ملفك الشخصي بنجاح.";
        // تحديث بيانات الجلسة الحالية
        $user['full_name'] = $full_name;
        $user['email'] = $email;
        $user['phone'] = $phone;
    } else {
        $error = "حدث خطأ أثناء محاولة التحديث.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-blue: #1a237e; --bg-gray: #f0f2f5; }
        body { background-color: var(--bg-gray); min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .profile-card { background: white; border-radius: 25px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); width: 100%; max-width: 700px; overflow: hidden; border: none; }
        .profile-header { background-color: var(--primary-blue); color: white; padding: 40px 20px; text-align: center; position: relative; }
        .avatar-container { width: 100px; height: 100px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; border: 4px solid rgba(255,255,255,0.2); }
        .avatar-container i { font-size: 50px; color: var(--primary-blue); }
        .form-control { border-radius: 12px; padding: 12px; border: 1px solid #dee2e6; transition: all 0.3s; }
        .form-control:focus { border-color: var(--primary-blue); box-shadow: 0 0 0 0.25 row rgba(26, 35, 126, 0.1); }
        .btn-save { background-color: var(--primary-blue); color: white; border-radius: 12px; padding: 12px 40px; border: none; font-weight: bold; transition: 0.3s; }
        .btn-save:hover { background-color: #0d47a1; transform: translateY(-2px); }
    </style>
</head>
<body>

<div class="profile-card shadow">
    <div class="profile-header">
        <div class="avatar-container">
            <i class="fas fa-user-circle"></i>
        </div>
        <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h4>
        <span class="badge bg-light text-primary rounded-pill px-3"><?php echo strtoupper($user['role']); ?></span>
    </div>

    <div class="p-4 p-md-5">
        <?php if ($success): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4"><i class="fas fa-check-circle me-2"></i><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-muted">الاسم الكامل</label>
                    <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-muted">اسم المستخدم</label>
                    <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-muted">البريد الإلكتروني</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-muted">رقم الهاتف</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
                </div>
            </div>

            <div class="mt-5 d-flex flex-column flex-md-row gap-3">
                <button type="submit" class="btn btn-save px-5 shadow-sm">حفظ التغييرات</button>
                <a href="<?php echo $user['role']; ?>/dashboard.php" class="btn btn-outline-secondary rounded-pill px-4 py-2 text-decoration-none text-center">
                    <i class="fas fa-arrow-right me-2"></i>العودة للوحة التحكم
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>