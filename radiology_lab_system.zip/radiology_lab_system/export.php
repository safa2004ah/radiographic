<?php
require_once 'includes/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    die('غير مصرح بالدخول');
}

// نوع التصدير
$type = $_GET['type'] ?? 'csv';
$table = $_GET['table'] ?? '';

if (empty($table)) {
    die('يرجى تحديد الجدول');
}

$conn = getDBConnection();

// جلب البيانات
$query = "SELECT * FROM " . $table;
$result = $conn->query($query);

if (!$result) {
    die('خطأ في استرجاع البيانات');
}

// تحديد نوع الملف
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $table . '_' . date('Y-m-d') . '.csv"');

// إنشاء ملف CSV
$output = fopen('php://output', 'w');

// كتابة رؤوس الأعمدة
$fields = $result->fetch_fields();
$headers = [];
foreach ($fields as $field) {
    $headers[] = $field->name;
}
fputcsv($output, $headers);

// كتابة البيانات
while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
exit;
?>