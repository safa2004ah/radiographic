<?php
require_once 'includes/config.php';

// توجيه المستخدم إذا كان مسجلاً دخوله
if (isLoggedIn()) {
    $user = getCurrentUser();
    header("Location: " . $user['role'] . "/dashboard.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $birth_date = $_POST['birth_date'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    $conn = getDBConnection();
    
    if ($password !== $confirm_password) {
        $error = 'كلمتا المرور غير متطابقتين';
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        
        if ($check->get_result()->num_rows > 0) {
            $error = 'اسم المستخدم أو البريد الإلكتروني مسجل مسبقاً';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            // إضافة birth_date إلى استعلام الإدخال
            $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, phone, birth_date, role, status) VALUES (?, ?, ?, ?, ?, ?, 'patient', 'active')");
            $stmt->bind_param("ssssss", $full_name, $username, $email, $hashed_password, $phone, $birth_date);
            
            if ($stmt->execute()) {
                $success = 'تم إنشاء حساب المريض بنجاح. يمكنك تسجيل الدخول الآن.';
            } else {
                $error = 'حدث خطأ أثناء التسجيل، يرجى المحاولة لاحقاً';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب مريض - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px 0; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .register-card { border: none; border-radius: 25px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); overflow: hidden; max-width: 600px; width: 100%; background: white; }
        .register-header { background-color: #1a237e; color: white; padding: 30px; text-align: center; }
        .form-control { border-radius: 10px; padding: 10px; border: 1px solid #eee; }
        .input-group-text { cursor: pointer; background: white; border-radius: 10px 0 0 10px !important; border-inline-start: 0; }
        .btn-register { background-color: #1a237e; color: white; border-radius: 10px; padding: 12px; width: 100%; border: none; transition: 0.3s; }
        .btn-register:hover { background-color: #0d47a1; transform: translateY(-2px); }
        .strength-meter { height: 5px; border-radius: 5px; margin-top: 5px; transition: 0.3s; }
    </style>
</head>
<body>

<div class="register-card shadow">
    <div class="register-header">
        <i class="fas fa-user-plus fa-2x mb-2"></i>
        <h4 class="fw-bold">إنشاء حساب مريض جديد</h4>
        <p class="small opacity-75 mb-0">يرجى إدخال بياناتك بدقة لتسهيل عملية التشخيص</p>
    </div>
    <div class="p-4 p-md-5">
        <?php if ($error): ?>
            <div class="alert alert-danger small rounded-3"><i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success small rounded-3"><i class="fas fa-check-circle me-2"></i><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" id="regForm">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">الاسم الكامل</label>
                    <input type="text" name="full_name" class="form-control" placeholder="الاسم الثلاثي" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">اسم المستخدم</label>
                    <input type="text" name="username" class="form-control" placeholder="username" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">البريد الإلكتروني</label>
                    <input type="email" name="email" class="form-control" placeholder="example@mail.com" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">رقم الهاتف</label>
                    <input type="text" name="phone" class="form-control" placeholder="09xxxxxxxx">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold">تاريخ الميلاد</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-calendar-alt text-muted"></i></span>
                    <input type="date" name="birth_date" class="form-control" required>
                </div>
                <small class="text-muted" style="font-size: 11px;">ضروري لحساب العمر بدقة عند إجراء الفحوصات.</small>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold">كلمة المرور</label>
                <div class="input-group">
                    <input type="password" name="password" id="password" class="form-control" required onkeyup="checkStrength(this.value)">
                    <span class="input-group-text" onclick="togglePass('password', 'eye1')">
                        <i class="fas fa-eye text-muted" id="eye1"></i>
                    </span>
                </div>
                <div id="meter" class="strength-meter"></div>
                <small id="strengthText" class="text-muted" style="font-size: 11px;">استخدم 8 أحرف على الأقل (أرقام وحروف).</small>
            </div>

            <div class="mb-4">
                <label class="form-label small fw-bold">تأكيد كلمة المرور</label>
                <div class="input-group">
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                    <span class="input-group-text" onclick="togglePass('confirm_password', 'eye2')">
                        <i class="fas fa-eye text-muted" id="eye2"></i>
                    </span>
                </div>
                <small id="matchText" class="text-danger" style="font-size: 11px; display:none;">كلمتا المرور غير متطابقتين!</small>
            </div>

            <button type="submit" class="btn btn-register fw-bold shadow-sm">تأكيد التسجيل</button>
            <div class="mt-4 text-center">
                <small class="text-muted">لديك حساب بالفعل؟ <a href="login.php" class="text-primary text-decoration-none fw-bold">سجل دخولك هنا</a></small>
            </div>
        </form>
    </div>
</div>

<script>
function togglePass(id, eyeId) {
    const field = document.getElementById(id);
    const eye = document.getElementById(eyeId);
    if (field.type === "password") {
        field.type = "text";
        eye.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        field.type = "password";
        eye.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

function checkStrength(password) {
    let strength = 0;
    if (password.length > 7) strength++;
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
    if (password.match(/\d/)) strength++;
    if (password.match(/[^a-zA-Z\d]/)) strength++;

    const meter = document.getElementById('meter');
    const text = document.getElementById('strengthText');
    
    switch(strength) {
        case 0: case 1: meter.style.width = "30%"; meter.style.backgroundColor = "#ff4d4d"; text.innerText = "ضعيفة"; break;
        case 2: meter.style.width = "60%"; meter.style.backgroundColor = "#ffa500"; text.innerText = "متوسطة"; break;
        case 3: case 4: meter.style.width = "100%"; meter.style.backgroundColor = "#27ae60"; text.innerText = "قوية جداً"; break;
    }
}

document.getElementById('confirm_password').onkeyup = function() {
    const p1 = document.getElementById('password').value;
    const matchText = document.getElementById('matchText');
    matchText.style.display = (p1 !== this.value) ? "block" : "none";
};
</script>
</body>
</html>