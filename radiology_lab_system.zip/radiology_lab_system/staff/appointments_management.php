<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_appointments')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add' || $action == 'edit') {
        $patient_id = $_POST['patient_id'];
        $doctor_id = $_POST['doctor_id'];
        $department_id = $_POST['department_id'];
        $appointment_date = $_POST['appointment_date'];
        $appointment_time = $_POST['appointment_time'];
        $notes = $_POST['notes'] ?? '';
        $staff_notes = $_POST['staff_notes'] ?? '';
        
        if ($action == 'add') {
            $query = "INSERT INTO appointments (patient_id, doctor_id, department_id, appointment_date, appointment_time, notes, staff_notes, status) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iiissss", $patient_id, $doctor_id, $department_id, $appointment_date, $appointment_time, $notes, $staff_notes);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة الموعد بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة الموعد';
            }
        } else {
            $appointment_id = $_POST['appointment_id'];
            $query = "UPDATE appointments SET patient_id = ?, doctor_id = ?, department_id = ?, 
                      appointment_date = ?, appointment_time = ?, notes = ?, staff_notes = ? 
                      WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iiissssi", $patient_id, $doctor_id, $department_id, $appointment_date, $appointment_time, $notes, $staff_notes, $appointment_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل الموعد بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل الموعد';
            }
        }
    } elseif ($action == 'delete') {
        $appointment_id = $_POST['appointment_id'];
        $query = "DELETE FROM appointments WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $appointment_id);
        
        if ($stmt->execute()) {
            $success = 'تم حذف الموعد بنجاح';
        } else {
            $error = 'حدث خطأ أثناء حذف الموعد';
        }
    } elseif ($action == 'change_status') {
        $appointment_id = $_POST['appointment_id'];
        $status = $_POST['status'];
        $query = "UPDATE appointments SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $status, $appointment_id);
        
        if ($stmt->execute()) {
            $success = 'تم تغيير حالة الموعد بنجاح';
        } else {
            $error = 'حدث خطأ أثناء تغيير حالة الموعد';
        }
    }
}

// جلب جميع المواعيد
$query = "SELECT a.*, p.full_name as patient_name, d.full_name as doctor_name, dept.name as department_name
          FROM appointments a
          JOIN users p ON a.patient_id = p.id
          JOIN users d ON a.doctor_id = d.id
          JOIN departments dept ON a.department_id = dept.id
          ORDER BY a.appointment_date DESC, a.appointment_time DESC";

$appointments = $conn->query($query);

// جلب المرضى
$patients_query = "SELECT id, full_name, phone FROM users WHERE role = 'patient' AND status = 'active' ORDER BY full_name";
$patients = $conn->query($patients_query);

// جلب الأطباء
$doctors_query = "SELECT id, full_name, specialization FROM users WHERE role = 'doctor' AND status = 'active' ORDER BY full_name";
$doctors = $conn->query($doctors_query);

// جلب الأقسام
$departments_query = "SELECT id, name FROM departments WHERE status = 'active' ORDER BY name";
$departments = $conn->query($departments_query);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المواعيد - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        /* تثبيت القائمة الجانبية على اليمين */
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        /* إعطاء مساحة للمحتوى الرئيسي ليتجنب التداخل */
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 sidebar-col shadow">
            <?php include 'sidebar.php'; ?>
        </div>
            <!-- المحتوى الرئيسي -->
            <main class="main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة المواعيد</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#appointmentModal" onclick="resetForm()">
                        <i class="fas fa-plus me-2"></i>إضافة موعد جديد
                    </button>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- فلاتر البحث -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <input type="text" class="form-control" id="searchInput" placeholder="بحث عن مريض أو طبيب..." 
                                       onkeyup="searchTable('searchInput', 'appointmentsTable')">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="statusFilter" onchange="filterByStatus()">
                                    <option value="">جميع الحالات</option>
                                    <option value="pending">قيد الانتظار</option>
                                    <option value="confirmed">مؤكد</option>
                                    <option value="completed">مكتمل</option>
                                    <option value="cancelled">ملغى</option>
                                    <option value="no-show">لم يحضر</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="date" class="form-control" id="dateFilter" onchange="filterByDate()">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="departmentFilter" onchange="filterByDepartment()">
                                    <option value="">جميع الأقسام</option>
                                    <?php 
                                    $temp_conn = getDBConnection();
                                    $temp_departments = $temp_conn->query("SELECT id, name FROM departments WHERE status = 'active'");
                                    while ($dept = $temp_departments->fetch_assoc()):
                                    ?>
                                        <option value="<?php echo $dept['id']; ?>"><?php echo $dept['name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- جدول المواعيد -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover" id="appointmentsTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>التاريخ والوقت</th>
                                        <th>المريض</th>
                                        <th>الطبيب</th>
                                        <th>القسم</th>
                                        <th>الحالة</th>
                                        <th>ملاحظات الموظف</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php while ($appointment = $appointments->fetch_assoc()): ?>
                                        <tr data-status="<?php echo $appointment['status']; ?>" 
                                            data-department="<?php echo $appointment['department_id']; ?>"
                                            data-date="<?php echo $appointment['appointment_date']; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <td>
                                                <strong><?php echo date('d/m/Y', strtotime($appointment['appointment_date'])); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></small>
                                            </td>
                                            <td>
                                                <strong><?php echo $appointment['patient_name']; ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo $appointment['phone'] ?? ''; ?></small>
                                            </td>
                                            <td>
                                                <strong><?php echo $appointment['doctor_name']; ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo $appointment['specialization'] ?? ''; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $appointment['department_name']; ?></span>
                                            </td>
                                            <td>
                                                <?php
                                                $status_badge = [
                                                    'pending' => 'warning',
                                                    'confirmed' => 'success',
                                                    'completed' => 'secondary',
                                                    'cancelled' => 'danger',
                                                    'no-show' => 'dark'
                                                ];
                                                $status_text = [
                                                    'pending' => 'قيد الانتظار',
                                                    'confirmed' => 'مؤكد',
                                                    'completed' => 'مكتمل',
                                                    'cancelled' => 'ملغى',
                                                    'no-show' => 'لم يحضر'
                                                ];
                                                ?>
                                                <span class="badge bg-<?php echo $status_badge[$appointment['status']]; ?>">
                                                    <?php echo $status_text[$appointment['status']]; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small><?php echo !empty($appointment['staff_notes']) ? $appointment['staff_notes'] : '-'; ?></small>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-primary me-1" 
                                                        onclick="editAppointment(<?php echo htmlspecialchars(json_encode($appointment)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-success me-1" 
                                                        onclick="changeStatus(<?php echo $appointment['id']; ?>, 'confirmed')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" 
                                                        onclick="deleteAppointment(<?php echo $appointment['id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نموذج إضافة/تعديل موعد -->
    <div class="modal fade" id="appointmentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">إضافة موعد جديد</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="appointment_id" id="appointmentId">
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">المريض <span class="text-danger">*</span></label>
                                <select class="form-select" name="patient_id" id="patientId" required>
                                    <option value="">اختر المريض</option>
                                    <?php mysqli_data_seek($patients, 0); ?>
                                    <?php while ($patient = $patients->fetch_assoc()): ?>
                                        <option value="<?php echo $patient['id']; ?>">
                                            <?php echo $patient['full_name']; ?> - <?php echo $patient['phone']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">الطبيب <span class="text-danger">*</span></label>
                                <select class="form-select" name="doctor_id" id="doctorId" required>
                                    <option value="">اختر الطبيب</option>
                                    <?php mysqli_data_seek($doctors, 0); ?>
                                    <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                        <option value="<?php echo $doctor['id']; ?>">
                                            <?php echo $doctor['full_name']; ?> - <?php echo $doctor['specialization']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">القسم <span class="text-danger">*</span></label>
                                <select class="form-select" name="department_id" id="departmentId" required>
                                    <option value="">اختر القسم</option>
                                    <?php mysqli_data_seek($departments, 0); ?>
                                    <?php while ($dept = $departments->fetch_assoc()): ?>
                                        <option value="<?php echo $dept['id']; ?>"><?php echo $dept['name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">تاريخ الموعد <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="appointment_date" id="appointmentDate" required 
                                       min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">وقت الموعد <span class="text-danger">*</span></label>
                                <input type="time" class="form-control" name="appointment_time" id="appointmentTime" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">ملاحظات عامة</label>
                                <textarea class="form-control" name="notes" id="notes" rows="2"></textarea>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">ملاحظات للموظف</label>
                                <textarea class="form-control" name="staff_notes" id="staffNotes" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="saveButtonText">حفظ الموعد</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').textContent = 'إضافة موعد جديد';
            document.getElementById('saveButtonText').textContent = 'حفظ الموعد';
            document.querySelector('form').reset();
        }

        function editAppointment(appointment) {
            document.getElementById('formAction').value = 'edit';
            document.getElementById('modalTitle').textContent = 'تعديل موعد';
            document.getElementById('saveButtonText').textContent = 'تعديل الموعد';
            document.getElementById('appointmentId').value = appointment.id;
            document.getElementById('patientId').value = appointment.patient_id;
            document.getElementById('doctorId').value = appointment.doctor_id;
            document.getElementById('departmentId').value = appointment.department_id;
            document.getElementById('appointmentDate').value = appointment.appointment_date;
            document.getElementById('appointmentTime').value = appointment.appointment_time;
            document.getElementById('notes').value = appointment.notes || '';
            document.getElementById('staffNotes').value = appointment.staff_notes || '';
            new bootstrap.Modal(document.getElementById('appointmentModal')).show();
        }

        function deleteAppointment(id) {
            if (confirm('هل أنت متأكد من حذف هذا الموعد؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'appointment_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function changeStatus(id, status) {
            if (confirm('هل تريد تغيير حالة الموعد؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'change_status';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'appointment_id';
                idInput.value = id;
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = status;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                form.appendChild(statusInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function filterByStatus() {
            const status = document.getElementById('statusFilter').value;
            const rows = document.querySelectorAll('#appointmentsTable tbody tr');
            
            rows.forEach(row => {
                if (!status || row.dataset.status === status) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function filterByDate() {
            const date = document.getElementById('dateFilter').value;
            const rows = document.querySelectorAll('#appointmentsTable tbody tr');
            
            rows.forEach(row => {
                if (!date || row.dataset.date === date) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function filterByDepartment() {
            const department = document.getElementById('departmentFilter').value;
            const rows = document.querySelectorAll('#appointmentsTable tbody tr');
            
            rows.forEach(row => {
                if (!department || row.dataset.department === department) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>