<?php
// جلب اسم الملف الحالي لتحديد الرابط النشط تلقائياً
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="d-flex flex-column p-3 text-white shadow sidebar-scrollable">
    <div class="text-center mb-2 pt-3 flex-shrink-0">
        <div class="avatar-bg mx-auto mb-2">
            <i class="fas fa-user-tie fa-2x text-primary"></i>
        </div>
        <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($user['full_name']); ?></h6>
        <small class="opacity-75">موظف استقبال ومواعيد</small>
    </div>
    
    <hr class="opacity-25 my-4 flex-shrink-0">
    
    <ul class="nav nav-pills flex-column mb-auto sidebar-nav-links">
        <li class="nav-item mb-2">
            <a href="dashboard.php" class="nav-link text-white <?php echo ($current_page == 'dashboard.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-tachometer-alt ms-2"></i> لوحة التحكم
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="patients_management.php" class="nav-link text-white <?php echo ($current_page == 'patients_management.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-user-injured ms-2"></i> إدارة المرضى
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="appointments_management.php" class="nav-link text-white <?php echo ($current_page == 'appointments_management.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-calendar-alt ms-2"></i> المواعيد
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="surveys_management.php" class="nav-link text-white <?php echo ($current_page == 'surveys.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-poll-h ms-2"></i> الاستبيانات
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="payment_methods.php" class="nav-link text-white <?php echo ($current_page == 'payment_methods.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-credit-card ms-2"></i> طرق الدفع
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="invoices.php" class="nav-link text-white <?php echo ($current_page == 'invoices.php') ? 'active' : 'hover-link'; ?> rounded-3">
                <i class="fas fa-file-invoice-dollar ms-2"></i> الفواتير
            </a>
        </li>
    </ul>
    
    <hr class="opacity-25 my-4 flex-shrink-0">
    
    <ul class="nav nav-pills flex-column flex-shrink-0">
        <li class="nav-item mb-2">
            <a href="../profile.php" class="nav-link text-white hover-link rounded-3">
                <i class="fas fa-user-circle ms-2"></i> الملف الشخصي
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="../change_password.php" class="nav-link text-white hover-link rounded-3">
                <i class="fas fa-key ms-2"></i> تغيير كلمة المرور
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="../logout.php" class="nav-link text-danger fw-bold rounded-3">
                <i class="fas fa-sign-out-alt ms-2"></i> خروج
            </a>
        </li>
    </ul>
</div>

<style>
    /* التنسيق الأساسي لتمكين التمرير */
    .sidebar-scrollable {
        height: 100vh; /* ملء كامل ارتفاع الشاشة */
        overflow-y: auto; /* تمكين التمرير العمودي */
        overflow-x: hidden;
        position: sticky;
        top: 0;
        scrollbar-width: thin; /* لمتصفح Firefox */
        scrollbar-color: rgba(255,255,255,0.2) transparent;
    }

    /* تخصيص شريط التمرير لمتصفحات Chrome/Edge/Safari */
    .sidebar-scrollable::-webkit-scrollbar {
        width: 4px;
    }
    .sidebar-scrollable::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.2);
        border-radius: 10px;
    }

    .avatar-bg { 
        width: 60px; height: 60px; background: white; 
        border-radius: 50%; display: flex; 
        align-items: center; justify-content: center; 
    }

    .nav-link { 
        transition: 0.3s; padding: 12px 15px; 
        display: flex; align-items: center; color: white;
    }

    .nav-link i { width: 25px; text-align: center; }

    .nav-link.active { 
        background-color: #3f51b5 !important; 
        color: white !important; font-weight: bold;
    }

    .hover-link:hover { 
        background-color: rgba(255,255,255,0.1) !important; 
    }
</style>