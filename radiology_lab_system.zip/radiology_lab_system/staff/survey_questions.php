<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_surveys')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// جلب معرف الاستبيان
$survey_id = $_GET['survey_id'] ?? 0;

// جلب معلومات الاستبيان
$survey_query = "SELECT * FROM surveys WHERE id = ?";
$stmt = $conn->prepare($survey_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$survey = $stmt->get_result()->fetch_assoc();

if (!$survey) {
    header('Location: surveys_management.php');
    exit;
}

// معالجة إضافة وتعديل الأسئلة
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add_question' || $action == 'edit_question') {
        $question = $_POST['question'];
        $question_type = $_POST['question_type'];
        $options = $_POST['options'] ?? '';
        $required = isset($_POST['required']) ? 1 : 0;
        $order_num = $_POST['order_num'] ?? 0;
        
        if ($action == 'add_question') {
            $query = "INSERT INTO survey_questions (survey_id, question, question_type, options, required, order_num) 
                      VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("isssii", $survey_id, $question, $question_type, $options, $required, $order_num);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة السؤال بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة السؤال';
            }
        } else {
            $question_id = $_POST['question_id'];
            $query = "UPDATE survey_questions SET question = ?, question_type = ?, options = ?, required = ?, order_num = ? 
                      WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssi", $question, $question_type, $options, $required, $order_num, $question_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل السؤال بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل السؤال';
            }
        }
    } elseif ($action == 'delete_question') {
        $question_id = $_POST['question_id'];
        $query = "DELETE FROM survey_questions WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $question_id);
        
        if ($stmt->execute()) {
            $success = 'تم حذف السؤال بنجاح';
        } else {
            $error = 'حدث خطأ أثناء حذف السؤال';
        }
    }
}

// جلب الأسئلة
$questions_query = "SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY order_num ASC, id ASC";
$stmt = $conn->prepare($questions_query);
$stmt->bind_param("i", $survey_id);
$stmt->execute();
$questions = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أسئلة الاستبيان - <?php echo $survey['title']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        /* تثبيت القائمة الجانبية على اليمين */
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        /* إعطاء مساحة للمحتوى الرئيسي ليتجنب التداخل */
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
      <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2 sidebar-col shadow">
                    <?php include 'sidebar.php'; ?>
                </div>
            <!-- المحتوى الرئيسي -->
            <main class="main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <div>
                        <h1 class="h2">أسئلة الاستبيان</h1>
                        <h5 class="text-muted"><?php echo $survey['title']; ?></h5>
                    </div>
                    <div>
                        <a href="surveys_management.php" class="btn btn-secondary me-2">
                            <i class="fas fa-arrow-right me-2"></i>العودة للاستبيانات
                        </a>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#questionModal" onclick="resetForm()">
                            <i class="fas fa-plus me-2"></i>إضافة سؤال جديد
                        </button>
                    </div>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- الأسئلة -->
                <div class="card">
                    <div class="card-body">
                        <?php if ($questions->num_rows > 0): ?>
                            <div class="list-group">
                                <?php while ($question = $questions->fetch_assoc()): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-2">
                                                    <?php echo $question['order_num']; ?>. <?php echo $question['question']; ?>
                                                    <?php if ($question['required']): ?>
                                                        <span class="text-danger">*</span>
                                                    <?php endif; ?>
                                                </h6>
                                                
                                                <div class="mb-2">
                                                    <span class="badge bg-info">
                                                        <?php 
                                                        $type_text = [
                                                            'text' => 'نص',
                                                            'radio' => 'اختيار واحد',
                                                            'checkbox' => 'اختيار متعدد',
                                                            'rating' => 'تقييم'
                                                        ];
                                                        echo $type_text[$question['question_type']];
                                                        ?>
                                                    </span>
                                                    
                                                    <?php if (!empty($question['options'])): ?>
                                                        <div class="mt-2">
                                                            <small class="text-muted">الخيارات: <?php echo $question['options']; ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <div class="btn-group btn-group-sm" role="group">
                                                <button class="btn btn-primary" 
                                                        onclick="editQuestion(<?php echo htmlspecialchars(json_encode($question)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-danger" 
                                                        onclick="deleteQuestion(<?php echo $question['id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info text-center">
                                <i class="fas fa-info-circle fa-2x mb-3"></i>
                                <p class="mb-0">لا توجد أسئلة لهذا الاستبيان</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نموذج إضافة/تعديل سؤال -->
    <div class="modal fade" id="questionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">إضافة سؤال جديد</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add_question">
                        <input type="hidden" name="question_id" id="questionId">
                        
                        <div class="mb-3">
                            <label class="form-label">السؤال <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="question" id="question" rows="3" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نوع السؤال <span class="text-danger">*</span></label>
                            <select class="form-select" name="question_type" id="questionType" required onchange="toggleOptionsField()">
                                <option value="text">نص (إجابة حرة)</option>
                                <option value="radio">اختيار واحد</option>
                                <option value="checkbox">اختيار متعدد</option>
                                <option value="rating">تقييم (1-5)</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="optionsField" style="display: none;">
                            <label class="form-label">الخيارات (افصل بينها بفواصل)</label>
                            <input type="text" class="form-control" name="options" id="options" placeholder="خيار1, خيار2, خيار3">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">ترتيب السؤال</label>
                            <input type="number" class="form-control" name="order_num" id="orderNum" value="0" min="0">
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="required" id="required" value="1">
                            <label class="form-check-label" for="required">سؤال إجباري</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="saveButtonText">حفظ السؤال</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add_question';
            document.getElementById('modalTitle').textContent = 'إضافة سؤال جديد';
            document.getElementById('saveButtonText').textContent = 'حفظ السؤال';
            document.querySelector('form').reset();
            document.getElementById('optionsField').style.display = 'none';
        }

        function toggleOptionsField() {
            const type = document.getElementById('questionType').value;
            const optionsField = document.getElementById('optionsField');
            
            if (type === 'radio' || type === 'checkbox') {
                optionsField.style.display = 'block';
            } else {
                optionsField.style.display = 'none';
            }
        }

        function editQuestion(question) {
            document.getElementById('formAction').value = 'edit_question';
            document.getElementById('modalTitle').textContent = 'تعديل سؤال';
            document.getElementById('saveButtonText').textContent = 'تعديل السؤال';
            document.getElementById('questionId').value = question.id;
            document.getElementById('question').value = question.question;
            document.getElementById('questionType').value = question.question_type;
            document.getElementById('options').value = question.options || '';
            document.getElementById('orderNum').value = question.order_num;
            document.getElementById('required').checked = question.required == 1;
            
            toggleOptionsField();
            new bootstrap.Modal(document.getElementById('questionModal')).show();
        }

        function deleteQuestion(id) {
            if (confirm('هل أنت متأكد من حذف هذا السؤال؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_question';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'question_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>