<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!isLoggedIn() || $_SESSION['user_role'] != 'staff') {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// إحصائيات سريعة
$pending_count = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE status = 'pending'")->fetch_assoc()['count'];
$today_count = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = CURDATE()")->fetch_assoc()['count'];

// جلب آخر المواعيد
$query = "SELECT a.*, u.full_name as patient_name, d.name as dept_name 
          FROM appointments a 
          JOIN users u ON a.patient_id = u.id 
          JOIN departments d ON a.department_id = d.id 
          ORDER BY a.appointment_date DESC LIMIT 8";
$appointments = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الموظف - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .stat-card { border: none; border-radius: 20px; box-shadow: 0 10px 20px rgba(0,0,0,0.05); }
        .table-card { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); overflow: hidden; }
        .badge-pending { background-color: #ffc107; color: #000; }
        .badge-completed { background-color: #198754; color: #fff; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 sidebar-col shadow">
            <?php include 'sidebar.php'; ?>
        </div>

        <div class="main-content">
            <div class="d-flex justify-content-between align-items-center mb-5 pb-3 border-bottom">
                <div>
                    <h2 class="fw-bold text-dark mb-1">مرحباً، <?php echo $user['full_name']; ?></h2>
                    <p class="text-muted small mb-0">لوحة تحكم قسم الاستقبال والمواعيد</p>
                </div>
                <span class="badge bg-primary rounded-pill px-4 py-2 shadow-sm"><i class="far fa-clock ms-2"></i><?php echo date('H:i'); ?></span>
            </div>

            <div class="row g-4 mb-5 text-center">
                <div class="col-md-6">
                    <div class="card stat-card bg-white p-4 border-start border-primary border-5">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="bg-primary bg-opacity-10 p-4 rounded-4 text-primary">
                                <i class="fas fa-hourglass-half fa-2x"></i>
                            </div>
                            <div class="text-end">
                                <h6 class="text-muted fw-bold">مواعيد بانتظار الإجراء</h6>
                                <h2 class="fw-bold text-dark mb-0"><?php echo $pending_count; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card stat-card bg-white p-4 border-start border-success border-5">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="bg-success bg-opacity-10 p-4 rounded-4 text-success">
                                <i class="fas fa-calendar-check fa-2x"></i>
                            </div>
                            <div class="text-end">
                                <h6 class="text-muted fw-bold">مواعيد اليوم</h6>
                                <h2 class="fw-bold text-dark mb-0"><?php echo $today_count; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card table-card bg-white">
                <div class="card-header bg-white py-4 px-4 border-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-dark"><i class="fas fa-list-ul ms-2"></i>أحدث المواعيد المسجلة</h5>
                    <a href="add_appointment.php" class="btn btn-primary rounded-pill px-4 shadow-sm">إضافة موعد جديد</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">المريض</th>
                                <th>القسم</th>
                                <th>التاريخ والوقت</th>
                                <th>الحالة</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $appointments->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4 fw-bold"><?php echo htmlspecialchars($row['patient_name']); ?></td>
                                <td><span class="badge bg-light text-primary border px-3"><?php echo htmlspecialchars($row['dept_name']); ?></span></td>
                                <td class="text-muted small"><?php echo date('Y-m-d | H:i', strtotime($row['appointment_date'])); ?></td>
                                <td>
                                    <?php if($row['status'] == 'pending'): ?>
                                        <span class="badge rounded-pill badge-pending px-3">قيد الانتظار</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill badge-completed px-3">مكتمل</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-light btn-sm rounded-circle"><i class="fas fa-ellipsis-v"></i></button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>