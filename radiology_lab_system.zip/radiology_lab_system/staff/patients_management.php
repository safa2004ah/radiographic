<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_patients')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add' || $action == 'edit') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'] ?? 'patient123';
        $full_name = $_POST['full_name'];
        $phone = $_POST['phone'] ?? '';
        $address = $_POST['address'] ?? '';
        $gender = $_POST['gender'] ?? '';
        $birth_date = $_POST['birth_date'] ?? '';
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        if ($action == 'add') {
            $query = "INSERT INTO users (username, email, password, full_name, role, phone, address, gender, birth_date, status) 
                      VALUES (?, ?, ?, ?, 'patient', ?, ?, ?, ?, 'active')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssssssss", $username, $email, $hashed_password, $full_name, $phone, $address, $gender, $birth_date);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة المريض بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة المريض';
            }
        } else {
            $patient_id = $_POST['patient_id'];
            $query = "UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, address = ?, gender = ?, birth_date = ? 
                      WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssssssi", $username, $email, $full_name, $phone, $address, $gender, $birth_date, $patient_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل المريض بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل المريض';
            }
        }
    }
}

// جلب جميع المرضى
$patients = $conn->query("SELECT * FROM users WHERE role = 'patient' ORDER BY created_at DESC");

// جلب السجلات الطبية
function getMedicalRecordsCount($conn, $patient_id) {
    $query = "SELECT COUNT(*) as count FROM medical_records WHERE patient_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['count'];
}

// جلب المواعيد
function getAppointmentsCount($conn, $patient_id) {
    $query = "SELECT COUNT(*) as count FROM appointments WHERE patient_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['count'];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المرضى - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        /* تثبيت القائمة الجانبية على اليمين */
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        /* إعطاء مساحة للمحتوى الرئيسي ليتجنب التداخل */
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
        <div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 sidebar-col shadow">
            <?php include 'sidebar.php'; ?>
        </div>
            <!-- المحتوى الرئيسي -->
            <main class="main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة المرضى</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#patientModal" onclick="resetForm()">
                        <i class="fas fa-plus me-2"></i>إضافة مريض جديد
                    </button>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- فلاتر البحث -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="searchInput" placeholder="بحث عن مريض..." 
                                       onkeyup="searchTable('searchInput', 'patientsTable')">
                            </div>
                            <div class="col-md-6">
                                <select class="form-select" id="genderFilter" onchange="filterByGender()">
                                    <option value="">تحديد الجنس</option>
                                    <option value="male">ذكر</option>
                                    <option value="female">أنثى</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- جدول المرضى -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover" id="patientsTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم المريض</th>
                                        <th>اسم المستخدم</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>رقم الهاتف</th>
                                        <th>الجنس</th>
                                        <th>السجلات الطبية</th>
                                        <th>المواعيد</th>
                                        <th>تاريخ التسجيل</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php while ($patient = $patients->fetch_assoc()): ?>
                                        <tr data-gender="<?php echo $patient['gender'] ?? ''; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong><?php echo $patient['full_name']; ?></strong></td>
                                            <td><?php echo $patient['username']; ?></td>
                                            <td><?php echo $patient['email']; ?></td>
                                            <td><?php echo $patient['phone'] ?? '-'; ?></td>
                                            <td>
                                                <?php if ($patient['gender'] == 'male'): ?>
                                                    <span class="badge bg-primary">ذكر</span>
                                                <?php elseif ($patient['gender'] == 'female'): ?>
                                                    <span class="badge bg-danger">أنثى</span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-success">
                                                    <?php echo getMedicalRecordsCount($conn, $patient['id']); ?> سجل
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo getAppointmentsCount($conn, $patient['id']); ?> موعد
                                                </span>
                                            </td>
                                            <td><?php echo date('d/m/Y', strtotime($patient['created_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary me-1" 
                                                        onclick="editPatient(<?php echo htmlspecialchars(json_encode($patient)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نموذج إضافة/تعديل مريض -->
    <div class="modal fade" id="patientModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">إضافة مريض جديد</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="patient_id" id="patientId">
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">اسم المستخدم <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="username" id="username" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">البريد الإلكتروني <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" name="email" id="email" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">الاسم الكامل <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="full_name" id="fullName" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">كلمة المرور</label>
                                <input type="password" class="form-control" name="password" id="password" 
                                       placeholder="patient123 (افتراضي)">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="text" class="form-control" name="phone" id="phone">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">العنوان</label>
                                <input type="text" class="form-control" name="address" id="address">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">الجنس</label>
                                <select class="form-select" name="gender" id="gender">
                                    <option value="">اختر...</option>
                                    <option value="male">ذكر</option>
                                    <option value="female">أنثى</option>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">تاريخ الميلاد</label>
                                <input type="date" class="form-control" name="birth_date" id="birthDate">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="saveButtonText">حفظ المريض</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').textContent = 'إضافة مريض جديد';
            document.getElementById('saveButtonText').textContent = 'حفظ المريض';
            document.querySelector('form').reset();
        }

        function editPatient(patient) {
            document.getElementById('formAction').value = 'edit';
            document.getElementById('modalTitle').textContent = 'تعديل مريض';
            document.getElementById('saveButtonText').textContent = 'تعديل المريض';
            document.getElementById('patientId').value = patient.id;
            document.getElementById('username').value = patient.username;
            document.getElementById('email').value = patient.email;
            document.getElementById('fullName').value = patient.full_name;
            document.getElementById('phone').value = patient.phone || '';
            document.getElementById('address').value = patient.address || '';
            document.getElementById('gender').value = patient.gender || '';
            document.getElementById('birthDate').value = patient.birth_date || '';
            new bootstrap.Modal(document.getElementById('patientModal')).show();
        }

        function viewMedicalRecords(id) {
            window.location.href = 'medical_records.php?patient_id=' + id;
        }

        function filterByGender() {
            const gender = document.getElementById('genderFilter').value;
            const rows = document.querySelectorAll('#patientsTable tbody tr');
            
            rows.forEach(row => {
                if (!gender || row.dataset.gender === gender) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>