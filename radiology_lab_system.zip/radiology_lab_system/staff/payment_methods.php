<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_invoices')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف والتفعيل
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add' || $action == 'edit') {
        $name = $_POST['name'];
        $description = $_POST['description'] ?? '';
        
        if ($action == 'add') {
            $query = "INSERT INTO payment_methods (name, description, status) VALUES (?, ?, 'active')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $name, $description);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة طريقة الدفع بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة طريقة الدفع';
            }
        } else {
            $method_id = $_POST['method_id'];
            $query = "UPDATE payment_methods SET name = ?, description = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $name, $description, $method_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل طريقة الدفع بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل طريقة الدفع';
            }
        }
    } elseif ($action == 'delete') {
        $method_id = $_POST['method_id'];
        $query = "DELETE FROM payment_methods WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $method_id);
        
        if ($stmt->execute()) {
            $success = 'تم حذف طريقة الدفع بنجاح';
        } else {
            $error = 'حدث خطأ أثناء حذف طريقة الدفع';
        }
    } elseif ($action == 'toggle_status') {
        $method_id = $_POST['method_id'];
        $query = "UPDATE payment_methods SET status = CASE status WHEN 'active' THEN 'inactive' ELSE 'active' END WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $method_id);
        
        if ($stmt->execute()) {
            $success = 'تم تغيير حالة طريقة الدفع بنجاح';
        } else {
            $error = 'حدث خطأ أثناء تغيير الحالة';
        }
    }
}

// جلب جميع طرق الدفع
$payment_methods = $conn->query("SELECT * FROM payment_methods ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة طرق الدفع - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        /* تثبيت القائمة الجانبية على اليمين */
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        /* إعطاء مساحة للمحتوى الرئيسي ليتجنب التداخل */
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 sidebar-col shadow">
            <?php include 'sidebar.php'; ?>
        </div>
            <!-- المحتوى الرئيسي -->
            <main class="main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة طرق الدفع</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#methodModal" onclick="resetForm()">
                        <i class="fas fa-plus me-2"></i>إضافة طريقة دفع جديدة
                    </button>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- جدول طرق الدفع -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم طريقة الدفع</th>
                                        <th>الوصف</th>
                                        <th>الحالة</th>
                                        <th>تاريخ الإنشاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php while ($method = $payment_methods->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong><?php echo $method['name']; ?></strong></td>
                                            <td><?php echo $method['description'] ?? '-'; ?></td>
                                            <td>
                                                <?php if ($method['status'] == 'active'): ?>
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-check-circle me-1"></i>مفعل
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">
                                                        <i class="fas fa-times-circle me-1"></i>معطل
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('d/m/Y', strtotime($method['created_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary me-1" 
                                                        onclick="editMethod(<?php echo htmlspecialchars(json_encode($method)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-<?php echo $method['status'] == 'active' ? 'warning' : 'success'; ?> me-1" 
                                                        onclick="toggleStatus(<?php echo $method['id']; ?>)">
                                                    <i class="fas fa-<?php echo $method['status'] == 'active' ? 'pause' : 'play'; ?>"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" 
                                                        onclick="deleteMethod(<?php echo $method['id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نموذج إضافة/تعديل طريقة دفع -->
    <div class="modal fade" id="methodModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">إضافة طريقة دفع جديدة</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="method_id" id="methodId">
                        
                        <div class="mb-3">
                            <label class="form-label">اسم طريقة الدفع <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="saveButtonText">حفظ</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').textContent = 'إضافة طريقة دفع جديدة';
            document.getElementById('saveButtonText').textContent = 'حفظ';
            document.querySelector('form').reset();
        }

        function editMethod(method) {
            document.getElementById('formAction').value = 'edit';
            document.getElementById('modalTitle').textContent = 'تعديل طريقة الدفع';
            document.getElementById('saveButtonText').textContent = 'تعديل';
            document.getElementById('methodId').value = method.id;
            document.getElementById('name').value = method.name;
            document.getElementById('description').value = method.description || '';
            new bootstrap.Modal(document.getElementById('methodModal')).show();
        }

        function deleteMethod(id) {
            if (confirm('هل أنت متأكد من حذف هذه الطريقة؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'method_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function toggleStatus(id) {
            if (confirm('هل تريد تغيير حالة هذه الطريقة؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'toggle_status';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'method_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>