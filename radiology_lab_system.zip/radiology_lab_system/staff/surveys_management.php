<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_surveys')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add_survey' || $action == 'edit_survey') {
        $title = $_POST['title'];
        $description = $_POST['description'] ?? '';
        
        if ($action == 'add_survey') {
            $query = "INSERT INTO surveys (title, description, created_by, status) VALUES (?, ?, ?, 'active')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $title, $description, $user['id']);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة الاستبيان بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة الاستبيان';
            }
        } else {
            $survey_id = $_POST['survey_id'];
            $query = "UPDATE surveys SET title = ?, description = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $title, $description, $survey_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل الاستبيان بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل الاستبيان';
            }
        }
    } elseif ($action == 'delete_survey') {
        $survey_id = $_POST['survey_id'];
        $query = "DELETE FROM surveys WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $survey_id);
        
        if ($stmt->execute()) {
            $success = 'تم حذف الاستبيان بنجاح';
        } else {
            $error = 'حدث خطأ أثناء حذف الاستبيان';
        }
    } elseif ($action == 'toggle_survey_status') {
        $survey_id = $_POST['survey_id'];
        $query = "UPDATE surveys SET status = CASE status WHEN 'active' THEN 'inactive' ELSE 'active' END WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $survey_id);
        
        if ($stmt->execute()) {
            $success = 'تم تغيير حالة الاستبيان بنجاح';
        } else {
            $error = 'حدث خطأ أثناء تغيير الحالة';
        }
    }
}

// جلب جميع الاستبيانات
$surveys = $conn->query("SELECT s.*, u.full_name as creator_name, COUNT(DISTINCT sq.id) as questions_count, COUNT(DISTINCT sr.id) as responses_count
                         FROM surveys s
                         JOIN users u ON s.created_by = u.id
                         LEFT JOIN survey_questions sq ON s.id = sq.survey_id
                         LEFT JOIN survey_responses sr ON s.id = sr.survey_id
                         GROUP BY s.id
                         ORDER BY s.created_at DESC");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الاستبيانات - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        /* تثبيت القائمة الجانبية على اليمين */
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; }
        /* إعطاء مساحة للمحتوى الرئيسي ليتجنب التداخل */
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) {
            .sidebar-col { display: none; }
            .main-content { margin-right: 0; width: 100%; }
        }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
    <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2 sidebar-col shadow">
                    <?php include 'sidebar.php'; ?>
                </div>

            <!-- المحتوى الرئيسي -->
            <main class="main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة استبيانات رضا المرضى</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#surveyModal" onclick="resetForm()">
                        <i class="fas fa-plus me-2"></i>إضافة استبيان جديد
                    </button>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- جدول الاستبيانات -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>عنوان الاستبيان</th>
                                        <th>الوصف</th>
                                        <th>الأسئلة</th>
                                        <th>الردود</th>
                                        <th>الحالة</th>
                                        <th>تاريخ الإنشاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php while ($survey = $surveys->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong><?php echo $survey['title']; ?></strong></td>
                                            <td><?php echo mb_substr($survey['description'], 0, 50, 'UTF-8') . '...'; ?></td>
                                            <td>
                                                <span class="badge bg-primary">
                                                    <i class="fas fa-question-circle me-1"></i><?php echo $survey['questions_count']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-success">
                                                    <i class="fas fa-reply me-1"></i><?php echo $survey['responses_count']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($survey['status'] == 'active'): ?>
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-check-circle me-1"></i>نشط
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">
                                                        <i class="fas fa-times-circle me-1"></i>معطل
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('d/m/Y', strtotime($survey['created_at'])); ?></td>
                                            <td>
                                                <a href="survey_questions.php?survey_id=<?php echo $survey['id']; ?>" 
                                                   class="btn btn-sm btn-info me-1">
                                                    <i class="fas fa-edit"></i> الأسئلة
                                                </a>
                                                <button class="btn btn-sm btn-primary me-1" 
                                                        onclick="editSurvey(<?php echo htmlspecialchars(json_encode($survey)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-<?php echo $survey['status'] == 'active' ? 'warning' : 'success'; ?> me-1" 
                                                        onclick="toggleSurveyStatus(<?php echo $survey['id']; ?>)">
                                                    <i class="fas fa-<?php echo $survey['status'] == 'active' ? 'pause' : 'play'; ?>"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" 
                                                        onclick="deleteSurvey(<?php echo $survey['id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نموذج إضافة/تعديل استبيان -->
    <div class="modal fade" id="surveyModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">إضافة استبيان جديد</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add_survey">
                        <input type="hidden" name="survey_id" id="surveyId">
                        
                        <div class="mb-3">
                            <label class="form-label">عنوان الاستبيان <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="title" id="title" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="saveButtonText">حفظ الاستبيان</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add_survey';
            document.getElementById('modalTitle').textContent = 'إضافة استبيان جديد';
            document.getElementById('saveButtonText').textContent = 'حفظ الاستبيان';
            document.querySelector('form').reset();
        }

        function editSurvey(survey) {
            document.getElementById('formAction').value = 'edit_survey';
            document.getElementById('modalTitle').textContent = 'تعديل استبيان';
            document.getElementById('saveButtonText').textContent = 'تعديل الاستبيان';
            document.getElementById('surveyId').value = survey.id;
            document.getElementById('title').value = survey.title;
            document.getElementById('description').value = survey.description || '';
            new bootstrap.Modal(document.getElementById('surveyModal')).show();
        }

        function deleteSurvey(id) {
            if (confirm('هل أنت متأكد من حذف هذا الاستبيان؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_survey';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'survey_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function toggleSurveyStatus(id) {
            if (confirm('هل تريد تغيير حالة هذا الاستبيان؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'toggle_survey_status';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'survey_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>