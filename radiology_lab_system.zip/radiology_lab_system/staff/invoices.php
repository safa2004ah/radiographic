<?php
require_once '../includes/config.php';
require_once '../libs/tcpdf/tcpdf.php'; 

// التحقق من الصلاحيات
if (!checkPermission('manage_invoices')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// معالجة الإضافة والتعديل والحذف وتصدير PDF
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add' || $action == 'edit') {
        $patient_id = $_POST['patient_id'];
        $amount = $_POST['amount'];
        $payment_method_id = !empty($_POST['payment_method_id']) ? $_POST['payment_method_id'] : null;
        $description = $_POST['description'] ?? '';
        $status = $_POST['status'] ?? 'pending';
        
        if ($action == 'add') {
            $invoice_number = 'INV-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $query = "INSERT INTO invoices (patient_id, staff_id, invoice_number, amount, payment_method_id, description, status) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iisdiss", $patient_id, $user['id'], $invoice_number, $amount, $payment_method_id, $description, $status);
            
            if ($stmt->execute()) {
                $success = 'تم إضافة الفاتورة بنجاح';
            } else {
                $error = 'حدث خطأ أثناء إضافة الفاتورة';
            }
        } else {
            $invoice_id = $_POST['invoice_id'];
            $query = "UPDATE invoices SET patient_id = ?, amount = ?, payment_method_id = ?, 
                      description = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("idissi", $patient_id, $amount, $payment_method_id, $description, $status, $invoice_id);
            
            if ($stmt->execute()) {
                $success = 'تم تعديل الفاتورة بنجاح';
            } else {
                $error = 'حدث خطأ أثناء تعديل الفاتورة';
            }
        }
    } elseif ($action == 'export') {
        $invoice_id = $_POST['invoice_id'];
        $query = "SELECT i.*, p.full_name as patient_name, p.phone as patient_phone, pm.name as payment_method_name
                  FROM invoices i
                  JOIN users p ON i.patient_id = p.id
                  LEFT JOIN payment_methods pm ON i.payment_method_id = pm.id
                  WHERE i.id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $invoice_id);
        $stmt->execute();
        $inv = $stmt->get_result()->fetch_assoc();

        if ($inv) {
            $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
            $pdf->SetCreator(SITE_NAME);
            $pdf->SetTitle('فاتورة رقم ' . $inv['invoice_number']);
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            $pdf->SetFont('aealarabiya', '', 12); 
            $pdf->AddPage();
            $pdf->setRTL(true);
            $status_txt = ($inv['status'] == 'paid') ? 'مدفوعة' : (($inv['status'] == 'pending') ? 'قيد الانتظار' : 'ملغاة');
            $html = '<h1 style="text-align:center; color:#1a237e;">مخبر الأشعة التخصصي</h1><h3 style="text-align:center;">فاتورة ضريبية</h3><hr>
            <table cellpadding="5">
                <tr><td><b>رقم الفاتورة:</b> '.$inv['invoice_number'].'</td><td style="text-align:left;"><b>التاريخ:</b> '.date('d/m/Y', strtotime($inv['created_at'])).'</td></tr>
                <tr><td><b>المريض:</b> '.$inv['patient_name'].'</td><td style="text-align:left;"><b>الهاتف:</b> '.$inv['patient_phone'].'</td></tr>
                <tr><td><b>طريقة الدفع:</b> '.($inv['payment_method_name'] ?? 'غير محدد').'</td><td style="text-align:left;"><b>الحالة:</b> '.$status_txt.'</td></tr>
            </table>
            <br><br>
            <table border="1" cellpadding="8">
                <tr style="background-color:#f2f2f2; font-weight:bold; text-align:center;"><th width="70%">البيان / الوصف</th><th width="30%">المبلغ</th></tr>
                <tr><td>'.$inv['description'].'</td><td style="text-align:center;">'.number_format($inv['amount'], 0, ',', '.').' ل.س</td></tr>
                <tr style="font-weight:bold; font-size:14px;"><td style="text-align:left; background-color:#f2f2f2;">الإجمالي الكلي</td><td style="text-align:center; background-color:#f2f2f2;">'.number_format($inv['amount'], 0, ',', '.').' ل.س</td></tr>
            </table>';
            $pdf->writeHTML($html, true, false, true, false, '');
            ob_end_clean();
            $pdf->Output('Invoice_'.$inv['invoice_number'].'.pdf', 'D');
            exit;
        }
    }
}

// جلب البيانات
$invoices = $conn->query("SELECT i.*, p.full_name as patient_name, pm.name as payment_method_name FROM invoices i JOIN users p ON i.patient_id = p.id LEFT JOIN payment_methods pm ON i.payment_method_id = pm.id ORDER BY i.created_at DESC");
$patients = $conn->query("SELECT id, full_name, phone FROM users WHERE role = 'patient' AND status = 'active' ORDER BY full_name");
$payment_methods = $conn->query("SELECT id, name FROM payment_methods WHERE status = 'active'");
$total_invoices = $conn->query("SELECT COUNT(*) as count FROM invoices")->fetch_assoc()['count'];
$paid_invoices = $conn->query("SELECT COUNT(*) as count FROM invoices WHERE status = 'paid'")->fetch_assoc()['count'];
$total_amount = $conn->query("SELECT SUM(amount) as sum FROM invoices")->fetch_assoc()['sum'];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الفواتير - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root { --sidebar-bg: #1a237e; --main-bg: #f8f9fa; }
        body { background-color: var(--main-bg); font-family: 'Segoe UI', Tahoma, sans-serif; overflow-x: hidden; }
        .sidebar-col { background-color: var(--sidebar-bg); min-height: 100vh; padding: 0; position: fixed; top: 0; right: 0; z-index: 1000; width: 16.666667%; }
        .main-content { margin-right: 16.666667%; padding: 2rem; width: 83.333333%; }
        @media (max-width: 991.98px) { .sidebar-col { display: none; } .main-content { margin-right: 0; width: 100%; } }
        .card-custom { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 sidebar-col shadow">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content">
                <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-4 border-bottom">
                    <h1 class="h2 fw-bold">إدارة الفواتير</h1>
                    <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#invoiceModal" onclick="resetForm()">
                        <i class="fas fa-plus ms-2"></i>إضافة فاتورة جديدة
                    </button>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show rounded-pill px-4" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show rounded-pill px-4" role="alert">
                        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row g-3 mb-4">
                    <div class="col-md-4"><div class="card bg-primary text-white card-custom"><div class="card-body p-4 text-center"><h6 class="opacity-75">إجمالي الفواتير</h6><h2 class="fw-bold mb-0"><?php echo $total_invoices; ?></h2></div></div></div>
                    <div class="col-md-4"><div class="card bg-success text-white card-custom"><div class="card-body p-4 text-center"><h6 class="opacity-75">الفواتير المدفوعة</h6><h2 class="fw-bold mb-0"><?php echo $paid_invoices; ?></h2></div></div></div>
                    <div class="col-md-4"><div class="card bg-info text-white card-custom"><div class="card-body p-4 text-center"><h6 class="opacity-75">إجمالي المبلغ المحصل</h6><h4 class="fw-bold mb-0"><?php echo number_format($total_amount, 0, ',', '.'); ?> ل.س</h4></div></div></div>
                </div>

                <div class="card mb-4 card-custom">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control rounded-pill" id="searchInput" 
                                    placeholder="بحث عن فاتورة (رقم الفاتورة أو اسم المريض)..." 
                                    onkeyup="searchTable('searchInput', 'invoicesTable')">
                            </div>
                            <div class="col-md-6">
                                <select class="form-select rounded-pill" id="statusFilter" onchange="filterByStatus()">
                                    <option value="">جميع الحالات</option>
                                    <option value="pending">قيد الانتظار</option>
                                    <option value="paid">مدفوعة</option>
                                    <option value="cancelled">ملغاة</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-custom">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover" id="invoicesTable">
                                <thead>
                                    <tr>
                                        <th>رقم الفاتورة</th>
                                        <th>المريض</th>
                                        <th>المبلغ</th>
                                        <th>طريقة الدفع</th>
                                        <th>الحالة</th>
                                        <th>التاريخ</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($invoice = $invoices->fetch_assoc()): ?>
                                        <tr data-status="<?php echo $invoice['status']; ?>">
                                            <td class="fw-bold"><?php echo $invoice['invoice_number']; ?></td>
                                            <td><?php echo $invoice['patient_name']; ?></td>
                                            <td class="text-primary fw-bold"><?php echo number_format($invoice['amount'], 0, ',', '.'); ?> ل.س</td>
                                            <td><span class="badge bg-light text-dark border"><?php echo $invoice['payment_method_name'] ?? '-'; ?></span></td>
                                            <td>
                                                <?php
                                                $s_badge = ['pending' => 'warning', 'paid' => 'success', 'cancelled' => 'danger'];
                                                $s_text = ['pending' => 'قيد الانتظار', 'paid' => 'مدفوعة', 'cancelled' => 'ملغاة'];
                                                ?>
                                                <span class="badge bg-<?php echo $s_badge[$invoice['status']]; ?> rounded-pill px-3">
                                                    <?php echo $s_text[$invoice['status']]; ?>
                                                </span>
                                            </td>
                                            <td class="small"><?php echo date('Y-m-d', strtotime($invoice['created_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" onclick="editInvoice(<?php echo htmlspecialchars(json_encode($invoice)); ?>)"><i class="fas fa-edit"></i></button>
                                                <button class="btn btn-sm btn-outline-danger" onclick="exportInvoice(<?php echo $invoice['id']; ?>)"><i class="fas fa-file-pdf"></i></button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <div class="modal fade" id="invoiceModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 card-custom">
                <div class="modal-header bg-primary text-white border-0 py-3">
                    <h5 class="modal-title fw-bold" id="modalTitle">إضافة فاتورة جديدة</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body p-4">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="invoice_id" id="invoiceId">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">المريض</label>
                                <select class="form-select rounded-3" name="patient_id" id="patientId" required>
                                    <option value="">اختر المريض</option>
                                    <?php mysqli_data_seek($patients, 0); while ($p = $patients->fetch_assoc()): ?>
                                        <option value="<?php echo $p['id']; ?>"><?php echo $p['full_name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6"><label class="form-label fw-bold">المبلغ</label><input type="number" class="form-control rounded-3" name="amount" id="amount" required></div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">طريقة الدفع</label>
                                <select class="form-select rounded-3" name="payment_method_id" id="paymentMethodId">
                                    <option value="">اختر طريقة الدفع</option>
                                    <?php mysqli_data_seek($payment_methods, 0); while ($m = $payment_methods->fetch_assoc()): ?>
                                        <option value="<?php echo $m['id']; ?>"><?php echo $m['name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">الحالة</label>
                                <select class="form-select rounded-3" name="status" id="status">
                                    <option value="pending">قيد الانتظار</option>
                                    <option value="paid">مدفوعة</option>
                                    <option value="cancelled">ملغاة</option>
                                </select>
                            </div>
                            <div class="col-12"><label class="form-label fw-bold">الوصف</label><textarea class="form-control rounded-3" name="description" id="description" rows="3"></textarea></div>
                        </div>
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold" id="saveButtonText">حفظ الفاتورة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function resetForm() {
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').textContent = 'إضافة فاتورة جديدة';
            document.getElementById('saveButtonText').textContent = 'حفظ الفاتورة';
            document.querySelector('form').reset();
        }
        function editInvoice(inv) {
            document.getElementById('formAction').value = 'edit';
            document.getElementById('modalTitle').textContent = 'تعديل فاتورة';
            document.getElementById('saveButtonText').textContent = 'تعديل الفاتورة';
            document.getElementById('invoiceId').value = inv.id;
            document.getElementById('patientId').value = inv.patient_id;
            document.getElementById('amount').value = inv.amount;
            document.getElementById('paymentMethodId').value = inv.payment_method_id || '';
            document.getElementById('status').value = inv.status;
            document.getElementById('description').value = inv.description || '';
            new bootstrap.Modal(document.getElementById('invoiceModal')).show();
        }
        function filterByStatus() {
            const status = document.getElementById('statusFilter').value;
            const rows = document.querySelectorAll('#invoicesTable tbody tr');
            rows.forEach(row => {
                row.style.display = (!status || row.dataset.status === status) ? '' : 'none';
            });
        }
        function exportInvoice(id) {
            const f = document.createElement('form'); f.method='POST';
            f.innerHTML = `<input type="hidden" name="action" value="export"><input type="hidden" name="invoice_id" value="${id}">`;
            document.body.appendChild(f); f.submit();
        }
    </script>
</body>
</html>