<?php
require_once '../includes/config.php';

// التحقق من الصلاحيات
if (!checkPermission('manage_invoices')) {
    die('غير مصرح بالدخول');
}

$conn = getDBConnection();
$invoice_id = $_GET['id'] ?? 0;

// جلب بيانات الفاتورة
$query = "SELECT i.*, p.full_name as patient_name, p.phone as patient_phone, p.address as patient_address,
                 s.full_name as staff_name, pm.name as payment_method_name
          FROM invoices i
          JOIN users p ON i.patient_id = p.id
          JOIN users s ON i.staff_id = s.id
          LEFT JOIN payment_methods pm ON i.payment_method_id = pm.id
          WHERE i.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $invoice_id);
$stmt->execute();
$invoice = $stmt->get_result()->fetch_assoc();

if (!$invoice) {
    die('الفاتورة غير موجودة');
}

// إعدادات التصدير
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Invoice_' . $invoice['invoice_number'] . '.pdf"');

// استخدام TCPDF أو FPDF لإنشاء PDF
// هنا سأستخدم طريقة بسيطة لإنشاء HTML يمكن طباعته
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فاتورة - <?php echo $invoice['invoice_number']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
            background-color: #fff;
        }
        
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #0d6efd;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #0d6efd;
        }
        
        .logo h2 {
            color: #0d6efd;
            font-size: 28px;
            font-weight: bold;
        }
        
        .invoice-info {
            text-align: left;
        }
        
        .invoice-info h3 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .invoice-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .section {
            margin-bottom: 20px;
        }
        
        .section h4 {
            color: #0d6efd;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #0d6efd;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .label {
            font-weight: bold;
            color: #555;
        }
        
        .value {
            color: #333;
        }
        
        .amount {
            font-size: 24px;
            font-weight: bold;
            color: #0d6efd;
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        
        .status-badge {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
        
        .status-pending {
            background-color: #ffc107;
            color: #000;
        }
        
        .status-paid {
            background-color: #198754;
            color: #fff;
        }
        
        .status-cancelled {
            background-color: #dc3545;
            color: #fff;
        }
        
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #0d6efd;
            text-align: center;
            color: #666;
        }
        
        @media print {
            body {
                padding: 0;
            }
            
            .invoice-container {
                border: none;
                box-shadow: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <!-- العنوان -->
        <div class="header">
            <div class="logo">
                <h2>نظام إدارة مخبر الأشعة</h2>
                <p style="color: #666; margin-top: 5px;">دمشق - سوريا</p>
                <p style="color: #666;">هاتف: +963 944 123456</p>
            </div>
            
            <div class="invoice-info">
                <h3>فاتورة رسمية</h3>
                <p style="font-size: 14px; color: #666; margin-top: 5px;">
                    رقم الفاتورة: <strong><?php echo $invoice['invoice_number']; ?></strong>
                </p>
                <p style="font-size: 14px; color: #666;">
                    التاريخ: <strong><?php echo date('d/m/Y', strtotime($invoice['created_at'])); ?></strong>
                </p>
            </div>
        </div>
        
        <!-- معلومات المريض -->
        <div class="section">
            <h4>معلومات المريض</h4>
            <div class="info-row">
                <span class="label">الاسم:</span>
                <span class="value"><?php echo $invoice['patient_name']; ?></span>
            </div>
            <div class="info-row">
                <span class="label">رقم الهاتف:</span>
                <span class="value"><?php echo $invoice['patient_phone'] ?? '-'; ?></span>
            </div>
            <div class="info-row">
                <span class="label">العنوان:</span>
                <span class="value"><?php echo $invoice['patient_address'] ?? '-'; ?></span>
            </div>
        </div>
        
        <!-- تفاصيل الفاتورة -->
        <div class="section">
            <h4>تفاصيل الفاتورة</h4>
            <div class="info-row">
                <span class="label">المبلغ:</span>
                <span class="value" style="font-size: 20px; font-weight: bold; color: #0d6efd;">
                    <?php echo number_format($invoice['amount'], 0, ',', '.'); ?> ل.س
                </span>
            </div>
            <div class="info-row">
                <span class="label">طريقة الدفع:</span>
                <span class="value"><?php echo $invoice['payment_method_name'] ?? 'غير محدد'; ?></span>
            </div>
            <div class="info-row">
                <span class="label">الحالة:</span>
                <span class="value">
                    <span class="status-badge status-<?php echo $invoice['status']; ?>">
                        <?php 
                        $status_text = [
                            'pending' => 'قيد الانتظار',
                            'paid' => 'مدفوعة',
                            'cancelled' => 'ملغاة'
                        ];
                        echo $status_text[$invoice['status']];
                        ?>
                    </span>
                </span>
            </div>
        </div>
        
        <!-- الوصف -->
        <?php if (!empty($invoice['description'])): ?>
        <div class="section">
            <h4>الوصف</h4>
            <p style="line-height: 1.6; color: #555; margin-top: 10px;">
                <?php echo nl2br($invoice['description']); ?>
            </p>
        </div>
        <?php endif; ?>
        
        <!-- المبلغ الإجمالي -->
        <div class="amount">
            المبلغ الإجمالي: <?php echo number_format($invoice['amount'], 0, ',', '.'); ?> ل.س
        </div>
        
        <!-- معلومات الموظف -->
        <div class="section">
            <h4>معلومات الموظف</h4>
            <div class="info-row">
                <span class="label">اسم الموظف:</span>
                <span class="value"><?php echo $invoice['staff_name']; ?></span>
            </div>
            <div class="info-row">
                <span class="label">تاريخ الإنشاء:</span>
                <span class="value"><?php echo date('d/m/Y h:i A', strtotime($invoice['created_at'])); ?></span>
            </div>
        </div>
        
        <!-- التوقيع -->
        <div style="margin-top: 50px; text-align: center;">
            <p style="font-weight: bold; color: #0d6efd; margin-bottom: 5px;">شكراً لثقتك</p>
            <p style="color: #666; font-size: 14px;">نأمل أن تكون الخدمة قد نالت رضاك</p>
        </div>
        
        <!-- الفوتر -->
        <div class="footer">
            <p>© 2026 نظام إدارة مخبر الأشعة - جميع الحقوق محفوظة</p>
            <p style="margin-top: 5px; font-size: 12px;">هذه فاتورة إلكترونية - صالح للتقديم</p>
        </div>
    </div>
    
    <script>
        // طباعة تلقائية عند التحميل
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>