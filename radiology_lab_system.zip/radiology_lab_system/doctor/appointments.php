<?php
require_once '../includes/config.php';

if (!checkPermission('doctor_dashboard')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser(); //
$conn = getDBConnection(); //
$doctor_id = $_SESSION['user_id']; //

// جلب المواعيد الخاصة بهذا الطبيب فقط
$query = "SELECT a.*, u.full_name as patient_name, u.gender 
          FROM appointments a 
          JOIN users u ON a.patient_id = u.id 
          WHERE a.doctor_id = $doctor_id 
          ORDER BY a.appointment_date DESC, a.appointment_time DESC";
$appointments = $conn->query($query); //
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المواعيد - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        /* التنسيق الموحد للمنطقة الرئيسية ليتناسب مع القائمة الجانبية الثابتة */
        .main-content { margin-right: 16.66%; padding: 2rem; min-height: 100vh; }
        .sidebar-fixed { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .table thead { background-color: #1a237e; color: white; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>

            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h2 class="fw-bold text-dark">
                        <i class="fas fa-calendar-check text-primary me-2"></i> جدول المواعيد
                    </h2>
                    <div class="badge bg-white text-dark shadow-sm p-2">
                        إجمالي المواعيد: <?php echo $appointments->num_rows; ?>
                    </div>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th class="ps-4">المريض</th>
                                        <th>التاريخ</th>
                                        <th>الوقت</th>
                                        <th>الحالة</th>
                                        <th class="text-center">الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($appointments->num_rows > 0): ?>
                                        <?php while($row = $appointments->fetch_assoc()): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="fw-bold"><?php echo htmlspecialchars($row['patient_name']); ?></div>
                                                <small class="text-muted"><?php echo $row['gender'] == 'male' ? 'ذكر' : 'أنثى'; ?></small>
                                            </td>
                                            <td><?php echo $row['appointment_date']; ?></td>
                                            <td><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></td>
                                            <td>
                                                <?php 
                                                $status_class = 'bg-secondary';
                                                $status_text = $row['status'];
                                                if($row['status'] == 'completed') { $status_class = 'bg-success'; $status_text = 'مكتمل'; }
                                                elseif($row['status'] == 'pending') { $status_class = 'bg-warning text-dark'; $status_text = 'قيد الانتظار'; }
                                                elseif($row['status'] == 'cancelled') { $status_class = 'bg-danger'; $status_text = 'ملغي'; }
                                                ?>
                                                <span class="badge <?php echo $status_class; ?> rounded-pill px-3">
                                                    <?php echo $status_text; ?>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <a href="medical_records.php?patient_id=<?php echo $row['patient_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-file-medical me-1"></i> السجل الطبي
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-5 text-muted">
                                                <i class="fas fa-calendar-times fa-3x mb-3"></i>
                                                <p>لا توجد مواعيد مسجلة حالياً.</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>