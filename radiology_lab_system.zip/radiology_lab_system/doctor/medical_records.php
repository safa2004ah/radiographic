<?php
require_once '../includes/config.php';

// التحقق من الجلسة والدور لضمان صلاحية الوصول
if (!checkPermission('manage_medical_records')) { 
    header('Location: ../login.php'); 
    exit; 
}

$conn = getDBConnection();
$doctor_id = $_SESSION['user_id'];

// --- 1. معالجة إضافة أو تعديل السجل الطبي ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $p_id = intval($_POST['patient_id']);
    $diag = $_POST['diagnosis'];
    $rec_id = isset($_POST['record_id']) ? intval($_POST['record_id']) : null;

    if ($_POST['action'] == 'save') {
        if ($rec_id) {
            // تعديل سجل موجود
            $stmt = $conn->prepare("UPDATE medical_records SET diagnosis = ?, updated_at = NOW() WHERE id = ? AND doctor_id = ?");
            $stmt->bind_param("sii", $diag, $rec_id, $doctor_id);
        } else {
            // إضافة سجل جديد مع تاريخ الزيارة
            $stmt = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, diagnosis, visit_date, created_at) VALUES (?, ?, ?, CURDATE(), NOW())");
            $stmt->bind_param("iis", $p_id, $doctor_id, $diag);
        }
        $stmt->execute();
    }
    header("Location: medical_records.php");
    exit;
}

// --- 2. جلب المرضى وسجلاتهم (تم تعديل الحقل إلى xray_image) ---
$query = "SELECT DISTINCT u.id as patient_id, u.full_name as patient_name, u.gender, 
                 mr.id as record_id, mr.diagnosis, mr.xray_image, mr.created_at, mr.updated_at
          FROM users u 
          INNER JOIN appointments a ON u.id = a.patient_id 
          LEFT JOIN medical_records mr ON u.id = mr.patient_id AND mr.doctor_id = $doctor_id
          WHERE a.doctor_id = $doctor_id AND u.role = 'patient'
          ORDER BY u.full_name ASC";
$records = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة السجلات الطبية - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .main-content { margin-right: 16.66%; padding: 2rem; min-height: 100vh; }
        .record-card { border-radius: 15px; border: none; margin-bottom: 15px; transition: 0.2s; }
        .record-card:hover { box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important; }
        .img-preview { width: 100px; height: 100px; object-fit: cover; border-radius: 10px; cursor: pointer; }
        .sidebar-col { width: 16.66%; right: 0; top: 0; height: 100vh; position: fixed; z-index: 1000; background: #1a237e; }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                    <h2 class="fw-bold text-dark">إدارة السجلات الطبية</h2>
                    <span class="badge bg-primary px-3 py-2">عدد الحالات: <?php echo $records->num_rows; ?></span>
                </div>

                <div class="row">
                    <?php if($records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <div class="col-12">
                            <div class="card record-card shadow-sm">
                                <div class="card-body d-flex align-items-center">
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h5 class="fw-bold text-primary mb-1"><?php echo htmlspecialchars($row['patient_name']); ?></h5>
                                                <small class="text-muted">الجنس: <?php echo ($row['gender'] == 'male' ? 'ذكر' : 'أنثى'); ?></small>
                                            </div>
                                            <div class="mt-2 small text-muted">
                                                <?php if($row['record_id']): ?>
                                                    <div class="mb-1">
                                                        <i class="fas fa-calendar-plus me-1 text-success"></i> 
                                                        <strong>تاريخ أول تشخيص:</strong> <?php echo date('Y-m-d H:i', strtotime($row['created_at'])); ?>
                                                    </div>
                                                    <div class="text-primary">
                                                        <i class="fas fa-history me-1"></i> 
                                                        <strong>آخر تحديث للتقرير:</strong> <?php echo date('Y-m-d H:i', strtotime($row['updated_at'])); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3 p-3 bg-light rounded border-start border-primary border-3">
                                            <strong>التشخيص والتقرير:</strong><br>
                                            <p class="mb-0 text-secondary"><?php echo $row['diagnosis'] ? nl2br(htmlspecialchars($row['diagnosis'])) : 'لا يوجد تقرير طبي مضاف حالياً...'; ?></p>
                                        </div>

                                        <div class="mt-3">
                                            <button class="btn btn-sm btn-primary px-4" onclick='openModal(<?php echo json_encode($row); ?>)'>
                                                <i class="fas fa-edit"></i> <?php echo $row['record_id'] ? 'تعديل التقرير' : 'إضافة تقرير'; ?>
                                            </button>
                                            
                                            <?php if($row['record_id']): ?>
                                                <button onclick='printSingleRecord(<?php echo json_encode($row); ?>)' class="btn btn-sm btn-outline-dark ms-2">
                                                    <i class="fas fa-print"></i> طباعة التقرير
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <?php if(!empty($row['xray_image'])): ?>
                                        <div class="ms-4 text-center">
                                            <a href="../uploads/xrays/<?php echo $row['xray_image']; ?>" target="_blank">
                                                <img src="../uploads/xrays/<?php echo $row['xray_image']; ?>" class="img-preview border shadow-sm" title="اضغط لتكبير الصورة">
                                            </a>
                                            <small class="d-block text-muted mt-1">صورة الأشعة</small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-user-injured fa-4x text-muted mb-3"></i>
                            <p class="text-muted">لا يوجد مرضى حالياً لمراجعة سجلاتهم.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <div class="modal fade" id="recordModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <form method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="mTitle">تحديث التقرير الطبي</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4">
                        <input type="hidden" name="action" value="save">
                        <input type="hidden" name="patient_id" id="pId">
                        <input type="hidden" name="record_id" id="rId">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">اسم المريض</label>
                            <input type="text" id="pName" class="form-control bg-light" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">التشخيص الطبي والتقرير</label>
                            <textarea name="diagnosis" id="diagInput" class="form-control" rows="8" required placeholder="اكتب الوصف التفصيلي للحالة والنتائج هنا..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary px-5">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function openModal(data) {
            const modal = new bootstrap.Modal(document.getElementById('recordModal'));
            document.getElementById('pId').value = data.patient_id;
            document.getElementById('pName').value = data.patient_name;
            document.getElementById('rId').value = data.record_id || '';
            document.getElementById('diagInput').value = data.diagnosis || '';
            document.getElementById('mTitle').innerText = data.record_id ? 'تعديل التقرير الطبي' : 'إضافة تقرير طبي جديد';
            modal.show();
        }

        function printSingleRecord(data) {
            const printWin = window.open('', '', 'width=900,height=900');
            const createdDate = data.created_at ? new Date(data.created_at).toLocaleString('ar-SY') : '---';
            printWin.document.write(`
                <!DOCTYPE html>
                <html dir="rtl">
                <head>
                    <title>تقرير طبي - ${data.patient_name}</title>
                    <style>
                        body { padding: 40px; font-family: 'Arial', sans-serif; line-height: 1.6; }
                        .header { text-align: center; border-bottom: 2px solid #000; margin-bottom: 30px; }
                        .content { margin-top: 20px; font-size: 18px; }
                        .footer { margin-top: 100px; text-align: left; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>مختبر الأشعة التخصصي</h1>
                        <h3>تقرير طبي رسمي</h3>
                    </div>
                    <div class="content">
                        <p><strong>اسم المريض:</strong> ${data.patient_name}</p>
                        <p><strong>تاريخ التقرير:</strong> ${createdDate}</p>
                        <hr>
                        <h4>نتائج التشخيص:</h4>
                        <div style="white-space: pre-wrap;">${data.diagnosis}</div>
                    </div>
                    <div class="footer">
                        <p>توقيع الطبيب المختص: ............................</p>
                    </div>
                    <script>
                        window.onload = function() { window.print(); window.close(); };
                    <\/script>
                </body>
                </html>
            `);
            printWin.document.close();
        }
    </script>
</body>
</html>