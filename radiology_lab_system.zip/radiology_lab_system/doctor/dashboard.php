<?php
require_once '../includes/config.php';
require_once '../includes/ai_prediction.php';

if (!checkPermission('doctor_dashboard')) {
    header('Location: ../login.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();
$doctor_id = $user['id'];

// إحصائيات
$records_count = $conn->query("SELECT COUNT(*) as count FROM medical_records WHERE doctor_id = $doctor_id")->fetch_assoc()['count'];
$today = date('Y-m-d');
$appointments_today = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE doctor_id = $doctor_id AND appointment_date = '$today'")->fetch_assoc()['count'];

// التنبؤ الذكي
$ai = new AIPrediction();
$prediction = $ai->predictPatients(1); // مثال للقسم الأول
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        .main-content { margin-right: 16.66%; padding: 30px; }
        .stat-card { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); transition: 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
        .ai-section { background: linear-gradient(45deg, #1a237e, #3949ab); color: white; border-radius: 15px; padding: 20px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-5">
                    <h2 class="fw-bold text-primary">مرحباً د. <?php echo $user['full_name']; ?></h2>
                    <div class="badge bg-white text-dark p-2 shadow-sm"><?php echo date('Y/m/d'); ?></div>
                </div>

                <div class="ai-section mb-4 shadow">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4><i class="fas fa-robot me-2"></i> مساعد الذكاء الاصطناعي</h4>
                            <p class="mb-0">بناءً على البيانات التاريخية، يتوقع النظام استقبال <strong><?php echo $prediction['predicted_count']; ?></strong> مريض الشهر القادم بنسبة ثقة <?php echo $prediction['confidence']; ?>%.</p>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card stat-card p-3 border-start border-primary border-5">
                            <h6 class="text-muted">مواعيد اليوم</h6>
                            <h2 class="fw-bold"><?php echo $appointments_today; ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card p-3 border-start border-success border-5">
                            <h6 class="text-muted">إجمالي السجلات</h6>
                            <h2 class="fw-bold"><?php echo $records_count; ?></h2>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>