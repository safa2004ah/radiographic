<?php
require_once '../includes/config.php';

if (!checkPermission('doctor_dashboard')) { header('Location: ../login.php'); exit; }

$conn = getDBConnection();
$doctor_id = $_SESSION['user_id'];
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// استعلام لجلب المرضى الذين لديهم سجلات أو مواعيد مع هذا الطبيب مع تفعيل البحث
$query = "SELECT DISTINCT u.id, u.full_name, u.phone, u.gender, u.email 
          FROM users u 
          LEFT JOIN medical_records mr ON u.id = mr.patient_id 
          LEFT JOIN appointments a ON u.id = a.patient_id
          WHERE (mr.doctor_id = $doctor_id OR a.doctor_id = $doctor_id) ";

if (!empty($search)) {
    $query .= " AND (u.full_name LIKE '%$search%' OR u.phone LIKE '%$search%')";
}
$patients = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة المرضى - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .main-content { margin-right: 16.66%; padding: 2rem; }
        .patient-card { border: none; border-radius: 15px; transition: 0.3s; background: #fff; }
        .patient-card:hover { box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .search-box { border-radius: 25px; padding-right: 45px; }
        .search-icon { position: absolute; right: 15px; top: 12px; color: #aaa; }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold">قائمة المرضى</h2>
                    <form action="" method="GET" class="position-relative w-25">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" name="search" class="form-control search-box shadow-sm" placeholder="ابحث بالاسم أو الهاتف..." value="<?php echo htmlspecialchars($search); ?>">
                    </form>
                </div>

                <div class="table-responsive shadow-sm bg-white rounded-4">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th class="p-3">اسم المريض</th>
                                <th>الجنس</th>
                                <th>رقم الهاتف</th>
                                <th>البريد الإلكتروني</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($patients->num_rows > 0): ?>
                                <?php while($row = $patients->fetch_assoc()): ?>
                                <tr>
                                    <td class="p-3 fw-bold"><?php echo $row['full_name']; ?></td>
                                    <td><?php echo $row['gender'] == 'male' ? 'ذكر' : 'أنثى'; ?></td>
                                    <td><?php echo $row['phone']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td class="text-center">
                                        <a href="medical_records.php?patient_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-soft-primary">
                                            <i class="fas fa-file-medical"></i> السجلات
                                        </a>
                                        <a href="upload_xray.php?patient_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-soft-success">
                                            <i class="fas fa-plus"></i> فحص جديد
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center py-5">لم يتم العثور على مرضى بهذا الاسم.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
</body>
</html>