<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="d-flex flex-column flex-shrink-0 p-3 text-white shadow-sm" style="width: 100%; min-height: 100vh; background: linear-gradient(180deg, #1a237e 0%, #283593 100%);">
    <div class="text-center mb-4">
        <div class="bg-white rounded-circle d-inline-block p-3 mb-2 shadow-sm">
            <i class="fas fa-user-md fa-3x text-primary"></i>
        </div>
        <h5 class="fw-bold mb-0">بوابة الطبيب</h5>
        <small class="opacity-75"><?php echo $_SESSION['user_name'] ?? 'دكتور'; ?></small>
    </div>
    <hr class="opacity-25">
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item mb-2">
            <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active bg-white text-primary shadow' : 'text-white hover-opacity'; ?>">
                <i class="fas fa-th-large me-2"></i> لوحة التحكم
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="appointments.php" class="nav-link <?php echo $current_page == 'appointments.php' ? 'active bg-white text-primary shadow' : 'text-white hover-opacity'; ?>">
                <i class="fas fa-calendar-alt me-2"></i> المواعيد
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="patients.php" class="nav-link <?php echo $current_page == 'patients.php' ? 'active bg-white text-primary shadow' : 'text-white hover-opacity'; ?>">
                <i class="fas fa-users me-2"></i> قائمة المرضى
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="medical_records.php" class="nav-link <?php echo $current_page == 'medical_records.php' ? 'active bg-white text-primary shadow' : 'text-white hover-opacity'; ?>">
                <i class="fas fa-notes-medical me-2"></i> السجلات الطبية
            </a>
        </li>
    </ul>
    
    <hr class="opacity-25">
    <ul class="nav nav-pills flex-column">
        <li class="nav-item mb-2">
            <a href="../profile.php" class="nav-link text-white hover-opacity">
                <i class="fas fa-user-circle me-2"></i> الملف الشخصي
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="../change_password.php" class="nav-link text-white hover-opacity">
                <i class="fas fa-key me-2"></i> تغيير كلمة المرور
            </a>
        </li>
        <li class="nav-item">
            <a href="../logout.php" class="nav-link text-danger fw-bold hover-opacity">
                <i class="fas fa-sign-out-alt me-2"></i> تسجيل الخروج
            </a>
        </li>
    </ul>
</div>