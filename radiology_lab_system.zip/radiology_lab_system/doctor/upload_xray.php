<?php
require_once '../includes/config.php';

if (!checkPermission('upload_xray')) { header('Location: ../login.php'); exit; }

$conn = getDBConnection();
$doctor_id = $_SESSION['user_id'];
$msg = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_id = intval($_POST['patient_id']);
    $new_diagnosis = $_POST['diagnosis']; // التشخيص الجديد المدخل
    
    if (isset($_FILES['xray_image']) && $_FILES['xray_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['xray_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_name = "XRAY_" . time() . "_" . $patient_id . "." . $ext;
            $upload_path = "../uploads/xrays/" . $new_name;
            
            if (move_uploaded_file($_FILES['xray_image']['tmp_name'], $upload_path)) {
                // 1. البحث عن السجل الطبي القديم لجلب البيانات السابقة
                $check_stmt = $conn->prepare("SELECT id, diagnosis FROM medical_records WHERE patient_id = ? AND doctor_id = ? LIMIT 1");
                $check_stmt->bind_param("ii", $patient_id, $doctor_id);
                $check_stmt->execute();
                $result = $check_stmt->get_result();

                if ($result->num_rows > 0) {
                    $old_data = $result->fetch_assoc();
                    $old_diagnosis = $old_data['diagnosis'];
                    
                    // 2. دمج التشخيص الجديد مع القديم بإضافة سطر فاصل وتاريخ التحديث
                    $update_tag = "\n\n--- تحديث بتاريخ " . date('Y-m-d H:i') . " ---\n";
                    $combined_diagnosis = $old_diagnosis . $update_tag . $new_diagnosis;

                    // 3. تحديث السجل (سيقوم SQL بتحديث updated_at تلقائياً)
                    $stmt = $conn->prepare("UPDATE medical_records SET diagnosis = ?, xray_image = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->bind_param("ssi", $combined_diagnosis, $new_name, $old_data['id']);
                } else {
                    // إنشاء سجل لأول مرة إذا لم يكن موجوداً
                    $initial_diagnosis = "--- التشخيص الأول " . date('Y-m-d H:i') . " ---\n" . $new_diagnosis;
                    $stmt = $conn->prepare("INSERT INTO medical_records (doctor_id, patient_id, diagnosis, xray_image, visit_date, created_at, updated_at) VALUES (?, ?, ?, ?, CURDATE(), NOW(), NOW())");
                    $stmt->bind_param("iiss", $doctor_id, $patient_id, $initial_diagnosis, $new_name);
                }

                if ($stmt->execute()) {
                    $msg = "<div class='alert alert-success'>تم دمج التشخيص الجديد مع السجل الطبي ورفع الصورة بنجاح!</div>";
                }
            }
        } else {
            $msg = "<div class='alert alert-danger'>عذراً، نوع الملف غير مدعوم.</div>";
        }
    }
}

// جلب قائمة المرضى للنموذج
$patients_list = $conn->query("SELECT id, full_name FROM users WHERE role = 'patient' AND status = 'active'");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>رفع صور الأشعة - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .main-content { margin-right: 16.66%; padding: 2rem; min-height: 100vh; }
        .upload-area { border: 2px dashed #0d6efd; border-radius: 15px; padding: 2rem; background: #f0f7ff; transition: 0.3s; }
        .upload-area:hover { background: #e2efff; border-color: #0a58ca; }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 p-0 position-fixed shadow" style="right: 0; z-index: 1000;">
                <?php include 'sidebar.php'; ?>
            </div>
            <main class="main-content col-lg-10">
                <div class="card border-0 shadow-sm mx-auto rounded-4" style="max-width: 900px;">
                    <div class="card-body p-5">
                        <h3 class="fw-bold text-center mb-4 text-primary">إضافة تقرير أشعة جديد</h3>
                        <?php echo $msg; ?>
                        
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label fw-bold">اختيار المريض</label>
                                <select name="patient_id" class="form-select rounded-pill" required>
                                    <option value="">-- اختر المريض --</option>
                                    <?php while($p = $patients_list->fetch_assoc()): ?>
                                        <option value="<?php echo $p['id']; ?>" <?php echo (isset($_GET['patient_id']) && $_GET['patient_id'] == $p['id']) ? 'selected' : ''; ?>>
                                            <?php echo $p['full_name']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">صورة الأشعة</label>
                                <div class="upload-area">
                                    <i class="fas fa-cloud-upload-alt fa-3x text-primary mb-3"></i>
                                    <input type="file" name="xray_image" class="form-control" required>
                                    <small class="text-muted d-block mt-2">أنواع الملفات المدعومة: JPG, PNG (بحد أقصى 5 ميجا)</small>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">التشخيص والتقرير الطبي</label>
                                <textarea name="diagnosis" class="form-control rounded-4" rows="6" placeholder="اكتب ملاحظات التشخيص هنا..." required></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 py-3 rounded-pill fw-bold shadow">
                                <i class="fas fa-save me-2"></i> حفظ السجل الطبي نهائياً
                            </button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>