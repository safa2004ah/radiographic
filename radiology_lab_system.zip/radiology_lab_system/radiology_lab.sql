-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 25, 2026 at 12:28 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `radiology_lab`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cleanup_old_data` (IN `months` INT)   BEGIN
    DELETE FROM survey_responses 
    WHERE submitted_at < DATE_SUB(NOW(), INTERVAL months MONTH);
    
    DELETE FROM appointments 
    WHERE appointment_date < DATE_SUB(NOW(), INTERVAL months MONTH)
      AND status IN ('completed', 'cancelled');
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int NOT NULL,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `department_id` int NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `status` enum('pending','confirmed','completed','cancelled','no-show') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `staff_notes` text COLLATE utf8mb4_unicode_ci,
  `patient_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `patient_id`, `doctor_id`, `department_id`, `appointment_date`, `appointment_time`, `status`, `notes`, `staff_notes`, `patient_notes`, `created_at`, `updated_at`) VALUES
(2, 7, 4, 2, '2026-02-16', '14:30:00', 'pending', 'رنين مغناطيسي للدماغ', NULL, NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(3, 8, 5, 3, '2026-02-17', '09:00:00', 'completed', 'تصوير مقطعي للبطن', NULL, NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(4, 9, 3, 1, '2026-02-20', '11:00:00', 'confirmed', 'فحص أشعة عادية', NULL, NULL, '2026-02-01 12:53:36', '2026-02-01 12:53:36'),
(5, 10, 4, 2, '2026-02-21', '15:00:00', 'confirmed', 'رنين مغناطيسي للظهر', NULL, NULL, '2026-02-01 12:53:36', '2026-03-05 09:00:43'),
(6, 11, 5, 3, '2026-02-22', '10:30:00', 'confirmed', 'تصوير مقطعي للرأس', NULL, NULL, '2026-02-01 12:53:36', '2026-02-01 12:53:36'),
(7, 12, 3, 4, '2026-02-23', '14:00:00', 'confirmed', 'سونار للبطن', NULL, NULL, '2026-02-01 12:53:36', '2026-02-13 15:25:27'),
(8, 13, 4, 5, '2026-02-24', '09:30:00', 'confirmed', 'تصوير طبقي للصدر', NULL, NULL, '2026-02-01 12:53:36', '2026-02-01 12:53:36'),
(17, 9, 1, 1, '2025-11-10', '09:00:00', 'completed', NULL, NULL, NULL, '2025-11-09 21:00:00', '2026-03-05 09:02:13'),
(18, 8, 1, 1, '2025-11-12', '10:00:00', 'completed', NULL, NULL, NULL, '2025-11-11 21:00:00', '2026-03-05 09:02:16'),
(19, 10, 1, 1, '2025-11-15', '11:00:00', 'completed', NULL, NULL, NULL, '2025-11-14 21:00:00', '2026-03-05 09:02:21'),
(20, 9, 1, 1, '2025-11-20', '09:30:00', 'completed', NULL, NULL, NULL, '2025-11-19 21:00:00', '2026-03-05 09:02:25'),
(21, 8, 1, 1, '2025-11-25', '12:00:00', 'completed', NULL, NULL, NULL, '2025-11-24 21:00:00', '2026-03-05 09:02:27'),
(22, 12, 1, 1, '2025-12-05', '09:00:00', 'completed', NULL, NULL, NULL, '2025-12-04 21:00:00', '2026-03-05 09:02:49'),
(23, 12, 1, 1, '2025-12-08', '10:00:00', 'completed', NULL, NULL, NULL, '2025-12-07 21:00:00', '2026-03-05 09:02:52'),
(24, 15, 1, 1, '2025-12-10', '11:00:00', 'completed', NULL, NULL, NULL, '2025-12-09 21:00:00', '2026-03-05 09:02:55'),
(25, 14, 1, 1, '2025-12-12', '09:30:00', 'completed', NULL, NULL, NULL, '2025-12-11 21:00:00', '2026-03-05 09:02:58'),
(26, 9, 1, 1, '2025-12-15', '12:00:00', 'completed', NULL, NULL, NULL, '2025-12-14 21:00:00', '2026-03-05 09:03:05'),
(27, 14, 1, 1, '2025-12-20', '10:00:00', 'completed', NULL, NULL, NULL, '2025-12-19 21:00:00', '2026-03-05 09:03:01'),
(28, 15, 1, 1, '2025-12-22', '11:00:00', 'completed', NULL, NULL, NULL, '2025-12-21 21:00:00', '2026-03-05 09:03:08'),
(29, 10, 1, 1, '2025-12-28', '09:00:00', 'completed', NULL, NULL, NULL, '2025-12-27 21:00:00', '2026-03-05 09:03:10'),
(30, 11, 1, 1, '2026-01-02', '09:00:00', 'completed', NULL, NULL, NULL, '2026-01-01 21:00:00', '2026-03-05 09:03:13'),
(31, 11, 1, 1, '2026-01-05', '10:00:00', 'completed', NULL, NULL, NULL, '2026-01-04 21:00:00', '2026-03-05 09:03:14'),
(32, 12, 1, 1, '2026-01-08', '11:00:00', 'completed', NULL, NULL, NULL, '2026-01-07 21:00:00', '2026-03-05 09:03:16'),
(33, 12, 1, 1, '2026-01-10', '09:30:00', 'completed', NULL, NULL, NULL, '2026-01-09 21:00:00', '2026-03-05 09:03:21'),
(34, 10, 1, 1, '2026-01-12', '12:00:00', 'completed', NULL, NULL, NULL, '2026-01-11 21:00:00', '2026-03-05 09:03:23'),
(35, 4, 1, 1, '2026-01-15', '10:00:00', 'completed', NULL, NULL, NULL, '2026-01-14 21:00:00', '2026-02-02 11:30:35'),
(36, 3, 1, 1, '2026-01-18', '11:00:00', 'completed', NULL, NULL, NULL, '2026-01-17 21:00:00', '2026-02-02 11:30:35'),
(37, 4, 1, 1, '2026-01-20', '09:00:00', 'completed', NULL, NULL, NULL, '2026-01-19 21:00:00', '2026-02-02 11:30:35'),
(38, 3, 1, 1, '2026-01-22', '10:00:00', 'completed', NULL, NULL, NULL, '2026-01-21 21:00:00', '2026-02-02 11:30:35'),
(39, 4, 1, 1, '2026-01-25', '11:00:00', 'completed', NULL, NULL, NULL, '2026-01-24 21:00:00', '2026-02-02 11:30:35'),
(40, 3, 1, 1, '2026-01-28', '12:00:00', 'completed', NULL, NULL, NULL, '2026-01-27 21:00:00', '2026-02-02 11:30:35'),
(41, 4, 1, 1, '2026-01-30', '09:30:00', 'completed', NULL, NULL, NULL, '2026-01-29 21:00:00', '2026-02-02 11:30:35'),
(42, 12, 3, 1, '2026-02-14', '17:30:00', 'confirmed', NULL, NULL, NULL, '2026-02-13 15:24:48', '2026-03-25 12:28:26');

--
-- Triggers `appointments`
--
DELIMITER $$
CREATE TRIGGER `after_appointment_insert` AFTER INSERT ON `appointments` FOR EACH ROW BEGIN
    DECLARE patient_count INT;
    DECLARE current_month INT;
    DECLARE current_year INT;
    
    SET current_month = MONTH(NEW.appointment_date);
    SET current_year = YEAR(NEW.appointment_date);
    
    -- الحصول على عدد المرضى الحالي
    SELECT COUNT(*) INTO patient_count
    FROM appointments
    WHERE department_id = NEW.department_id
      AND MONTH(appointment_date) = current_month
      AND YEAR(appointment_date) = current_year;
    
    -- تحديث أو إدراج الإحصائيات
    INSERT INTO patient_statistics (department_id, month, year, patient_count)
    VALUES (NEW.department_id, current_month, current_year, patient_count)
    ON DUPLICATE KEY UPDATE patient_count = patient_count + 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `description`, `status`, `created_at`) VALUES
(1, 'الأشعة العادية', 'تصوير الأشعة السينية', 'active', '2026-02-01 12:00:58'),
(2, 'الرنين المغناطيسي', 'تصوير الرنين المغناطيسي', 'active', '2026-02-01 12:00:58'),
(3, 'التصوير المقطعي', 'التصوير المقطعي المحوسب', 'active', '2026-02-01 12:00:58'),
(4, 'التصوير بالموجات فوق الصوتية', 'السونار', 'active', '2026-02-01 12:00:58'),
(5, 'التصوير الطبقي', 'التصوير الطبقي المحوري', 'active', '2026-02-01 12:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int NOT NULL,
  `patient_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `invoice_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method_id` int DEFAULT NULL,
  `status` enum('pending','paid','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `patient_id`, `staff_id`, `invoice_number`, `amount`, `payment_method_id`, `status`, `description`, `created_at`, `updated_at`) VALUES
(2, 7, 2, 'INV-2026-002', 45000.00, 2, 'pending', 'رنين مغناطيسي', '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(3, 8, 1, 'INV-2026-003', 25000.00, 3, 'paid', 'تصوير مقطعي', '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(4, 9, 1, 'INV-2026-004', 12000.00, 1, 'paid', 'فحص أشعة', '2026-02-01 12:53:54', '2026-02-11 14:23:58'),
(5, 10, 2, 'INV-2026-005', 50000.00, 2, 'pending', 'رنين مغناطيسي', '2026-02-01 12:53:54', '2026-02-01 12:53:54'),
(6, 11, 1, 'INV-2026-006', 28000.00, 3, 'paid', 'تصوير مقطعي', '2026-02-01 12:53:54', '2026-02-01 12:53:54'),
(7, 12, 2, 'INV-2026-007', 18000.00, 1, 'paid', 'سونار', '2026-02-01 12:53:54', '2026-02-01 12:53:54'),
(8, 13, 1, 'INV-2026-008', 35000.00, 4, 'pending', 'تصوير طبقي', '2026-02-01 12:53:54', '2026-02-01 12:53:54');

-- --------------------------------------------------------

--
-- Table structure for table `medical_records`
--

CREATE TABLE `medical_records` (
  `id` int NOT NULL,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `appointment_id` int DEFAULT NULL,
  `visit_date` date NOT NULL,
  `diagnosis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `treatment` text COLLATE utf8mb4_unicode_ci,
  `xray_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `medical_records`
--

INSERT INTO `medical_records` (`id`, `patient_id`, `doctor_id`, `appointment_id`, `visit_date`, `diagnosis`, `treatment`, `xray_image`, `notes`, `created_at`, `updated_at`) VALUES
(2, 7, 4, 2, '2026-02-16', 'صداع نصفي', 'مسكنات وراحة', 'XRAY_1772700156_9.png', 'تحت الملاحظة', '2026-02-01 12:00:58', '2026-03-25 11:53:44'),
(3, 8, 5, 3, '2026-02-17', 'آلام في البطن', 'فحص مخبري إضافي', 'XRAY_1772700156_9.png', 'يحتاج متابعة', '2026-02-01 12:00:58', '2026-03-25 11:53:47'),
(5, 10, 4, 5, '2026-02-21', 'آلام في الظهر', 'مسكنات وراحة', 'XRAY_1772700156_9.png', 'تحت الملاحظة', '2026-02-01 12:53:45', '2026-03-25 11:53:50'),
(6, 11, 5, 6, '2026-02-22', 'صداع', 'مسكنات', 'XRAY_1772700156_9.png', 'يحتاج متابعة', '2026-02-01 12:53:45', '2026-03-25 11:53:54'),
(8, 13, 4, 8, '2026-02-24', 'سعال', 'علاج للسعال', 'XRAY_1772700156_9.png', 'تحسن ملحوظ', '2026-02-01 12:53:45', '2026-03-25 11:53:56'),
(10, 12, 3, NULL, '2026-03-25', '--- التشخيص الأول 2026-03-25 14:55 ---\nآلام في الصدر مرفقة بسعال حاد', NULL, 'XRAY_1774439757_12.jpg', NULL, '2026-03-25 11:55:57', '2026-03-25 11:55:57');

-- --------------------------------------------------------

--
-- Stand-in structure for view `monthly_statistics`
-- (See below for the actual view)
--
CREATE TABLE `monthly_statistics` (
`year` year
,`month` int
,`total_appointments` bigint
,`completed_appointments` bigint
,`cancelled_appointments` bigint
,`department_id` int
);

-- --------------------------------------------------------

--
-- Table structure for table `patient_statistics`
--

CREATE TABLE `patient_statistics` (
  `id` int NOT NULL,
  `department_id` int NOT NULL,
  `month` int NOT NULL,
  `year` int NOT NULL,
  `patient_count` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patient_statistics`
--

INSERT INTO `patient_statistics` (`id`, `department_id`, `month`, `year`, `patient_count`, `created_at`) VALUES
(1, 1, 1, 2026, 120, '2026-02-01 12:00:58'),
(2, 1, 2, 2026, 135, '2026-02-01 12:00:58'),
(3, 1, 3, 2026, 145, '2026-02-01 12:00:58'),
(4, 1, 4, 2026, 150, '2026-02-01 12:00:58'),
(5, 1, 5, 2026, 160, '2026-02-01 12:00:58'),
(6, 1, 6, 2026, 155, '2026-02-01 12:00:58'),
(7, 1, 7, 2026, 170, '2026-02-01 12:00:58'),
(8, 1, 8, 2026, 180, '2026-02-01 12:00:58'),
(9, 1, 9, 2026, 175, '2026-02-01 12:00:58'),
(10, 1, 10, 2026, 190, '2026-02-01 12:00:58'),
(11, 1, 11, 2026, 200, '2026-02-01 12:00:58'),
(12, 1, 12, 2026, 210, '2026-02-01 12:00:58'),
(13, 2, 1, 2026, 80, '2026-02-01 12:00:58'),
(14, 2, 2, 2026, 85, '2026-02-01 12:00:58'),
(15, 2, 3, 2026, 90, '2026-02-01 12:00:58'),
(16, 2, 4, 2026, 95, '2026-02-01 12:00:58'),
(17, 2, 5, 2026, 100, '2026-02-01 12:00:58'),
(18, 2, 6, 2026, 105, '2026-02-01 12:00:58'),
(19, 2, 7, 2026, 110, '2026-02-01 12:00:58'),
(20, 2, 8, 2026, 115, '2026-02-01 12:00:58'),
(21, 2, 9, 2026, 120, '2026-02-01 12:00:58'),
(22, 2, 10, 2026, 125, '2026-02-01 12:00:58'),
(23, 2, 11, 2026, 130, '2026-02-01 12:00:58'),
(24, 2, 12, 2026, 135, '2026-02-01 12:00:58'),
(25, 1, 2, 2026, 2, '2026-02-01 12:53:36'),
(26, 2, 2, 2026, 2, '2026-02-01 12:53:36'),
(27, 3, 2, 2026, 2, '2026-02-01 12:53:36'),
(28, 4, 2, 2026, 1, '2026-02-01 12:53:36'),
(29, 5, 2, 2026, 1, '2026-02-01 12:53:36'),
(30, 3, 1, 2026, 95, '2026-02-01 12:54:08'),
(31, 3, 2, 2026, 100, '2026-02-01 12:54:08'),
(32, 3, 3, 2026, 105, '2026-02-01 12:54:08'),
(33, 3, 4, 2026, 110, '2026-02-01 12:54:08'),
(34, 3, 5, 2026, 115, '2026-02-01 12:54:08'),
(35, 3, 6, 2026, 120, '2026-02-01 12:54:08'),
(36, 3, 7, 2026, 125, '2026-02-01 12:54:08'),
(37, 3, 8, 2026, 130, '2026-02-01 12:54:08'),
(38, 3, 9, 2026, 135, '2026-02-01 12:54:08'),
(39, 3, 10, 2026, 140, '2026-02-01 12:54:08'),
(40, 3, 11, 2026, 145, '2026-02-01 12:54:08'),
(41, 3, 12, 2026, 150, '2026-02-01 12:54:08'),
(42, 4, 1, 2026, 70, '2026-02-01 12:54:08'),
(43, 4, 2, 2026, 75, '2026-02-01 12:54:08'),
(44, 4, 3, 2026, 80, '2026-02-01 12:54:08'),
(45, 4, 4, 2026, 85, '2026-02-01 12:54:08'),
(46, 4, 5, 2026, 90, '2026-02-01 12:54:08'),
(47, 4, 6, 2026, 95, '2026-02-01 12:54:08'),
(48, 4, 7, 2026, 100, '2026-02-01 12:54:08'),
(49, 4, 8, 2026, 105, '2026-02-01 12:54:08'),
(50, 4, 9, 2026, 110, '2026-02-01 12:54:08'),
(51, 4, 10, 2026, 115, '2026-02-01 12:54:08'),
(52, 4, 11, 2026, 120, '2026-02-01 12:54:08'),
(53, 4, 12, 2026, 125, '2026-02-01 12:54:08'),
(54, 5, 1, 2026, 60, '2026-02-01 12:54:08'),
(55, 5, 2, 2026, 65, '2026-02-01 12:54:08'),
(56, 5, 3, 2026, 70, '2026-02-01 12:54:08'),
(57, 5, 4, 2026, 75, '2026-02-01 12:54:08'),
(58, 5, 5, 2026, 80, '2026-02-01 12:54:08'),
(59, 5, 6, 2026, 85, '2026-02-01 12:54:08'),
(60, 5, 7, 2026, 90, '2026-02-01 12:54:08'),
(61, 5, 8, 2026, 95, '2026-02-01 12:54:08'),
(62, 5, 9, 2026, 100, '2026-02-01 12:54:08'),
(63, 5, 10, 2026, 105, '2026-02-01 12:54:08'),
(64, 5, 11, 2026, 110, '2026-02-01 12:54:08'),
(65, 5, 12, 2026, 115, '2026-02-01 12:54:08'),
(66, 1, 11, 2025, 1, '2026-02-02 11:28:36'),
(67, 1, 11, 2025, 2, '2026-02-02 11:28:36'),
(68, 2, 11, 2025, 1, '2026-02-02 11:28:36'),
(69, 1, 12, 2025, 1, '2026-02-02 11:28:36'),
(70, 1, 12, 2025, 2, '2026-02-02 11:28:36'),
(71, 1, 12, 2025, 3, '2026-02-02 11:28:36'),
(72, 1, 1, 2026, 1, '2026-02-02 11:28:36'),
(73, 1, 1, 2026, 2, '2026-02-02 11:28:36'),
(74, 1, 11, 2025, 1, '2026-02-02 11:30:35'),
(75, 1, 11, 2025, 2, '2026-02-02 11:30:35'),
(76, 1, 11, 2025, 3, '2026-02-02 11:30:35'),
(77, 1, 11, 2025, 4, '2026-02-02 11:30:35'),
(78, 1, 11, 2025, 5, '2026-02-02 11:30:35'),
(79, 1, 12, 2025, 1, '2026-02-02 11:30:35'),
(80, 1, 12, 2025, 2, '2026-02-02 11:30:35'),
(81, 1, 12, 2025, 3, '2026-02-02 11:30:35'),
(82, 1, 12, 2025, 4, '2026-02-02 11:30:35'),
(83, 1, 12, 2025, 5, '2026-02-02 11:30:35'),
(84, 1, 12, 2025, 6, '2026-02-02 11:30:35'),
(85, 1, 12, 2025, 7, '2026-02-02 11:30:35'),
(86, 1, 12, 2025, 8, '2026-02-02 11:30:35'),
(87, 1, 1, 2026, 1, '2026-02-02 11:30:35'),
(88, 1, 1, 2026, 2, '2026-02-02 11:30:35'),
(89, 1, 1, 2026, 3, '2026-02-02 11:30:35'),
(90, 1, 1, 2026, 4, '2026-02-02 11:30:35'),
(91, 1, 1, 2026, 5, '2026-02-02 11:30:35'),
(92, 1, 1, 2026, 6, '2026-02-02 11:30:35'),
(93, 1, 1, 2026, 7, '2026-02-02 11:30:35'),
(94, 1, 1, 2026, 8, '2026-02-02 11:30:35'),
(95, 1, 1, 2026, 9, '2026-02-02 11:30:35'),
(96, 1, 1, 2026, 10, '2026-02-02 11:30:35'),
(97, 1, 1, 2026, 11, '2026-02-02 11:30:35'),
(98, 1, 1, 2026, 12, '2026-02-02 11:30:35'),
(99, 1, 2, 2026, 2, '2026-02-13 15:24:48');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `description`, `status`, `created_at`) VALUES
(1, 'نقداً', 'الدفع النقدي', 'active', '2026-02-01 12:00:58'),
(2, 'حوالة بنكية', 'التحويل البنكي', 'active', '2026-02-01 12:00:58'),
(3, 'دفع إلكتروني', 'الدفع عبر الإنترنت', 'active', '2026-02-01 12:00:58'),
(4, 'تأمين طبي', 'التأمين الصحي', 'active', '2026-02-01 12:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `surveys`
--

CREATE TABLE `surveys` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `surveys`
--

INSERT INTO `surveys` (`id`, `title`, `description`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'استبيان رضا المرضى', 'استبيان لتقييم جودة الخدمة', 1, 'active', '2026-02-01 12:00:58', '2026-02-02 12:15:15'),
(2, 'استبيان تقييم الأطباء', 'تقييم أداء الأطباء', 1, 'active', '2026-02-01 12:00:58', '2026-02-01 12:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `id` int NOT NULL,
  `survey_id` int NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_type` enum('text','radio','checkbox','rating') COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `options` text COLLATE utf8mb4_unicode_ci,
  `required` tinyint(1) DEFAULT '0',
  `order_num` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`id`, `survey_id`, `question`, `question_type`, `options`, `required`, `order_num`) VALUES
(1, 1, 'ما مدى رضاك عن الخدمة المقدمة؟', 'rating', '1,2,3,4,5', 1, 1),
(2, 1, 'هل توصي المخبر للآخرين؟', 'radio', 'نعم,لا', 1, 2),
(3, 1, 'ما هي ملاحظاتك؟', 'text', '', 0, 3),
(4, 2, 'تقييم الطبيب', 'rating', '1,2,3,4,5', 1, 1),
(5, 2, 'مدى الاحترافية', 'rating', '1,2,3,4,5', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `survey_responses`
--

CREATE TABLE `survey_responses` (
  `id` int NOT NULL,
  `survey_id` int NOT NULL,
  `patient_id` int NOT NULL,
  `question_id` int NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_responses`
--

INSERT INTO `survey_responses` (`id`, `survey_id`, `patient_id`, `question_id`, `answer`, `submitted_at`) VALUES
(6, 1, 8, 1, '5', '2026-02-01 12:54:00'),
(7, 1, 8, 2, 'نعم', '2026-02-01 12:54:00');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int NOT NULL,
  `setting_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'site_name', 'مخبر الأشعة التخصصي', '2026-03-05 10:49:31'),
(2, 'contact_email', 'admin@radiology.sy', '2026-03-05 10:49:31'),
(3, 'address', 'دمشق - المزة', '2026-03-05 10:49:31'),
(4, 'phone', '+963944123456', '2026-03-05 10:49:31'),
(5, 'platform_name', 'نظام إدارة مخبر الأشعة', '2026-03-22 11:44:07'),
(6, 'currency', 'ل.س', '2026-03-22 10:52:44'),
(7, 'timezone', 'Asia/Damascus', '2026-03-22 10:52:44'),
(8, 'language', 'ar', '2026-03-22 10:52:44'),
(9, 'maintenance_mode', '0', '2026-03-22 10:52:44'),
(10, 'max_appointments_per_day', '20', '2026-03-22 10:52:44'),
(11, 'invoice_prefix', 'INV', '2026-03-22 11:42:19');

-- --------------------------------------------------------

--
-- Stand-in structure for view `upcoming_appointments`
-- (See below for the actual view)
--
CREATE TABLE `upcoming_appointments` (
`id` int
,`patient_id` int
,`doctor_id` int
,`department_id` int
,`appointment_date` date
,`appointment_time` time
,`status` enum('pending','confirmed','completed','cancelled','no-show')
,`notes` text
,`staff_notes` text
,`patient_notes` text
,`created_at` timestamp
,`updated_at` timestamp
,`patient_name` varchar(100)
,`patient_phone` varchar(20)
,`doctor_name` varchar(100)
,`department_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','doctor','staff','patient') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `specialization` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','suspended') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `role`, `phone`, `address`, `gender`, `birth_date`, `department_id`, `specialization`, `license_number`, `status`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@radiology.sy', '$2y$10$Oga83I4/v5EKDc96DxtvQOnP0xYdObGKq1nt0h.j/C2aMAj7spMwO', 'المدير العام', 'admin', '+963944123456', 'دمشق - المزة', 'male', NULL, NULL, NULL, NULL, 'active', '2026-03-25 15:02:22', '2026-02-01 12:00:58', '2026-03-25 12:02:22'),
(2, 'manager', 'manager@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير المخبر', 'admin', '+963944234567', 'حلب - الجديدة', NULL, NULL, NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:00:58', '2026-02-02 10:17:25'),
(3, 'dr_ahmad', 'ahmad@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'د. أحمد محمد', 'doctor', '+963944345678', 'دمشق - برزة', 'male', '1980-05-15', 1, 'أخصائي أشعة', 'SYR-12345', 'active', '2026-03-25 15:05:36', '2026-02-01 12:00:58', '2026-03-25 12:05:36'),
(4, 'dr_leila', 'leila@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'د. ليلى حسن', 'doctor', '+963944456789', 'حلب - السليمانية', 'female', '1985-08-20', 2, 'أخصائية رنين مغناطيسي', 'SYR-23456', 'active', NULL, '2026-02-01 12:00:58', '2026-02-11 20:07:35'),
(5, 'dr_karim', 'karim@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'د. كريم علي', 'doctor', '+963944567890', 'حمص - البياضة', 'male', '1978-12-10', 3, 'أخصائي تصوير مقطعي', 'SYR-34567', 'active', NULL, '2026-02-01 12:00:58', '2026-03-25 12:03:18'),
(6, 'staff_samer', 'samer@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'سامر أحمد', 'staff', '+963944678901', 'دمشق - الميدان', 'male', '1990-03-25', NULL, NULL, NULL, 'active', '2026-03-25 15:04:54', '2026-02-01 12:00:58', '2026-03-25 12:04:54'),
(7, 'staff_nour', 'nour@radiology.sy', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'نور محمد', 'staff', '+963944789012', 'حلب - الشيخ مقصود', 'female', '1992-07-18', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(8, 'patient_ali', 'ali@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'علي حسن', 'patient', '+963944890123', 'دمشق - ركن الدين', 'male', '1995-01-10', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(9, 'patient_fatima', 'fatima@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'فاطمة خالد', 'patient', '+963944901234', 'حلب - الجندول', 'female', '1988-09-05', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(10, 'patient_omar', 'omar@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'عمر يوسف', 'patient', '+963944012345', 'حمص - الوعر', 'male', '1975-11-20', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:00:58', '2026-02-01 12:00:58'),
(11, 'patient_youssef', 'youssef@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'يوسف أحمد', 'patient', '+963944111222', 'دمشق - الميدان', 'male', '1992-03-15', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:53:28', '2026-03-05 08:55:23'),
(12, 'patient_sara', 'sara@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'سارة محمد', 'patient', '+963944222333', 'حلب - الجديدة', 'female', '1989-07-22', NULL, NULL, NULL, 'active', '2026-03-25 15:26:15', '2026-02-01 12:53:28', '2026-03-25 12:26:15'),
(13, 'patient_ahmad2', 'ahmad2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'أحمد خالد', 'patient', '+963944333444', 'حمص - البياضة', 'male', '1994-11-08', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:53:28', '2026-02-01 12:53:28'),
(14, 'patient_leila2', 'leila2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ليلى يوسف', 'patient', '+963944444555', 'دمشق - برزة', 'female', '1991-05-30', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:53:28', '2026-02-01 12:53:28'),
(15, 'patient_karim2', 'karim2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'كريم علي', 'patient', '+963944555666', 'حلب - السليمانية', 'male', '1987-09-12', NULL, NULL, NULL, 'active', NULL, '2026-02-01 12:53:28', '2026-02-01 12:53:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `idx_appointments_date` (`appointment_date`),
  ADD KEY `idx_appointments_date_status` (`appointment_date`,`status`),
  ADD KEY `idx_appointments_doctor` (`doctor_id`,`appointment_date`),
  ADD KEY `idx_appointments_patient` (`patient_id`,`appointment_date`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD KEY `staff_id` (`staff_id`),
  ADD KEY `payment_method_id` (`payment_method_id`),
  ADD KEY `idx_invoices_patient` (`patient_id`),
  ADD KEY `idx_invoices_status_date` (`status`,`created_at`);

--
-- Indexes for table `medical_records`
--
ALTER TABLE `medical_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `appointment_id` (`appointment_id`),
  ADD KEY `idx_medical_records_patient` (`patient_id`),
  ADD KEY `idx_medical_records_patient_date` (`patient_id`,`visit_date`);

--
-- Indexes for table `patient_statistics`
--
ALTER TABLE `patient_statistics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_patient_stats_dept` (`department_id`,`year`,`month`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surveys`
--
ALTER TABLE `surveys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_id` (`survey_id`);

--
-- Indexes for table `survey_responses`
--
ALTER TABLE `survey_responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `idx_survey_responses_survey` (`survey_id`,`patient_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_role_status` (`role`,`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `medical_records`
--
ALTER TABLE `medical_records`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `patient_statistics`
--
ALTER TABLE `patient_statistics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `surveys`
--
ALTER TABLE `surveys`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `survey_questions`
--
ALTER TABLE `survey_questions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `survey_responses`
--
ALTER TABLE `survey_responses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

-- --------------------------------------------------------

--
-- Structure for view `monthly_statistics`
--
DROP TABLE IF EXISTS `monthly_statistics`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `monthly_statistics`  AS SELECT year(`appointments`.`appointment_date`) AS `year`, month(`appointments`.`appointment_date`) AS `month`, count(0) AS `total_appointments`, count((case when (`appointments`.`status` = 'completed') then 1 end)) AS `completed_appointments`, count((case when (`appointments`.`status` = 'cancelled') then 1 end)) AS `cancelled_appointments`, `appointments`.`department_id` AS `department_id` FROM `appointments` GROUP BY year(`appointments`.`appointment_date`), month(`appointments`.`appointment_date`), `appointments`.`department_id` ;

-- --------------------------------------------------------

--
-- Structure for view `upcoming_appointments`
--
DROP TABLE IF EXISTS `upcoming_appointments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `upcoming_appointments`  AS SELECT `a`.`id` AS `id`, `a`.`patient_id` AS `patient_id`, `a`.`doctor_id` AS `doctor_id`, `a`.`department_id` AS `department_id`, `a`.`appointment_date` AS `appointment_date`, `a`.`appointment_time` AS `appointment_time`, `a`.`status` AS `status`, `a`.`notes` AS `notes`, `a`.`staff_notes` AS `staff_notes`, `a`.`patient_notes` AS `patient_notes`, `a`.`created_at` AS `created_at`, `a`.`updated_at` AS `updated_at`, `p`.`full_name` AS `patient_name`, `p`.`phone` AS `patient_phone`, `d`.`full_name` AS `doctor_name`, `dept`.`name` AS `department_name` FROM (((`appointments` `a` join `users` `p` on((`a`.`patient_id` = `p`.`id`))) join `users` `d` on((`a`.`doctor_id` = `d`.`id`))) join `departments` `dept` on((`a`.`department_id` = `dept`.`id`))) WHERE ((`a`.`appointment_date` >= curdate()) AND (`a`.`status` <> 'cancelled')) ORDER BY `a`.`appointment_date` ASC, `a`.`appointment_time` ASC ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`);

--
-- Constraints for table `medical_records`
--
ALTER TABLE `medical_records`
  ADD CONSTRAINT `medical_records_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `medical_records_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `medical_records_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`);

--
-- Constraints for table `patient_statistics`
--
ALTER TABLE `patient_statistics`
  ADD CONSTRAINT `patient_statistics_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `surveys`
--
ALTER TABLE `surveys`
  ADD CONSTRAINT `surveys_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD CONSTRAINT `survey_questions_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`);

--
-- Constraints for table `survey_responses`
--
ALTER TABLE `survey_responses`
  ADD CONSTRAINT `survey_responses_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`),
  ADD CONSTRAINT `survey_responses_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `survey_responses_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `survey_questions` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
