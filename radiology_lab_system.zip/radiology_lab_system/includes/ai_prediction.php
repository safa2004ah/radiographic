<?php
class AIPrediction {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    /**
     * التنبؤ بعدد المرضى للشهر القادم
     * @param int $department_id معرف القسم
     * @param int $months عدد الأشهر السابقة للتحليل
     * @return array نتائج التنبؤ
     */
    public function predictPatients($department_id, $months = 12) {
        // جلب البيانات التاريخية
        $historical_data = $this->getHistoricalData($department_id, $months);
        
        if (count($historical_data) < 3) {
            return [
                'predicted_count' => 0,
                'confidence' => 0,
                'trend' => 'unknown',
                'message' => 'لا توجد بيانات كافية للتنبؤ'
            ];
        }
        
        // حساب التنبؤ باستخدام الانحدار الخطي
        $prediction = $this->linearRegression($historical_data);
        
        // تحليل الاتجاه
        $trend = $this->analyzeTrend($historical_data);
        
        // حساب مستوى الثقة
        $confidence = $this->calculateConfidence($historical_data, $prediction);
        
        return [
            'predicted_count' => round($prediction),
            'confidence' => round($confidence * 100, 2),
            'trend' => $trend,
            'historical_data' => $historical_data,
            'next_month' => date('Y-m', strtotime('+1 month'))
        ];
    }
    
    /**
     * جلب البيانات التاريخية
     */
    private function getHistoricalData($department_id, $months) {
        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$months} months"));
        
        $query = "SELECT month, year, patient_count 
                  FROM patient_statistics 
                  WHERE department_id = ? 
                  AND year >= YEAR(DATE_SUB(NOW(), INTERVAL ? MONTH))
                  AND month >= MONTH(DATE_SUB(NOW(), INTERVAL ? MONTH))
                  ORDER BY year ASC, month ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $department_id, $months, $months);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'month' => $row['month'],
                'year' => $row['year'],
                'count' => $row['patient_count']
            ];
        }
        
        return $data;
    }
    
    /**
     * خوارزمية الانحدار الخطي
     */
    private function linearRegression($data) {
        $n = count($data);
        
        if ($n < 2) {
            return 0;
        }
        
        $sum_x = 0;
        $sum_y = 0;
        $sum_xy = 0;
        $sum_xx = 0;
        
        for ($i = 0; $i < $n; $i++) {
            $x = $i + 1; // الشهر
            $y = $data[$i]['count'];
            
            $sum_x += $x;
            $sum_y += $y;
            $sum_xy += $x * $y;
            $sum_xx += $x * $x;
        }
        
        // حساب ميل الخط
        $slope = ($n * $sum_xy - $sum_x * $sum_y) / ($n * $sum_xx - $sum_x * $sum_x);
        
        // حساب التقاطع
        $intercept = ($sum_y - $slope * $sum_x) / $n;
        
        // التنبؤ للشهر القادم
        $next_month = $n + 1;
        $prediction = $slope * $next_month + $intercept;
        
        return max(0, $prediction); // لا يمكن أن يكون سالب
    }
    
    /**
     * تحليل الاتجاه
     */
    private function analyzeTrend($data) {
        $n = count($data);
        
        if ($n < 2) {
            return 'stable';
        }
        
        $first_half = array_slice($data, 0, floor($n / 2));
        $second_half = array_slice($data, floor($n / 2));
        
        $avg_first = array_sum(array_column($first_half, 'count')) / count($first_half);
        $avg_second = array_sum(array_column($second_half, 'count')) / count($second_half);
        
        $change_percentage = (($avg_second - $avg_first) / $avg_first) * 100;
        
        if ($change_percentage > 10) {
            return 'increasing';
        } elseif ($change_percentage < -10) {
            return 'decreasing';
        } else {
            return 'stable';
        }
    }
    
    /**
     * حساب مستوى الثقة
     */
    private function calculateConfidence($data, $prediction) {
        $values = array_column($data, 'count');
        $avg = array_sum($values) / count($values);
        $std_dev = $this->standardDeviation($values);
        
        // حساب مستوى الثقة بناءً على التباين
        $confidence = 1 - ($std_dev / ($avg + $std_dev));
        
        return max(0.5, min(0.95, $confidence)); // بين 50% و 95%
    }
    
    /**
     * حساب الانحراف المعياري
     */
    private function standardDeviation($values) {
        $avg = array_sum($values) / count($values);
        $sum = 0;
        
        foreach ($values as $value) {
            $sum += pow($value - $avg, 2);
        }
        
        return sqrt($sum / count($values));
    }
    
    /**
     * تحديث إحصائيات المرضى
     */
    public function updateStatistics($department_id, $month, $year, $count) {
        $query = "INSERT INTO patient_statistics (department_id, month, year, patient_count) 
                  VALUES (?, ?, ?, ?) 
                  ON DUPLICATE KEY UPDATE patient_count = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iiiii", $department_id, $month, $year, $count, $count);
        
        return $stmt->execute();
    }
    
    /**
     * الحصول على مقارنة بين الأقسام
     */
    public function getDepartmentComparison($year = null) {
        if (!$year) {
            $year = date('Y');
        }
        
        $query = "SELECT d.name as department_name, 
                         SUM(ps.patient_count) as total_patients,
                         AVG(ps.patient_count) as avg_patients,
                         MAX(ps.patient_count) as max_patients,
                         MIN(ps.patient_count) as min_patients
                  FROM patient_statistics ps
                  JOIN departments d ON ps.department_id = d.id
                  WHERE ps.year = ? AND d.status = 'active'
                  GROUP BY ps.department_id, d.name
                  ORDER BY total_patients DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $year);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        return $data;
    }
}
?>