<?php
// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'radiology_lab');

// إعدادات الموقع
define('SITE_NAME', 'نظام إدارة مخبر الأشعة');
define('SITE_URL', 'http://localhost/radiology_lab_system');
define('ADMIN_EMAIL', 'admin@radiology.sy');

// إعدادات الأمان
define('SESSION_LIFE', 3600); // ساعة واحدة
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_TIMEOUT', 900); // 15 دقيقة

// إعدادات التحميل
define('MAX_FILE_SIZE', 5242880); // 5 ميجابايت
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// إعدادات الذكاء الصناعي
define('AI_PREDICTION_MONTHS', 12);
define('AI_CONFIDENCE_LEVEL', 0.85);

// إعدادات اللغة والتاريخ
date_default_timezone_set('Asia/Damascus');
setlocale(LC_ALL, 'ar_SY.UTF-8');

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// الاتصال بقاعدة البيانات
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// التحقق من تسجيل الدخول
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}

// الحصول على معلومات المستخدم الحالي
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $conn = getDBConnection();
    $user_id = $_SESSION['user_id'];
    $query = "SELECT * FROM users WHERE id = ? AND status = 'active'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// التحقق من الصلاحيات
function hasPermission($required_role) {
    $current_user = getCurrentUser();
    
    if (!$current_user) {
        return false;
    }
    
    $allowed_roles = [
        'admin' => ['admin'],
        'doctor' => ['admin', 'doctor'],
        'staff' => ['admin', 'staff'],
        'patient' => ['admin', 'doctor', 'staff', 'patient']
    ];
    
    return in_array($current_user['role'], $allowed_roles[$required_role]);
}

// التحقق من صلاحيات محددة
function checkPermission($permission) {
    $current_user = getCurrentUser();
    
    if (!$current_user) {
        return false;
    }
    
    $permissions = [
        'manage_users' => ['admin'],
        'manage_settings' => ['admin'],
        'manage_appointments' => ['admin', 'staff'],
        'manage_invoices' => ['admin', 'staff'],
        'manage_patients' => ['admin', 'staff'],
        'manage_surveys' => ['admin', 'staff'],
        'manage_medical_records' => ['doctor'],
        'view_payment_methods' => ['admin', 'staff', 'patient'],
        'doctor_dashboard' => ['doctor'],
        'upload_xray' => ['doctor'],
        'view_my_appointments' => ['patient', 'admin', 'staff'],
        'view_my_medical_records' => ['patient', 'doctor', 'admin']
    ];
    
    if (!isset($permissions[$permission])) {
        return false;
    }
    
    return in_array($current_user['role'], $permissions[$permission]);
}
?>